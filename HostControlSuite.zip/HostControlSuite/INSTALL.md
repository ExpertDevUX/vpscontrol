# VPS Control Panel Installation Guide

This guide provides step-by-step instructions for installing and setting up the VPS Control Panel.

**Author:** Tony Pham  
**Contact:** info@hwosecurity.org

## Quick Installation

### Prerequisites

- Python 3.11 or higher
- PostgreSQL database server
- Git

### Installation Steps

1. **Clone the repository**
   ```bash
   git clone https://github.com/yourusername/vps-control-panel.git
   cd vps-control-panel
   ```

2. **Set up virtual environment (recommended)**
   ```bash
   python -m venv venv
   
   # Activate on Linux/macOS
   source venv/bin/activate
   
   # Activate on Windows
   venv\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   # Install required packages
   pip install -r requirements.txt
   
   # Or install from dependencies.md if requirements.txt is not available
   pip install Flask Flask-SQLAlchemy Flask-Login Flask-WTF SQLAlchemy Werkzeug gunicorn email-validator psycopg2-binary pycryptodome pyotp boto3 reportlab PyPDF2 qrcode anthropic html2text python-dotenv
   ```

4. **Configure environment**
   
   Create a `.env` file in the project root with the following settings:
   ```
   # Required settings
   DATABASE_URL=postgresql://username:password@localhost:5432/vpscontrolpanel
   SESSION_SECRET=your_secret_key_here
   
   # Optional settings
   COMPANY_NAME=Your Company
   ADMIN_EMAIL=admin@example.com
   
   # AI Chat settings (optional)
   ANTHROPIC_API_KEY=your_anthropic_api_key
   AI_ENABLED=true
   
   # Payment settings (optional)
   PAYPAL_CLIENT_ID=your_paypal_client_id
   PAYPAL_SECRET_KEY=your_paypal_secret_key
   PAYPAL_SANDBOX=true
   ```

5. **Run the application**
   ```bash
   python main.py
   ```
   
   The application will:
   - Check if the database exists and create it if necessary
   - Initialize the database tables
   - Start the web server on port 5000

6. **Access the application**
   
   Open your browser and go to:
   ```
   http://localhost:5000
   ```
   
   Log in with default admin credentials:
   - Username: `admin`
   - Email: `admin@example.com`
   - Password: `admin123`
   
   **Important:** Change these credentials immediately!

## Production Deployment

For production environments, use Gunicorn with a proper web server like Nginx:

1. **Install Gunicorn**
   ```bash
   pip install gunicorn
   ```

2. **Create a systemd service** (on Linux)
   
   Create `/etc/systemd/system/vpscontrolpanel.service`:
   ```
   [Unit]
   Description=VPS Control Panel
   After=network.target
   
   [Service]
   User=your_username
   WorkingDirectory=/path/to/vps-control-panel
   Environment="PATH=/path/to/vps-control-panel/venv/bin"
   ExecStart=/path/to/vps-control-panel/venv/bin/gunicorn --bind 0.0.0.0:5000 --workers 3 main:app
   Restart=always
   
   [Install]
   WantedBy=multi-user.target
   ```

3. **Enable and start the service**
   ```bash
   sudo systemctl enable vpscontrolpanel
   sudo systemctl start vpscontrolpanel
   ```

4. **Set up Nginx as a reverse proxy** (recommended)
   
   Install Nginx and configure a site:
   ```
   server {
       listen 80;
       server_name your_domain.com;
       
       location / {
           proxy_pass http://localhost:5000;
           proxy_set_header Host $host;
           proxy_set_header X-Real-IP $remote_addr;
       }
   }
   ```

## Troubleshooting

- **Database connection issues**: Verify PostgreSQL is running and credentials are correct
- **Missing packages**: Check that all dependencies are installed
- **Port conflicts**: Change the port in `main.py` if port 5000 is in use
- **Permission errors**: Ensure proper file permissions in the application directory

For additional help, refer to the comprehensive documentation in the [README.md](README.md) file.