import os
import logging
from database import init_database

# Configure logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Initialize database if needed
logger.info("Checking database configuration...")
db_initialized = init_database()
if db_initialized:
    logger.info("Database initialized successfully.")
else:
    logger.warning("Database initialization skipped or failed. Using existing database configuration.")

# Import Flask app after database initialization
from app import app

if __name__ == "__main__":
    # Get port from environment or use 5000 as default
    port = int(os.environ.get("PORT", 5000))
    
    # Run the application
    logger.info(f"Starting VPS Control Panel on port {port}...")
    app.run(host="0.0.0.0", port=port, debug=True)
