import threading
import json
import logging
import time
from datetime import datetime
from queue import Queue
from flask import Flask

# Set up logging
logger = logging.getLogger(__name__)

# Global collections for WebSocket functionality
connected_clients = {}  # Maps client_id to WebSocket connection
user_connections = {}   # Maps user_id to set of client_ids
message_queues = {}     # Maps client_id to message queue

class WebSocketHandler:
    """
    Handles WebSocket connections for real-time updates
    This is a simplified WebSocket handler implementation
    
    In a production environment, you would use a proper WebSocket library or service
    such as Socket.IO, Flask-SocketIO, or a dedicated service like Pusher or Ably
    """
    
    @staticmethod
    def register_client(client_id, websocket, user_id=None):
        """Register a new WebSocket client"""
        connected_clients[client_id] = websocket
        message_queues[client_id] = Queue()
        
        if user_id:
            if user_id not in user_connections:
                user_connections[user_id] = set()
            user_connections[user_id].add(client_id)
        
        # Start a background thread to process messages for this client
        thread = threading.Thread(target=WebSocketHandler.process_messages, args=(client_id,))
        thread.daemon = True
        thread.start()
        
        logger.info(f"Client {client_id} registered for user {user_id}")
    
    @staticmethod
    def unregister_client(client_id, user_id=None):
        """Unregister a WebSocket client"""
        if client_id in connected_clients:
            del connected_clients[client_id]
        
        if client_id in message_queues:
            del message_queues[client_id]
        
        if user_id and user_id in user_connections:
            user_connections[user_id].discard(client_id)
            if not user_connections[user_id]:
                del user_connections[user_id]
        
        logger.info(f"Client {client_id} unregistered for user {user_id}")
    
    @staticmethod
    def send_to_user(user_id, message):
        """Send a message to all clients for a specific user"""
        if user_id not in user_connections:
            return
        
        # Convert message to JSON if it's a dict
        if isinstance(message, dict):
            message = json.dumps(message)
        
        # Add message to queue for each client
        for client_id in user_connections[user_id]:
            if client_id in message_queues:
                message_queues[client_id].put(message)
    
    @staticmethod
    def process_messages(client_id):
        """Process messages for a client in a background thread"""
        queue = message_queues.get(client_id)
        if not queue:
            return
        
        try:
            while True:
                # Check if client is still connected
                if client_id not in connected_clients:
                    break
                
                # Get message from queue if available
                try:
                    message = queue.get(block=True, timeout=0.1)
                    websocket = connected_clients.get(client_id)
                    if websocket:
                        websocket.send(message)
                except Exception:
                    # No message available or error sending
                    time.sleep(0.1)
        except Exception as e:
            logger.error(f"Error processing messages for client {client_id}: {str(e)}")

def send_deployment_update(server_id, user_id, status, progress, log=None, error_message=None):
    """
    Send a deployment update via WebSocket
    
    Args:
        server_id: ID of the server being deployed
        user_id: ID of the user who owns the server
        status: Deployment status (pending, in_progress, complete, error)
        progress: Deployment progress percentage (0-100)
        log: Optional log entry to include
        error_message: Optional error message if status is 'error'
    """
    data = {
        'server_id': server_id,
        'status': status,
        'progress': progress,
        'timestamp': datetime.utcnow().isoformat()
    }
    
    if log:
        data['log'] = log
    
    if error_message and status == 'error':
        data['error_message'] = error_message
    
    WebSocketHandler.send_to_user(user_id, data)
    logger.debug(f"Sent deployment update for server {server_id} to user {user_id}")

# This function would be used by the Flask route handler that sets up the WebSocket
def handle_websocket(websocket, user_id):
    """
    Handle a WebSocket connection
    
    This is a placeholder for the actual WebSocket handling code
    In a real implementation, you would use a WebSocket library that integrates with Flask
    """
    try:
        client_id = f"client_{int(time.time() * 1000)}"
        WebSocketHandler.register_client(client_id, websocket, user_id)
        
        # Send initial connection confirmation
        websocket.send(json.dumps({
            'type': 'connection',
            'status': 'connected',
            'client_id': client_id
        }))
        
        # Main message loop - keep connection open
        while True:
            try:
                message = websocket.receive()
                if message is None:
                    break  # Client closed connection
                
                # Process incoming messages (if any)
                # In this implementation, we don't expect client messages
                pass
            except Exception as e:
                logger.error(f"Error in WebSocket message loop: {str(e)}")
                break
                
    except Exception as e:
        logger.error(f"WebSocket error: {str(e)}")
    finally:
        WebSocketHandler.unregister_client(client_id, user_id)
        
# Note: To integrate this with Flask, you would typically use a library like Flask-SocketIO
# or implement the WebSocket protocol with a WSGI server that supports it (like Gevent or Eventlet)
# The actual implementation would depend on your specific server setup