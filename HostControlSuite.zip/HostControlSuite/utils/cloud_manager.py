import logging
import json
import requests
import os
from abc import ABC, abstractmethod
import boto3
from datetime import datetime
import time
import base64
import hmac
import hashlib
import uuid
import re

logger = logging.getLogger(__name__)

class CloudProviderManager(ABC):
    """Base class for cloud provider integrations"""
    
    @abstractmethod
    def test_connection(self):
        """Test connection to the cloud provider API"""
        pass
    
    @abstractmethod
    def get_available_regions(self):
        """Get list of available regions"""
        pass
    
    @abstractmethod
    def get_available_plans(self):
        """Get list of available plans/sizes"""
        pass
    
    @abstractmethod
    def get_available_os(self):
        """Get list of available operating systems/images"""
        pass
    
    @abstractmethod
    def create_server(self, name, plan_id, os_id, region=None, ssh_keys=None):
        """Create a new server"""
        pass
    
    @abstractmethod
    def delete_server(self, server_id):
        """Delete a server"""
        pass
    
    @abstractmethod
    def restart_server(self, server_id):
        """Restart a server"""
        pass
    
    @abstractmethod
    def power_on_server(self, server_id):
        """Power on a server"""
        pass
    
    @abstractmethod
    def power_off_server(self, server_id):
        """Power off a server"""
        pass
    
    @abstractmethod
    def get_server_details(self, server_id):
        """Get server details"""
        pass
    
    @abstractmethod
    def get_server_status(self, server_id):
        """Get server status and resource usage"""
        pass


class DigitalOceanManager(CloudProviderManager):
    """DigitalOcean API integration"""
    
    def __init__(self, api_key, region=None):
        self.api_key = api_key
        self.region = region
        self.base_url = "https://api.digitalocean.com/v2"
        self.headers = {
            "Authorization": f"Bearer {self.api_key}",
            "Content-Type": "application/json"
        }
    
    def test_connection(self):
        """Test connection to DigitalOcean API"""
        try:
            response = requests.get(f"{self.base_url}/account", headers=self.headers)
            if response.status_code == 200:
                account_data = response.json().get('account', {})
                return {
                    'success': True,
                    'message': f"Successfully connected to DigitalOcean API - Account: {account_data.get('email')}",
                    'data': account_data
                }
            else:
                return {
                    'success': False,
                    'message': f"Failed to connect: {response.status_code} - {response.text}",
                    'data': None
                }
        except Exception as e:
            logger.error(f"Error testing DigitalOcean connection: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_available_regions(self):
        """Get list of available regions from DigitalOcean"""
        try:
            response = requests.get(f"{self.base_url}/regions", headers=self.headers)
            if response.status_code == 200:
                regions = response.json().get('regions', [])
                # Filter to only available regions
                available_regions = [r for r in regions if r.get('available', False)]
                return {
                    'success': True,
                    'message': f"Found {len(available_regions)} available regions",
                    'data': available_regions
                }
            else:
                return {
                    'success': False,
                    'message': f"Failed to get regions: {response.status_code} - {response.text}",
                    'data': None
                }
        except Exception as e:
            logger.error(f"Error getting DigitalOcean regions: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_available_plans(self):
        """Get list of available plans/sizes from DigitalOcean"""
        try:
            response = requests.get(f"{self.base_url}/sizes", headers=self.headers)
            if response.status_code == 200:
                sizes = response.json().get('sizes', [])
                # Filter to only available sizes
                available_sizes = [s for s in sizes if s.get('available', False)]
                
                # Transform to our format
                plans = []
                for size in available_sizes:
                    # Calculate price with appropriate precision
                    monthly_price = float(size.get('price_monthly', 0))
                    
                    plan = {
                        'provider_plan_id': size.get('slug'),
                        'name': size.get('slug').replace('-', ' ').title(),
                        'cpu_cores': size.get('vcpus', 1),
                        'ram_mb': size.get('memory', 0),
                        'disk_gb': size.get('disk', 0),
                        'bandwidth_gb': size.get('transfer', 0),
                        'price_monthly': monthly_price,
                        'regions': size.get('regions', []),
                        'description': f"{size.get('vcpus')} CPU, {size.get('memory')}MB RAM, {size.get('disk')}GB Disk"
                    }
                    plans.append(plan)
                
                return {
                    'success': True,
                    'message': f"Found {len(plans)} available plans",
                    'data': plans
                }
            else:
                return {
                    'success': False,
                    'message': f"Failed to get plans: {response.status_code} - {response.text}",
                    'data': None
                }
        except Exception as e:
            logger.error(f"Error getting DigitalOcean plans: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_available_os(self):
        """Get list of available operating systems/images from DigitalOcean"""
        try:
            response = requests.get(f"{self.base_url}/images?type=distribution", headers=self.headers)
            if response.status_code == 200:
                images = response.json().get('images', [])
                
                # Filter to public distribution images
                distribution_images = [i for i in images if i.get('public', False)]
                
                # Transform to our format
                os_list = []
                for image in distribution_images:
                    os_info = {
                        'id': image.get('slug') or image.get('id'),
                        'name': image.get('name'),
                        'distribution': image.get('distribution'),
                        'description': f"{image.get('distribution')} {image.get('name')}",
                        'min_disk_size': image.get('min_disk_size', 0)
                    }
                    os_list.append(os_info)
                
                return {
                    'success': True,
                    'message': f"Found {len(os_list)} available operating systems",
                    'data': os_list
                }
            else:
                return {
                    'success': False,
                    'message': f"Failed to get images: {response.status_code} - {response.text}",
                    'data': None
                }
        except Exception as e:
            logger.error(f"Error getting DigitalOcean images: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def create_server(self, name, plan_id, os_id, region=None, ssh_keys=None):
        """Create a new server on DigitalOcean"""
        try:
            # Use instance region or specified region
            region_to_use = region or self.region
            if not region_to_use:
                regions_info = self.get_available_regions()
                if regions_info['success']:
                    # Use first available region
                    region_to_use = regions_info['data'][0]['slug']
                else:
                    return {
                        'success': False,
                        'message': "No region specified and failed to get available regions",
                        'data': None
                    }
            
            # Prepare request
            droplet_data = {
                "name": name,
                "region": region_to_use,
                "size": plan_id,
                "image": os_id,
                "backups": False,
                "ipv6": True,
                "monitoring": True,
                "tags": ["vps-control-panel"]
            }
            
            if ssh_keys:
                droplet_data["ssh_keys"] = ssh_keys
            
            response = requests.post(
                f"{self.base_url}/droplets", 
                headers=self.headers,
                json=droplet_data
            )
            
            if response.status_code in (201, 202):
                droplet_info = response.json().get('droplet', {})
                droplet_id = droplet_info.get('id')
                
                # Wait for the droplet to be active and get IP
                server_info = self._wait_for_server(droplet_id)
                if server_info and 'ip_address' in server_info:
                    return {
                        'success': True,
                        'message': f"Server {name} created successfully with IP {server_info['ip_address']}",
                        'data': server_info
                    }
                else:
                    return {
                        'success': True,
                        'message': f"Server {name} creation initiated. Droplet ID: {droplet_id}",
                        'data': {'id': droplet_id, 'name': name}
                    }
            else:
                return {
                    'success': False,
                    'message': f"Failed to create server: {response.status_code} - {response.text}",
                    'data': None
                }
        except Exception as e:
            logger.error(f"Error creating DigitalOcean server: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def _wait_for_server(self, droplet_id, max_attempts=20, interval=6):
        """Wait for a droplet to be active and get its networking info"""
        for attempt in range(max_attempts):
            try:
                response = requests.get(
                    f"{self.base_url}/droplets/{droplet_id}",
                    headers=self.headers
                )
                
                if response.status_code == 200:
                    droplet_info = response.json().get('droplet', {})
                    status = droplet_info.get('status')
                    
                    if status == 'active':
                        # Get IP address
                        networks = droplet_info.get('networks', {})
                        v4_networks = networks.get('v4', [])
                        ip_address = None
                        
                        for network in v4_networks:
                            if network.get('type') == 'public':
                                ip_address = network.get('ip_address')
                                break
                        
                        if ip_address:
                            # Get default password
                            # In real implementation, you would get this from the provider
                            # For DigitalOcean, password is usually emailed
                            # Here we'll use a random placeholder
                            import random
                            import string
                            password = ''.join(random.choices(string.ascii_letters + string.digits, k=12))
                            
                            return {
                                'id': droplet_id,
                                'name': droplet_info.get('name'),
                                'status': status,
                                'ip_address': ip_address,
                                'username': 'root',  # Default username for DigitalOcean
                                'password': password,  # Placeholder - real password is emailed
                                'ssh_port': 22,
                                'creation_time': datetime.utcnow().isoformat()
                            }
                
                # Not ready yet, wait and try again
                time.sleep(interval)
                
            except Exception as e:
                logger.error(f"Error waiting for DigitalOcean server: {str(e)}")
                time.sleep(interval)
        
        # If we get here, the server did not become active in time
        logger.warning(f"Droplet {droplet_id} did not become active within expected time")
        return None
    
    def delete_server(self, server_id):
        """Delete a server on DigitalOcean"""
        try:
            response = requests.delete(
                f"{self.base_url}/droplets/{server_id}",
                headers=self.headers
            )
            
            if response.status_code in (202, 204):
                return {
                    'success': True,
                    'message': f"Server {server_id} deletion initiated",
                    'data': None
                }
            else:
                return {
                    'success': False,
                    'message': f"Failed to delete server: {response.status_code} - {response.text}",
                    'data': None
                }
        except Exception as e:
            logger.error(f"Error deleting DigitalOcean server: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def restart_server(self, server_id):
        """Restart a server on DigitalOcean"""
        try:
            response = requests.post(
                f"{self.base_url}/droplets/{server_id}/actions",
                headers=self.headers,
                json={"type": "reboot"}
            )
            
            if response.status_code in (201, 202):
                action_id = response.json().get('action', {}).get('id')
                return {
                    'success': True,
                    'message': f"Server {server_id} restart initiated (Action ID: {action_id})",
                    'data': {'action_id': action_id}
                }
            else:
                return {
                    'success': False,
                    'message': f"Failed to restart server: {response.status_code} - {response.text}",
                    'data': None
                }
        except Exception as e:
            logger.error(f"Error restarting DigitalOcean server: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def power_on_server(self, server_id):
        """Power on a server on DigitalOcean"""
        try:
            response = requests.post(
                f"{self.base_url}/droplets/{server_id}/actions",
                headers=self.headers,
                json={"type": "power_on"}
            )
            
            if response.status_code in (201, 202):
                action_id = response.json().get('action', {}).get('id')
                return {
                    'success': True,
                    'message': f"Server {server_id} power on initiated (Action ID: {action_id})",
                    'data': {'action_id': action_id}
                }
            else:
                return {
                    'success': False,
                    'message': f"Failed to power on server: {response.status_code} - {response.text}",
                    'data': None
                }
        except Exception as e:
            logger.error(f"Error powering on DigitalOcean server: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def power_off_server(self, server_id):
        """Power off a server on DigitalOcean"""
        try:
            response = requests.post(
                f"{self.base_url}/droplets/{server_id}/actions",
                headers=self.headers,
                json={"type": "power_off"}
            )
            
            if response.status_code in (201, 202):
                action_id = response.json().get('action', {}).get('id')
                return {
                    'success': True,
                    'message': f"Server {server_id} power off initiated (Action ID: {action_id})",
                    'data': {'action_id': action_id}
                }
            else:
                return {
                    'success': False,
                    'message': f"Failed to power off server: {response.status_code} - {response.text}",
                    'data': None
                }
        except Exception as e:
            logger.error(f"Error powering off DigitalOcean server: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_server_details(self, server_id):
        """Get server details from DigitalOcean"""
        try:
            response = requests.get(
                f"{self.base_url}/droplets/{server_id}",
                headers=self.headers
            )
            
            if response.status_code == 200:
                droplet_info = response.json().get('droplet', {})
                
                # Extract IP address
                networks = droplet_info.get('networks', {})
                v4_networks = networks.get('v4', [])
                ip_address = None
                
                for network in v4_networks:
                    if network.get('type') == 'public':
                        ip_address = network.get('ip_address')
                        break
                
                # Format the response
                server_details = {
                    'id': droplet_info.get('id'),
                    'name': droplet_info.get('name'),
                    'status': droplet_info.get('status'),
                    'ip_address': ip_address,
                    'memory': droplet_info.get('memory'),
                    'vcpus': droplet_info.get('vcpus'),
                    'disk': droplet_info.get('disk'),
                    'created_at': droplet_info.get('created_at'),
                    'image': droplet_info.get('image', {}).get('slug') or droplet_info.get('image', {}).get('name'),
                    'region': droplet_info.get('region', {}).get('slug'),
                    'tags': droplet_info.get('tags', [])
                }
                
                return {
                    'success': True,
                    'message': f"Server details retrieved for {server_id}",
                    'data': server_details
                }
            else:
                return {
                    'success': False,
                    'message': f"Failed to get server details: {response.status_code} - {response.text}",
                    'data': None
                }
        except Exception as e:
            logger.error(f"Error getting DigitalOcean server details: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_server_status(self, server_id):
        """Get server status from DigitalOcean"""
        # Get base details
        details_result = self.get_server_details(server_id)
        if not details_result['success']:
            return details_result
        
        server_details = details_result['data']
        
        # DigitalOcean doesn't provide real-time CPU/RAM usage via API
        # We would need to install a monitoring agent or use their monitoring service
        # Here we'll return the server status and some placeholder usage values
        
        return {
            'success': True,
            'message': f"Server status retrieved for {server_id}",
            'data': {
                'status': server_details['status'],
                'cpu_usage': None,  # No real-time CPU usage available via API
                'ram_usage': None,  # No real-time RAM usage available via API
                'disk_usage': None,  # No real-time disk usage available via API
                'uptime': None,     # No uptime info available via API
            }
        }


class AWSManager(CloudProviderManager):
    """AWS API integration"""
    
    def __init__(self, api_key, api_secret, region=None):
        self.api_key = api_key
        self.api_secret = api_secret
        self.region = region or 'us-east-1'  # Default to us-east-1 if not specified
        
        # Initialize boto3 EC2 client
        self.ec2 = boto3.client(
            'ec2',
            aws_access_key_id=self.api_key,
            aws_secret_access_key=self.api_secret,
            region_name=self.region
        )
        
        # Initialize boto3 EC2 resource
        self.ec2_resource = boto3.resource(
            'ec2',
            aws_access_key_id=self.api_key,
            aws_secret_access_key=self.api_secret,
            region_name=self.region
        )
    
    def test_connection(self):
        """Test connection to AWS API"""
        try:
            # Try to describe regions as a simple API test
            response = self.ec2.describe_regions()
            return {
                'success': True,
                'message': f"Successfully connected to AWS API in region {self.region}",
                'data': response
            }
        except Exception as e:
            logger.error(f"Error testing AWS connection: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_available_regions(self):
        """Get list of available AWS regions"""
        try:
            response = self.ec2.describe_regions()
            regions = response.get('Regions', [])
            
            # Format the response
            formatted_regions = []
            for region in regions:
                formatted_regions.append({
                    'slug': region.get('RegionName'),
                    'name': region.get('RegionName'),
                    'available': True
                })
            
            return {
                'success': True,
                'message': f"Found {len(formatted_regions)} available regions",
                'data': formatted_regions
            }
        except Exception as e:
            logger.error(f"Error getting AWS regions: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_available_plans(self):
        """Get list of available EC2 instance types"""
        try:
            # This is a simplified implementation that lists some common instance types
            # A full implementation would query the EC2 pricing API
            
            instance_types = [
                {
                    'provider_plan_id': 't2.micro',
                    'name': 'T2 Micro',
                    'cpu_cores': 1,
                    'ram_mb': 1024,
                    'disk_gb': 8,  # Default EBS storage, customizable
                    'bandwidth_gb': 0,  # AWS measures bandwidth differently
                    'price_monthly': 8.50,  # Approximate price - would need pricing API for exact
                    'description': '1 vCPU, 1GB RAM, Up to 3.3 GHz Intel, EBS storage'
                },
                {
                    'provider_plan_id': 't2.small',
                    'name': 'T2 Small',
                    'cpu_cores': 1,
                    'ram_mb': 2048,
                    'disk_gb': 8,
                    'bandwidth_gb': 0,
                    'price_monthly': 17.00,
                    'description': '1 vCPU, 2GB RAM, Up to 3.3 GHz Intel, EBS storage'
                },
                {
                    'provider_plan_id': 't2.medium',
                    'name': 'T2 Medium',
                    'cpu_cores': 2,
                    'ram_mb': 4096,
                    'disk_gb': 8,
                    'bandwidth_gb': 0,
                    'price_monthly': 34.00,
                    'description': '2 vCPU, 4GB RAM, Up to 3.3 GHz Intel, EBS storage'
                },
                {
                    'provider_plan_id': 'm5.large',
                    'name': 'M5 Large',
                    'cpu_cores': 2,
                    'ram_mb': 8192,
                    'disk_gb': 8,
                    'bandwidth_gb': 0,
                    'price_monthly': 69.00,
                    'description': '2 vCPU, 8GB RAM, Up to 3.1 GHz Intel, EBS storage'
                },
                {
                    'provider_plan_id': 'c5.large',
                    'name': 'C5 Large',
                    'cpu_cores': 2,
                    'ram_mb': 4096,
                    'disk_gb': 8,
                    'bandwidth_gb': 0,
                    'price_monthly': 76.00,
                    'description': '2 vCPU, 4GB RAM, Up to 3.4 GHz Intel, EBS storage, Compute Optimized'
                },
                {
                    'provider_plan_id': 'r5.large',
                    'name': 'R5 Large',
                    'cpu_cores': 2,
                    'ram_mb': 16384,
                    'disk_gb': 8,
                    'bandwidth_gb': 0,
                    'price_monthly': 113.00,
                    'description': '2 vCPU, 16GB RAM, Up to 3.1 GHz Intel, EBS storage, Memory Optimized'
                }
            ]
            
            return {
                'success': True,
                'message': f"Found {len(instance_types)} available plans",
                'data': instance_types
            }
        except Exception as e:
            logger.error(f"Error getting AWS plans: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_available_os(self):
        """Get list of available AWS AMIs"""
        try:
            # Query for commonly used AMIs owned by Amazon
            response = self.ec2.describe_images(
                Owners=['amazon'],
                Filters=[
                    {
                        'Name': 'state',
                        'Values': ['available']
                    },
                    {
                        'Name': 'name',
                        'Values': ['amzn2-ami-hvm-*-gp2', 'ubuntu/images/hvm-ssd/ubuntu-*-*-amd64-server-*']
                    }
                ]
            )
            
            images = response.get('Images', [])
            
            # Sort by creation date (newest first)
            images.sort(key=lambda x: x.get('CreationDate', ''), reverse=True)
            
            # Group by type and take the newest ones
            amazon_linux = [img for img in images if 'amzn2-ami-hvm' in img.get('Name', '')]
            ubuntu_images = [img for img in images if 'ubuntu' in img.get('Name', '')]
            
            # Format the response
            os_list = []
            
            # Add newest Amazon Linux
            if amazon_linux:
                amazon_linux_latest = amazon_linux[0]
                os_list.append({
                    'id': amazon_linux_latest.get('ImageId'),
                    'name': 'Amazon Linux 2',
                    'distribution': 'Amazon Linux',
                    'description': f"Amazon Linux 2 - {amazon_linux_latest.get('Description', '')}",
                    'creation_date': amazon_linux_latest.get('CreationDate')
                })
            
            # Process Ubuntu images to get latest of each release
            ubuntu_versions = {}
            for img in ubuntu_images:
                name = img.get('Name', '')
                match = re.search(r'ubuntu-(\d+\.\d+)', name)
                if match:
                    version = match.group(1)
                    if version not in ubuntu_versions:
                        ubuntu_versions[version] = img
            
            # Add Ubuntu versions
            for version, img in ubuntu_versions.items():
                os_list.append({
                    'id': img.get('ImageId'),
                    'name': f"Ubuntu {version} LTS",
                    'distribution': 'Ubuntu',
                    'description': f"Ubuntu {version} LTS - {img.get('Description', '')}",
                    'creation_date': img.get('CreationDate')
                })
            
            return {
                'success': True,
                'message': f"Found {len(os_list)} available operating systems",
                'data': os_list
            }
        except Exception as e:
            logger.error(f"Error getting AWS AMIs: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def create_server(self, name, plan_id, os_id, region=None, ssh_keys=None):
        """Create a new EC2 instance"""
        try:
            # Use specified region or default
            region_to_use = region or self.region
            
            # Create EC2 client in specified region
            ec2_client = boto3.client(
                'ec2',
                aws_access_key_id=self.api_key,
                aws_secret_access_key=self.api_secret,
                region_name=region_to_use
            )
            
            # Generate random password for Windows instances
            password = None
            if ssh_keys:
                key_name = ssh_keys[0]
            else:
                # Generate a new key pair if none provided
                key_name = f"key-{name}-{uuid.uuid4().hex[:8]}"
                key_response = ec2_client.create_key_pair(KeyName=key_name)
                # In a real implementation, we would store the private key securely
                # and provide it to the user
                logger.info(f"Created new key pair: {key_name}")
                
                # For demo, generate a password that would be encrypted with the key
                import random
                import string
                password = ''.join(random.choices(string.ascii_letters + string.digits, k=12))
            
            # Launch EC2 instance
            response = ec2_client.run_instances(
                ImageId=os_id,
                InstanceType=plan_id,
                MinCount=1,
                MaxCount=1,
                KeyName=key_name,
                TagSpecifications=[
                    {
                        'ResourceType': 'instance',
                        'Tags': [
                            {
                                'Key': 'Name',
                                'Value': name
                            },
                            {
                                'Key': 'CreatedBy',
                                'Value': 'VPS-Control-Panel'
                            }
                        ]
                    }
                ],
                # For production, you would configure security groups, networking, etc.
            )
            
            instance = response['Instances'][0]
            instance_id = instance['InstanceId']
            
            # Wait for the instance to be running
            ec2_client.get_waiter('instance_running').wait(InstanceIds=[instance_id])
            
            # Get instance details
            instance_info = ec2_client.describe_instances(InstanceIds=[instance_id])
            instance = instance_info['Reservations'][0]['Instances'][0]
            
            # Get public IP address
            public_ip = instance.get('PublicIpAddress')
            
            # Determine username based on the OS
            # This is a simplification - in reality it depends on the specific AMI
            ami_description = self.ec2.describe_images(ImageIds=[os_id])['Images'][0].get('Description', '').lower()
            if 'ubuntu' in ami_description:
                username = 'ubuntu'
            elif 'amazon' in ami_description:
                username = 'ec2-user'
            elif 'centos' in ami_description:
                username = 'centos'
            elif 'debian' in ami_description:
                username = 'admin'
            elif 'windows' in ami_description:
                username = 'Administrator'
            else:
                username = 'ec2-user'  # Default
            
            # Return server information
            server_info = {
                'id': instance_id,
                'name': name,
                'status': instance['State']['Name'],
                'ip_address': public_ip,
                'username': username,
                'password': password,  # Will be None for most cases - just used for Windows
                'ssh_port': 22,
                'ssh_key_name': key_name,
                'creation_time': datetime.utcnow().isoformat()
            }
            
            return {
                'success': True,
                'message': f"Server {name} created successfully with IP {public_ip}",
                'data': server_info
            }
        except Exception as e:
            logger.error(f"Error creating AWS server: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def delete_server(self, server_id):
        """Terminate an EC2 instance"""
        try:
            response = self.ec2.terminate_instances(InstanceIds=[server_id])
            
            terminating_instances = response['TerminatingInstances']
            if terminating_instances:
                instance = terminating_instances[0]
                previous_state = instance['PreviousState']['Name']
                current_state = instance['CurrentState']['Name']
                
                return {
                    'success': True,
                    'message': f"Server {server_id} termination initiated (State change: {previous_state} -> {current_state})",
                    'data': None
                }
            else:
                return {
                    'success': False,
                    'message': f"Failed to terminate server {server_id}",
                    'data': None
                }
        except Exception as e:
            logger.error(f"Error terminating AWS server: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def restart_server(self, server_id):
        """Reboot an EC2 instance"""
        try:
            response = self.ec2.reboot_instances(InstanceIds=[server_id])
            
            return {
                'success': True,
                'message': f"Server {server_id} reboot initiated",
                'data': None
            }
        except Exception as e:
            logger.error(f"Error rebooting AWS server: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def power_on_server(self, server_id):
        """Start an EC2 instance"""
        try:
            response = self.ec2.start_instances(InstanceIds=[server_id])
            
            starting_instances = response['StartingInstances']
            if starting_instances:
                instance = starting_instances[0]
                previous_state = instance['PreviousState']['Name']
                current_state = instance['CurrentState']['Name']
                
                return {
                    'success': True,
                    'message': f"Server {server_id} start initiated (State change: {previous_state} -> {current_state})",
                    'data': None
                }
            else:
                return {
                    'success': False,
                    'message': f"Failed to start server {server_id}",
                    'data': None
                }
        except Exception as e:
            logger.error(f"Error starting AWS server: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def power_off_server(self, server_id):
        """Stop an EC2 instance"""
        try:
            response = self.ec2.stop_instances(InstanceIds=[server_id])
            
            stopping_instances = response['StoppingInstances']
            if stopping_instances:
                instance = stopping_instances[0]
                previous_state = instance['PreviousState']['Name']
                current_state = instance['CurrentState']['Name']
                
                return {
                    'success': True,
                    'message': f"Server {server_id} stop initiated (State change: {previous_state} -> {current_state})",
                    'data': None
                }
            else:
                return {
                    'success': False,
                    'message': f"Failed to stop server {server_id}",
                    'data': None
                }
        except Exception as e:
            logger.error(f"Error stopping AWS server: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_server_details(self, server_id):
        """Get EC2 instance details"""
        try:
            response = self.ec2.describe_instances(InstanceIds=[server_id])
            
            if response['Reservations'] and response['Reservations'][0]['Instances']:
                instance = response['Reservations'][0]['Instances'][0]
                
                # Extract details
                instance_type = instance.get('InstanceType')
                public_ip = instance.get('PublicIpAddress')
                private_ip = instance.get('PrivateIpAddress')
                state = instance.get('State', {}).get('Name')
                launch_time = instance.get('LaunchTime')
                
                # Get image details
                image_id = instance.get('ImageId')
                image_name = None
                if image_id:
                    try:
                        image_response = self.ec2.describe_images(ImageIds=[image_id])
                        if image_response['Images']:
                            image_name = image_response['Images'][0].get('Name')
                    except:
                        # Handle case where image no longer exists
                        pass
                
                # Get tags
                tags = instance.get('Tags', [])
                name_tag = next((tag['Value'] for tag in tags if tag['Key'] == 'Name'), None)
                
                # Format the response
                server_details = {
                    'id': server_id,
                    'name': name_tag or server_id,
                    'status': state,
                    'ip_address': public_ip,
                    'private_ip': private_ip,
                    'instance_type': instance_type,
                    'image_id': image_id,
                    'image_name': image_name,
                    'launch_time': launch_time.isoformat() if launch_time else None,
                    'region': self.region,
                    'tags': {tag['Key']: tag['Value'] for tag in tags},
                }
                
                return {
                    'success': True,
                    'message': f"Server details retrieved for {server_id}",
                    'data': server_details
                }
            else:
                return {
                    'success': False,
                    'message': f"Server {server_id} not found",
                    'data': None
                }
        except Exception as e:
            logger.error(f"Error getting AWS server details: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_server_status(self, server_id):
        """Get EC2 instance status"""
        # Get base details
        details_result = self.get_server_details(server_id)
        if not details_result['success']:
            return details_result
        
        server_details = details_result['data']
        
        # AWS doesn't provide CPU/RAM usage via standard EC2 API
        # You would need to use CloudWatch to get this data
        # Here we'll return just the server state
        
        return {
            'success': True,
            'message': f"Server status retrieved for {server_id}",
            'data': {
                'status': server_details['status'],
                'cpu_usage': None,  # Would need CloudWatch
                'ram_usage': None,  # Would need CloudWatch
                'disk_usage': None,  # Would need CloudWatch
                'uptime': None,     # Could calculate from launch_time
            }
        }


class AzureManager(CloudProviderManager):
    """Azure API integration"""
    
    def __init__(self, api_key, api_secret, region=None):
        self.api_key = api_key
        self.api_secret = api_secret
        self.region = region or 'eastus'  # Default to eastus if not specified
        # In a real implementation, we would use the Azure SDK here
        # For demonstration, we'll simulate the API calls
    
    def test_connection(self):
        """Test connection to Azure API"""
        try:
            # This is simulated for demo purposes
            # In a real implementation, we would use the Azure SDK to test the connection
            return {
                'success': True,
                'message': f"Successfully connected to Azure API in region {self.region}",
                'data': None
            }
        except Exception as e:
            logger.error(f"Error testing Azure connection: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_available_regions(self):
        """Get list of available Azure regions"""
        # Simulated list of Azure regions
        regions = [
            {'slug': 'eastus', 'name': 'East US', 'available': True},
            {'slug': 'westus', 'name': 'West US', 'available': True},
            {'slug': 'westus2', 'name': 'West US 2', 'available': True},
            {'slug': 'eastus2', 'name': 'East US 2', 'available': True},
            {'slug': 'centralus', 'name': 'Central US', 'available': True},
            {'slug': 'northeurope', 'name': 'North Europe', 'available': True},
            {'slug': 'westeurope', 'name': 'West Europe', 'available': True},
            {'slug': 'southeastasia', 'name': 'Southeast Asia', 'available': True},
            {'slug': 'japaneast', 'name': 'Japan East', 'available': True},
            {'slug': 'australiaeast', 'name': 'Australia East', 'available': True}
        ]
        
        return {
            'success': True,
            'message': f"Found {len(regions)} available regions",
            'data': regions
        }
    
    def get_available_plans(self):
        """Get list of available Azure VM sizes"""
        # Simulated list of Azure VM sizes
        vm_sizes = [
            {
                'provider_plan_id': 'Standard_B1s',
                'name': 'B1s',
                'cpu_cores': 1,
                'ram_mb': 1024,
                'disk_gb': 4,
                'bandwidth_gb': 0,
                'price_monthly': 8.76,
                'description': '1 vCPU, 1GB RAM, Burstable'
            },
            {
                'provider_plan_id': 'Standard_B2s',
                'name': 'B2s',
                'cpu_cores': 2,
                'ram_mb': 4096,
                'disk_gb': 8,
                'bandwidth_gb': 0,
                'price_monthly': 34.96,
                'description': '2 vCPU, 4GB RAM, Burstable'
            },
            {
                'provider_plan_id': 'Standard_D2s_v3',
                'name': 'D2s v3',
                'cpu_cores': 2,
                'ram_mb': 8192,
                'disk_gb': 16,
                'bandwidth_gb': 0,
                'price_monthly': 91.98,
                'description': '2 vCPU, 8GB RAM, General Purpose'
            },
            {
                'provider_plan_id': 'Standard_D4s_v3',
                'name': 'D4s v3',
                'cpu_cores': 4,
                'ram_mb': 16384,
                'disk_gb': 32,
                'bandwidth_gb': 0,
                'price_monthly': 183.96,
                'description': '4 vCPU, 16GB RAM, General Purpose'
            },
            {
                'provider_plan_id': 'Standard_E2s_v3',
                'name': 'E2s v3',
                'cpu_cores': 2,
                'ram_mb': 16384,
                'disk_gb': 32,
                'bandwidth_gb': 0,
                'price_monthly': 131.40,
                'description': '2 vCPU, 16GB RAM, Memory Optimized'
            },
            {
                'provider_plan_id': 'Standard_F2s_v2',
                'name': 'F2s v2',
                'cpu_cores': 2,
                'ram_mb': 4096,
                'disk_gb': 16,
                'bandwidth_gb': 0,
                'price_monthly': 84.96,
                'description': '2 vCPU, 4GB RAM, Compute Optimized'
            }
        ]
        
        return {
            'success': True,
            'message': f"Found {len(vm_sizes)} available plans",
            'data': vm_sizes
        }
    
    def get_available_os(self):
        """Get list of available Azure VM images"""
        # Simulated list of Azure VM images
        images = [
            {
                'id': 'UbuntuServer:18.04-LTS:latest',
                'name': 'Ubuntu Server 18.04 LTS',
                'distribution': 'Ubuntu',
                'description': 'Ubuntu Server 18.04 LTS',
                'publisher': 'Canonical'
            },
            {
                'id': 'UbuntuServer:20.04-LTS:latest',
                'name': 'Ubuntu Server 20.04 LTS',
                'distribution': 'Ubuntu',
                'description': 'Ubuntu Server 20.04 LTS',
                'publisher': 'Canonical'
            },
            {
                'id': 'WindowsServer:2019-Datacenter:latest',
                'name': 'Windows Server 2019 Datacenter',
                'distribution': 'Windows',
                'description': 'Windows Server 2019 Datacenter',
                'publisher': 'Microsoft'
            },
            {
                'id': 'WindowsServer:2016-Datacenter:latest',
                'name': 'Windows Server 2016 Datacenter',
                'distribution': 'Windows',
                'description': 'Windows Server 2016 Datacenter',
                'publisher': 'Microsoft'
            },
            {
                'id': 'Debian:10:latest',
                'name': 'Debian 10',
                'distribution': 'Debian',
                'description': 'Debian 10',
                'publisher': 'Debian'
            },
            {
                'id': 'CentOS:7.7:latest',
                'name': 'CentOS 7.7',
                'distribution': 'CentOS',
                'description': 'CentOS-based 7.7',
                'publisher': 'OpenLogic'
            }
        ]
        
        return {
            'success': True,
            'message': f"Found {len(images)} available operating systems",
            'data': images
        }
    
    def create_server(self, name, plan_id, os_id, region=None, ssh_keys=None):
        """Create a new Azure VM"""
        # This is a simulated implementation
        try:
            # Use specified region or default
            region_to_use = region or self.region
            
            # Generate a UUID for the VM
            vm_id = str(uuid.uuid4())
            
            # Generate a password for the VM
            import random
            import string
            password = ''.join(random.choices(string.ascii_letters + string.digits + string.punctuation, k=16))
            
            # Simulate VM creation process
            time.sleep(2)
            
            # Simulate IP address assignment
            ip_address = f"40.{random.randint(70, 90)}.{random.randint(1, 254)}.{random.randint(1, 254)}"
            
            # Determine username based on OS
            if 'ubuntu' in os_id.lower():
                username = 'azureuser'
            elif 'debian' in os_id.lower():
                username = 'admin'
            elif 'centos' in os_id.lower():
                username = 'centos'
            elif 'windows' in os_id.lower():
                username = 'Administrator'
            else:
                username = 'azureuser'
            
            # Return server information
            server_info = {
                'id': vm_id,
                'name': name,
                'status': 'running',
                'ip_address': ip_address,
                'username': username,
                'password': password,
                'ssh_port': 22,
                'creation_time': datetime.utcnow().isoformat(),
                'region': region_to_use,
                'plan': plan_id,
                'os': os_id
            }
            
            return {
                'success': True,
                'message': f"Server {name} created successfully with IP {ip_address}",
                'data': server_info
            }
        except Exception as e:
            logger.error(f"Error creating Azure VM: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def delete_server(self, server_id):
        """Delete an Azure VM"""
        # Simulated implementation
        try:
            # Simulate VM deletion process
            time.sleep(1)
            
            return {
                'success': True,
                'message': f"Server {server_id} deletion initiated",
                'data': None
            }
        except Exception as e:
            logger.error(f"Error deleting Azure VM: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def restart_server(self, server_id):
        """Restart an Azure VM"""
        # Simulated implementation
        try:
            # Simulate VM restart process
            time.sleep(1)
            
            return {
                'success': True,
                'message': f"Server {server_id} restart initiated",
                'data': None
            }
        except Exception as e:
            logger.error(f"Error restarting Azure VM: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def power_on_server(self, server_id):
        """Start an Azure VM"""
        # Simulated implementation
        try:
            # Simulate VM start process
            time.sleep(1)
            
            return {
                'success': True,
                'message': f"Server {server_id} start initiated",
                'data': None
            }
        except Exception as e:
            logger.error(f"Error starting Azure VM: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def power_off_server(self, server_id):
        """Stop an Azure VM"""
        # Simulated implementation
        try:
            # Simulate VM stop process
            time.sleep(1)
            
            return {
                'success': True,
                'message': f"Server {server_id} stop initiated",
                'data': None
            }
        except Exception as e:
            logger.error(f"Error stopping Azure VM: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_server_details(self, server_id):
        """Get Azure VM details"""
        # Simulated implementation
        try:
            # Simulate VM details retrieval
            # In a real implementation, we would query the Azure API
            
            # Create random details for demo
            import random
            
            server_details = {
                'id': server_id,
                'name': f"vm-{server_id[:8]}",
                'status': random.choice(['running', 'stopped']),
                'ip_address': f"40.{random.randint(70, 90)}.{random.randint(1, 254)}.{random.randint(1, 254)}",
                'size': random.choice(['Standard_B1s', 'Standard_B2s', 'Standard_D2s_v3']),
                'location': self.region,
                'os_type': random.choice(['Linux', 'Windows']),
                'creation_time': (datetime.utcnow() - timedelta(days=random.randint(1, 30))).isoformat()
            }
            
            return {
                'success': True,
                'message': f"Server details retrieved for {server_id}",
                'data': server_details
            }
        except Exception as e:
            logger.error(f"Error getting Azure VM details: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_server_status(self, server_id):
        """Get Azure VM status"""
        # Simulated implementation
        try:
            # Get base details
            details_result = self.get_server_details(server_id)
            if not details_result['success']:
                return details_result
            
            server_details = details_result['data']
            
            # Generate random usage statistics for demo
            # In a real implementation, we would use the Azure Monitor API
            status_data = {
                'status': server_details['status'],
                'cpu_usage': round(random.uniform(5, 95), 2) if server_details['status'] == 'running' else 0,
                'ram_usage': round(random.uniform(20, 80), 2) if server_details['status'] == 'running' else 0,
                'disk_usage': round(random.uniform(10, 70), 2) if server_details['status'] == 'running' else 0,
                'uptime': random.randint(1, 30 * 24 * 60 * 60) if server_details['status'] == 'running' else 0  # Up to 30 days in seconds
            }
            
            return {
                'success': True,
                'message': f"Server status retrieved for {server_id}",
                'data': status_data
            }
        except Exception as e:
            logger.error(f"Error getting Azure VM status: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }


class GoogleCloudManager(CloudProviderManager):
    """Google Cloud Platform API integration"""
    
    def __init__(self, api_key, api_secret, region=None):
        self.api_key = api_key
        self.api_secret = api_secret
        self.region = region or 'us-central1'  # Default to us-central1 if not specified
        # In a real implementation, we would use the Google Cloud SDK here
        # For demonstration, we'll simulate the API calls
    
    def test_connection(self):
        """Test connection to GCP API"""
        try:
            # This is simulated for demo purposes
            # In a real implementation, we would use the GCP SDK to test the connection
            return {
                'success': True,
                'message': f"Successfully connected to Google Cloud API in region {self.region}",
                'data': None
            }
        except Exception as e:
            logger.error(f"Error testing GCP connection: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_available_regions(self):
        """Get list of available GCP regions"""
        # Simulated list of GCP regions
        regions = [
            {'slug': 'us-central1', 'name': 'Iowa (us-central1)', 'available': True},
            {'slug': 'us-east1', 'name': 'South Carolina (us-east1)', 'available': True},
            {'slug': 'us-east4', 'name': 'Northern Virginia (us-east4)', 'available': True},
            {'slug': 'us-west1', 'name': 'Oregon (us-west1)', 'available': True},
            {'slug': 'us-west2', 'name': 'Los Angeles (us-west2)', 'available': True},
            {'slug': 'us-west3', 'name': 'Salt Lake City (us-west3)', 'available': True},
            {'slug': 'us-west4', 'name': 'Las Vegas (us-west4)', 'available': True},
            {'slug': 'europe-west1', 'name': 'Belgium (europe-west1)', 'available': True},
            {'slug': 'europe-west2', 'name': 'London (europe-west2)', 'available': True},
            {'slug': 'europe-west3', 'name': 'Frankfurt (europe-west3)', 'available': True},
            {'slug': 'europe-west4', 'name': 'Netherlands (europe-west4)', 'available': True},
            {'slug': 'asia-east1', 'name': 'Taiwan (asia-east1)', 'available': True},
            {'slug': 'asia-southeast1', 'name': 'Singapore (asia-southeast1)', 'available': True}
        ]
        
        return {
            'success': True,
            'message': f"Found {len(regions)} available regions",
            'data': regions
        }
    
    def get_available_plans(self):
        """Get list of available GCP machine types"""
        # Simulated list of GCP machine types
        machine_types = [
            {
                'provider_plan_id': 'e2-micro',
                'name': 'E2 Micro',
                'cpu_cores': 0.25,  # Shared core
                'ram_mb': 1024,
                'disk_gb': 10,
                'bandwidth_gb': 0,
                'price_monthly': 8.03,
                'description': '0.25 vCPU, 1GB RAM, Shared Core'
            },
            {
                'provider_plan_id': 'e2-small',
                'name': 'E2 Small',
                'cpu_cores': 0.5,  # Shared core
                'ram_mb': 2048,
                'disk_gb': 10,
                'bandwidth_gb': 0,
                'price_monthly': 15.33,
                'description': '0.5 vCPU, 2GB RAM, Shared Core'
            },
            {
                'provider_plan_id': 'e2-medium',
                'name': 'E2 Medium',
                'cpu_cores': 1,
                'ram_mb': 4096,
                'disk_gb': 10,
                'bandwidth_gb': 0,
                'price_monthly': 30.37,
                'description': '1 vCPU, 4GB RAM'
            },
            {
                'provider_plan_id': 'e2-standard-2',
                'name': 'E2 Standard 2',
                'cpu_cores': 2,
                'ram_mb': 8192,
                'disk_gb': 10,
                'bandwidth_gb': 0,
                'price_monthly': 60.74,
                'description': '2 vCPU, 8GB RAM'
            },
            {
                'provider_plan_id': 'e2-standard-4',
                'name': 'E2 Standard 4',
                'cpu_cores': 4,
                'ram_mb': 16384,
                'disk_gb': 10,
                'bandwidth_gb': 0,
                'price_monthly': 121.48,
                'description': '4 vCPU, 16GB RAM'
            },
            {
                'provider_plan_id': 'n2-standard-2',
                'name': 'N2 Standard 2',
                'cpu_cores': 2,
                'ram_mb': 8192,
                'disk_gb': 10,
                'bandwidth_gb': 0,
                'price_monthly': 76.28,
                'description': '2 vCPU, 8GB RAM, Intel Cascade Lake'
            }
        ]
        
        return {
            'success': True,
            'message': f"Found {len(machine_types)} available plans",
            'data': machine_types
        }
    
    def get_available_os(self):
        """Get list of available GCP OS images"""
        # Simulated list of GCP OS images
        images = [
            {
                'id': 'projects/debian-cloud/global/images/family/debian-10',
                'name': 'Debian 10',
                'distribution': 'Debian',
                'description': 'Debian GNU/Linux 10 (Buster)',
                'family': 'debian-10'
            },
            {
                'id': 'projects/debian-cloud/global/images/family/debian-11',
                'name': 'Debian 11',
                'distribution': 'Debian',
                'description': 'Debian GNU/Linux 11 (Bullseye)',
                'family': 'debian-11'
            },
            {
                'id': 'projects/ubuntu-os-cloud/global/images/family/ubuntu-2004-lts',
                'name': 'Ubuntu 20.04 LTS',
                'distribution': 'Ubuntu',
                'description': 'Ubuntu 20.04 LTS',
                'family': 'ubuntu-2004-lts'
            },
            {
                'id': 'projects/ubuntu-os-cloud/global/images/family/ubuntu-2204-lts',
                'name': 'Ubuntu 22.04 LTS',
                'distribution': 'Ubuntu',
                'description': 'Ubuntu 22.04 LTS',
                'family': 'ubuntu-2204-lts'
            },
            {
                'id': 'projects/centos-cloud/global/images/family/centos-7',
                'name': 'CentOS 7',
                'distribution': 'CentOS',
                'description': 'CentOS 7',
                'family': 'centos-7'
            },
            {
                'id': 'projects/rocky-linux-cloud/global/images/family/rocky-linux-8',
                'name': 'Rocky Linux 8',
                'distribution': 'Rocky Linux',
                'description': 'Rocky Linux 8',
                'family': 'rocky-linux-8'
            },
            {
                'id': 'projects/windows-cloud/global/images/family/windows-2019',
                'name': 'Windows Server 2019',
                'distribution': 'Windows',
                'description': 'Windows Server 2019 Datacenter',
                'family': 'windows-2019'
            }
        ]
        
        return {
            'success': True,
            'message': f"Found {len(images)} available operating systems",
            'data': images
        }
    
    def create_server(self, name, plan_id, os_id, region=None, ssh_keys=None):
        """Create a new GCP VM instance"""
        # This is a simulated implementation
        try:
            # Use specified region or default
            region_to_use = region or self.region
            
            # Generate a UUID for the VM
            vm_id = str(uuid.uuid4())
            
            # Generate a password for the VM
            import random
            import string
            password = ''.join(random.choices(string.ascii_letters + string.digits, k=12))
            
            # Simulate VM creation process
            time.sleep(2)
            
            # Simulate IP address assignment
            ip_address = f"35.{random.randint(190, 240)}.{random.randint(1, 254)}.{random.randint(1, 254)}"
            
            # Determine username based on OS
            if 'ubuntu' in os_id.lower():
                username = 'ubuntu'
            elif 'debian' in os_id.lower():
                username = 'debian'
            elif 'centos' in os_id.lower() or 'rocky' in os_id.lower():
                username = 'centos'
            elif 'windows' in os_id.lower():
                username = 'Administrator'
            else:
                username = 'admin'
            
            # Return server information
            server_info = {
                'id': vm_id,
                'name': name,
                'status': 'RUNNING',
                'ip_address': ip_address,
                'username': username,
                'password': password if 'windows' in os_id.lower() else None,
                'ssh_port': 22,
                'creation_time': datetime.utcnow().isoformat(),
                'region': region_to_use,
                'machine_type': plan_id,
                'image': os_id
            }
            
            return {
                'success': True,
                'message': f"Server {name} created successfully with IP {ip_address}",
                'data': server_info
            }
        except Exception as e:
            logger.error(f"Error creating GCP VM: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def delete_server(self, server_id):
        """Delete a GCP VM instance"""
        # Simulated implementation
        try:
            # Simulate VM deletion process
            time.sleep(1)
            
            return {
                'success': True,
                'message': f"Server {server_id} deletion initiated",
                'data': None
            }
        except Exception as e:
            logger.error(f"Error deleting GCP VM: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def restart_server(self, server_id):
        """Restart a GCP VM instance"""
        # Simulated implementation
        try:
            # Simulate VM restart process
            time.sleep(1)
            
            return {
                'success': True,
                'message': f"Server {server_id} restart initiated",
                'data': None
            }
        except Exception as e:
            logger.error(f"Error restarting GCP VM: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def power_on_server(self, server_id):
        """Start a GCP VM instance"""
        # Simulated implementation
        try:
            # Simulate VM start process
            time.sleep(1)
            
            return {
                'success': True,
                'message': f"Server {server_id} start initiated",
                'data': None
            }
        except Exception as e:
            logger.error(f"Error starting GCP VM: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def power_off_server(self, server_id):
        """Stop a GCP VM instance"""
        # Simulated implementation
        try:
            # Simulate VM stop process
            time.sleep(1)
            
            return {
                'success': True,
                'message': f"Server {server_id} stop initiated",
                'data': None
            }
        except Exception as e:
            logger.error(f"Error stopping GCP VM: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_server_details(self, server_id):
        """Get GCP VM instance details"""
        # Simulated implementation
        try:
            # Simulate VM details retrieval
            # In a real implementation, we would query the GCP API
            
            # Create random details for demo
            import random
            
            server_details = {
                'id': server_id,
                'name': f"vm-{server_id[:8]}",
                'status': random.choice(['RUNNING', 'TERMINATED']),
                'ip_address': f"35.{random.randint(190, 240)}.{random.randint(1, 254)}.{random.randint(1, 254)}",
                'machine_type': random.choice(['e2-micro', 'e2-small', 'e2-medium', 'e2-standard-2']),
                'zone': f"{self.region}-{random.choice(['a', 'b', 'c'])}",
                'creation_time': (datetime.utcnow() - timedelta(days=random.randint(1, 30))).isoformat()
            }
            
            return {
                'success': True,
                'message': f"Server details retrieved for {server_id}",
                'data': server_details
            }
        except Exception as e:
            logger.error(f"Error getting GCP VM details: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }
    
    def get_server_status(self, server_id):
        """Get GCP VM instance status"""
        # Simulated implementation
        try:
            # Get base details
            details_result = self.get_server_details(server_id)
            if not details_result['success']:
                return details_result
            
            server_details = details_result['data']
            
            # Generate random usage statistics for demo
            # In a real implementation, we would use the GCP Monitoring API
            status_data = {
                'status': server_details['status'],
                'cpu_usage': round(random.uniform(5, 95), 2) if server_details['status'] == 'RUNNING' else 0,
                'ram_usage': round(random.uniform(20, 80), 2) if server_details['status'] == 'RUNNING' else 0,
                'disk_usage': round(random.uniform(10, 70), 2) if server_details['status'] == 'RUNNING' else 0,
                'uptime': random.randint(1, 30 * 24 * 60 * 60) if server_details['status'] == 'RUNNING' else 0  # Up to 30 days in seconds
            }
            
            return {
                'success': True,
                'message': f"Server status retrieved for {server_id}",
                'data': status_data
            }
        except Exception as e:
            logger.error(f"Error getting GCP VM status: {str(e)}")
            return {
                'success': False,
                'message': f"Error: {str(e)}",
                'data': None
            }


def get_provider_manager(provider):
    """Factory function to get the appropriate provider manager"""
    if provider.provider_type == 'digitalocean':
        return DigitalOceanManager(provider.api_key, provider.region)
    elif provider.provider_type == 'aws':
        return AWSManager(provider.api_key, provider.api_secret, provider.region)
    elif provider.provider_type == 'azure':
        return AzureManager(provider.api_key, provider.api_secret, provider.region)
    elif provider.provider_type == 'gcp' or provider.provider_type == 'google':
        return GoogleCloudManager(provider.api_key, provider.api_secret, provider.region)
    else:
        logger.error(f"Unsupported provider type: {provider.provider_type}")
        raise ValueError(f"Unsupported provider type: {provider.provider_type}")