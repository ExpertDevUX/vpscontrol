import os
import logging
import base64
from io import BytesIO
from datetime import datetime

from reportlab.lib.pagesizes import letter
from reportlab.lib import colors
from reportlab.lib.units import inch
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, Image
from reportlab.pdfgen import canvas

from models import Invoice, InvoiceItem, User, Transaction

logger = logging.getLogger(__name__)

# Company details for invoice
COMPANY_NAME = os.environ.get('COMPANY_NAME', 'VPS Control Panel, Inc.')
COMPANY_ADDRESS = os.environ.get('COMPANY_ADDRESS', '123 Server Street, Cloud City, CC 12345')
COMPANY_PHONE = os.environ.get('COMPANY_PHONE', '+1 (555) 123-4567')
COMPANY_EMAIL = os.environ.get('COMPANY_EMAIL', 'billing@vpscontrolpanel.com')
COMPANY_WEBSITE = os.environ.get('COMPANY_WEBSITE', 'www.vpscontrolpanel.com')
COMPANY_VAT = os.environ.get('COMPANY_VAT', 'VAT: 123456789')

# Path to signature image - store a base64 encoded signature for better portability
DEFAULT_SIGNATURE = """
iVBORw0KGgoAAAANSUhEUgAAAMgAAAA2CAYAAACLRp/vAAAACXBIWXMAAA7EAAAOxAGVKw4bAAABhGlDQ1BJQ0MgcHJvZmlsZQAAKJF9
kT1Iw0AcxV9TpVUqDnYQcchQnSyIijhqFYpQIdQKrTqYXPoFTRqSFBdHwbXg4Mdi1cHFWVcHV0EQ/AA6OTkpukiJ/0sKLWI8OO7Hu3uP
u3eAUC8zzeoYBzTdNlOJuJjJroqhVwQRQAQCGZaZZcxJUhK+4+seAb7exXiW/7k/R6+asxgQEInnmGHaxBvE05u2wXmfOMKKskp8Tjxm
0gWJH7muePzGueCywDMjZjo1TxwhFgttrLQxK5oa8RRxVNV0yhcyHquctzhr5Spr3pO/MJzTl5e4TnMICSxiCRJEKKiihDJsxGjVSbGQ
ov24j3/A9UvkUshVAiPHAirQILt+8D/43a2Vn5zwksJxoPPFcT5GgNAu0Kg5zvex4zROgOAzcKW3/JU6MPNJeq2lxY6A3m3g4rqlKXvA
5Q4w+GTIpuxKQZpCPg+8n9E3ZYH+W6B7ze2tuY/TByBNXSVvgINDYLRA2es+7+5u7+3fM83+fgByFXKFxhAraw==
"""

def generate_invoice_pdf(invoice_id):
    """
    Generate a PDF invoice for the given invoice ID
    
    Args:
        invoice_id (int): ID of the invoice to generate
        
    Returns:
        BytesIO: PDF file as a BytesIO object
    """
    try:
        # Get invoice data
        invoice = Invoice.query.get(invoice_id)
        if not invoice:
            raise ValueError(f"Invoice with ID {invoice_id} not found")
        
        # Get customer data
        customer = User.query.get(invoice.user_id)
        if not customer:
            raise ValueError(f"Customer with ID {invoice.user_id} not found")
        
        # Get invoice items
        items = InvoiceItem.query.filter_by(invoice_id=invoice_id).all()
        
        # Get transactions
        transactions = Transaction.query.filter_by(invoice_id=invoice_id).all()
        
        # Create PDF buffer
        buffer = BytesIO()
        
        # Create the PDF document
        doc = SimpleDocTemplate(
            buffer,
            pagesize=letter,
            rightMargin=0.5*inch,
            leftMargin=0.5*inch,
            topMargin=0.5*inch,
            bottomMargin=0.5*inch,
            title=f"Invoice #{invoice.invoice_number}"
        )
        
        # Get styles
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(
            name='RightAlign',
            parent=styles['Normal'],
            alignment=2  # 2 = right aligned
        ))
        styles.add(ParagraphStyle(
            name='CenterAlign',
            parent=styles['Normal'],
            alignment=1  # 1 = center aligned
        ))
        styles.add(ParagraphStyle(
            name='InvoiceTitle',
            parent=styles['Heading1'],
            fontSize=16,
            alignment=1
        ))
        
        # Prepare the content
        content = []
        
        # Header with company and invoice information
        header_data = [
            [Paragraph(f"<font size='14'><b>{COMPANY_NAME}</b></font>", styles['Normal']), 
             Paragraph("<font size='14'><b>INVOICE</b></font>", styles['RightAlign'])],
            [Paragraph(COMPANY_ADDRESS, styles['Normal']), 
             Paragraph(f"<b>Invoice #:</b> {invoice.invoice_number}", styles['RightAlign'])],
            [Paragraph(f"Phone: {COMPANY_PHONE}", styles['Normal']), 
             Paragraph(f"<b>Date:</b> {invoice.issue_date.strftime('%Y-%m-%d')}", styles['RightAlign'])],
            [Paragraph(f"Email: {COMPANY_EMAIL}", styles['Normal']), 
             Paragraph(f"<b>Due Date:</b> {invoice.due_date.strftime('%Y-%m-%d')}", styles['RightAlign'])],
            [Paragraph(f"Website: {COMPANY_WEBSITE}", styles['Normal']), 
             Paragraph(f"<b>Status:</b> {invoice.status.upper()}", styles['RightAlign'])],
            [Paragraph(COMPANY_VAT, styles['Normal']), ""]
        ]
        
        header_table = Table(header_data, colWidths=[4*inch, 3*inch])
        header_table.setStyle(TableStyle([
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('BOTTOMPADDING', (0,0), (-1,-1), 5),
        ]))
        content.append(header_table)
        content.append(Spacer(1, 0.3*inch))
        
        # Customer information
        customer_info = [
            [Paragraph("<font size='12'><b>Bill To:</b></font>", styles['Normal'])],
            [Paragraph(f"<b>{customer.first_name} {customer.last_name}</b>", styles['Normal'])],
            [Paragraph(customer.company_name if customer.company_name else "", styles['Normal'])],
            [Paragraph(customer.address if customer.address else "", styles['Normal'])],
            [Paragraph(f"{customer.city}, {customer.state} {customer.zip_code}" if customer.city else "", styles['Normal'])],
            [Paragraph(customer.country if customer.country else "", styles['Normal'])],
            [Paragraph(f"Email: {customer.email}", styles['Normal'])],
            [Paragraph(f"Phone: {customer.phone}" if customer.phone else "", styles['Normal'])]
        ]
        
        customer_table = Table(customer_info, colWidths=[7*inch])
        customer_table.setStyle(TableStyle([
            ('VALIGN', (0,0), (-1,-1), 'TOP'),
            ('BOTTOMPADDING', (0,0), (-1,-1), 2),
        ]))
        content.append(customer_table)
        content.append(Spacer(1, 0.3*inch))
        
        # Invoice items
        item_data = [["#", "Description", "Quantity", "Unit Price", "Amount"]]
        
        total = 0
        for i, item in enumerate(items):
            amount = item.amount * item.quantity
            total += amount
            item_data.append([
                str(i+1),
                item.description,
                str(item.quantity),
                f"${item.amount:.2f}",
                f"${amount:.2f}"
            ])
        
        # Add tax amount if applicable
        if invoice.tax_amount > 0:
            item_data.append(["", "", "", "Subtotal:", f"${total:.2f}"])
            item_data.append(["", "", "", "Tax:", f"${invoice.tax_amount:.2f}"])
            total = invoice.total_amount
        
        # Add total row
        item_data.append(["", "", "", "<b>Total:</b>", f"<b>${total:.2f}</b>"])
        
        # Create the table
        item_table = Table(item_data, colWidths=[0.3*inch, 3.7*inch, 0.8*inch, 1*inch, 1*inch])
        item_table.setStyle(TableStyle([
            ('BACKGROUND', (0,0), (-1,0), colors.lightgrey),
            ('TEXTCOLOR', (0,0), (-1,0), colors.black),
            ('ALIGN', (0,0), (-1,0), 'CENTER'),
            ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
            ('FONTSIZE', (0,0), (-1,0), 10),
            ('BOTTOMPADDING', (0,0), (-1,0), 12),
            ('BACKGROUND', (0,1), (-1,-1), colors.white),
            ('GRID', (0,0), (-1,-4), 0.5, colors.grey),
            ('ALIGN', (2,1), (-1,-1), 'RIGHT'),
            ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ('FONTSIZE', (0,1), (-1,-1), 9),
            ('BOTTOMPADDING', (0,1), (-1,-1), 6),
        ]))
        content.append(item_table)
        content.append(Spacer(1, 0.3*inch))
        
        # Payment information if paid
        if invoice.status == 'paid' and transactions:
            payment_title = Paragraph("<font size='12'><b>Payment Information</b></font>", styles['Normal'])
            content.append(payment_title)
            content.append(Spacer(1, 0.1*inch))
            
            payment_data = [["Date", "Transaction ID", "Method", "Amount"]]
            
            for transaction in transactions:
                payment_data.append([
                    transaction.transaction_date.strftime('%Y-%m-%d'),
                    transaction.transaction_id,
                    transaction.gateway.title(),
                    f"${transaction.amount:.2f}"
                ])
            
            payment_table = Table(payment_data, colWidths=[1*inch, 3*inch, 1.5*inch, 1.3*inch])
            payment_table.setStyle(TableStyle([
                ('BACKGROUND', (0,0), (-1,0), colors.lightgrey),
                ('TEXTCOLOR', (0,0), (-1,0), colors.black),
                ('ALIGN', (0,0), (-1,0), 'CENTER'),
                ('FONTNAME', (0,0), (-1,0), 'Helvetica-Bold'),
                ('FONTSIZE', (0,0), (-1,0), 10),
                ('BOTTOMPADDING', (0,0), (-1,0), 12),
                ('BACKGROUND', (0,1), (-1,-1), colors.white),
                ('GRID', (0,0), (-1,-1), 0.5, colors.grey),
                ('ALIGN', (3,1), (3,-1), 'RIGHT'),
                ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
                ('FONTSIZE', (0,1), (-1,-1), 9),
                ('BOTTOMPADDING', (0,1), (-1,-1), 6),
            ]))
            content.append(payment_table)
            content.append(Spacer(1, 0.3*inch))
        
        # Notes section
        if invoice.notes:
            notes_title = Paragraph("<font size='12'><b>Notes</b></font>", styles['Normal'])
            content.append(notes_title)
            content.append(Spacer(1, 0.1*inch))
            notes_text = Paragraph(invoice.notes, styles['Normal'])
            content.append(notes_text)
            content.append(Spacer(1, 0.3*inch))
        
        # Add signature if the invoice is paid
        if invoice.status == 'paid':
            content.append(Spacer(1, 0.1*inch))
            
            # Signature and thank you text
            signature_data = [
                [Paragraph("<font size='10'><b>Thank you for your business!</b></font>", styles['CenterAlign'])],
                [Spacer(1, 0.2*inch)]
            ]
            
            # Add signature image
            try:
                signature_img_data = base64.b64decode(DEFAULT_SIGNATURE.strip())
                img = Image(BytesIO(signature_img_data))
                img.drawHeight = 0.5*inch
                img._restrictSize(1.5*inch, 0.5*inch)
                signature_data.append([img])
            except Exception as e:
                logger.error(f"Failed to add signature image: {str(e)}")
                signature_data.append([Paragraph("____________________", styles['CenterAlign'])])
            
            # Add signature name
            signature_data.append([Paragraph("<font size='9'>Authorized Signature</font>", styles['CenterAlign'])])
            
            signature_table = Table(signature_data, colWidths=[7*inch])
            signature_table.setStyle(TableStyle([
                ('ALIGN', (0,0), (-1,-1), 'CENTER'),
                ('VALIGN', (0,0), (-1,-1), 'MIDDLE'),
            ]))
            content.append(signature_table)
        
        # Build the PDF
        doc.build(content)
        
        # Reset buffer position to the beginning
        buffer.seek(0)
        return buffer
    
    except Exception as e:
        logger.error(f"Failed to generate invoice PDF: {str(e)}")
        raise
        
def attach_digital_signature(pdf_buffer):
    """
    Attach a digital signature to the PDF
    In a real implementation, this would use a digital certificate
    
    Args:
        pdf_buffer (BytesIO): PDF buffer to sign
        
    Returns:
        BytesIO: Signed PDF buffer
    """
    try:
        from PyPDF2 import PdfReader, PdfWriter
        import hashlib
        from datetime import datetime
        
        # Create a new buffer for the signed PDF
        signed_buffer = BytesIO()
        
        # Read the original PDF
        reader = PdfReader(pdf_buffer)
        writer = PdfWriter()
        
        # Copy all pages from the original
        for page_num in range(len(reader.pages)):
            writer.add_page(reader.pages[page_num])
            
        # Add metadata
        writer.add_metadata({
            "/SignatureDate": datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S UTC"),
            "/SignatureMethod": "VPS Control Panel PDF Signature",
            "/SignatureLocation": "VPS Control Panel Server",
            "/SignatureReason": "Invoice Authentication"
        })
        
        # Create a digital fingerprint (hash of the content)
        content_hash = hashlib.sha256(pdf_buffer.getvalue()).hexdigest()
        
        # Add signature information to the PDF
        writer.add_metadata({
            "/ContentHash": content_hash,
            "/SignatureProvider": "VPS Control Panel",
            "/SignatureVersion": "1.0"
        })
        
        # Write the signed PDF to the new buffer
        writer.write(signed_buffer)
        signed_buffer.seek(0)
        
        # For demonstration, we could also add a visual signature/stamp to the last page
        # but that would require more complex PDF manipulation
        
        return signed_buffer
        
    except Exception as e:
        logger.error(f"Failed to attach digital signature: {str(e)}")
        # In case of error, return the original file
        pdf_buffer.seek(0)
        return pdf_buffer