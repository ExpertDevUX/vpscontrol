import base64
import os
import re
import logging
import pyotp
import qrcode
import html
from io import BytesIO
import requests
import string
import random
from flask import flash, redirect, url_for, session, request, abort
from functools import wraps
from datetime import datetime, timedelta
from app import db
from models import User

logger = logging.getLogger(__name__)

def generate_2fa_secret():
    """Generate a new secret for 2FA"""
    return pyotp.random_base32()

def get_2fa_qrcode_url(email, secret, issuer_name="VPS Control Panel"):
    """Generate a URL for the QR code"""
    totp = pyotp.TOTP(secret)
    return totp.provisioning_uri(name=email, issuer_name=issuer_name)

def generate_2fa_qrcode(email, secret):
    """Generate QR code as base64 image"""
    qr = qrcode.QRCode(
        version=1,
        error_correction=qrcode.constants.ERROR_CORRECT_L,
        box_size=10,
        border=4,
    )
    qr.add_data(get_2fa_qrcode_url(email, secret))
    qr.make(fit=True)
    
    img = qr.make_image(fill_color="black", back_color="white")
    buffer = BytesIO()
    img.save(buffer, "PNG")
    img_str = base64.b64encode(buffer.getvalue()).decode("utf-8")
    
    return f"data:image/png;base64,{img_str}"

def verify_2fa_code(secret, code):
    """Verify a 2FA code against a secret"""
    totp = pyotp.TOTP(secret)
    return totp.verify(code)

def requires_2fa(f):
    """Decorator to ensure 2FA is completed if enabled"""
    @wraps(f)
    def decorated_function(*args, **kwargs):
        from flask_login import current_user
        
        # Skip if user is not logged in
        if not current_user.is_authenticated:
            return f(*args, **kwargs)
        
        # Skip if 2FA is not enabled for this user
        if not current_user.two_factor_enabled:
            return f(*args, **kwargs)
        
        # Skip if 2FA is already verified for this session
        if session.get('2fa_verified') and session.get('2fa_expiry') > datetime.utcnow().timestamp():
            return f(*args, **kwargs)
        
        # Otherwise redirect to the 2FA verification page
        return redirect(url_for('auth.verify_2fa', next=request.path))
    
    return decorated_function

def verify_captcha(captcha_response, remote_ip=None):
    """Verify reCAPTCHA response from client"""
    captcha_secret = os.environ.get('RECAPTCHA_SECRET_KEY')
    
    if not captcha_secret:
        logger.warning("RECAPTCHA_SECRET_KEY not set, skipping verification")
        return True
    
    if not captcha_response:
        return False
    
    data = {
        'secret': captcha_secret,
        'response': captcha_response
    }
    
    if remote_ip:
        data['remoteip'] = remote_ip
    
    try:
        response = requests.post('https://www.google.com/recaptcha/api/siteverify', data=data)
        result = response.json()
        return result.get('success', False)
    except Exception as e:
        logger.error(f"Error verifying reCAPTCHA: {str(e)}")
        return False

def verify_cloudflare_turnstile(token, remote_ip=None):
    """Verify Cloudflare Turnstile token"""
    secret_key = os.environ.get('CLOUDFLARE_TURNSTILE_SECRET')
    
    if not secret_key:
        logger.warning("CLOUDFLARE_TURNSTILE_SECRET not set, skipping verification")
        return True
    
    if not token:
        return False
    
    data = {
        'secret': secret_key,
        'response': token
    }
    
    if remote_ip:
        data['remoteip'] = remote_ip
    
    try:
        response = requests.post('https://challenges.cloudflare.com/turnstile/v0/siteverify', data=data)
        result = response.json()
        return result.get('success', False)
    except Exception as e:
        logger.error(f"Error verifying Cloudflare Turnstile: {str(e)}")
        return False

def record_login_attempt(user_id, successful, ip_address=None, user_agent=None):
    """Record login attempt for security tracking"""
    from models import LoginAttempt
    
    attempt = LoginAttempt(
        user_id=user_id,
        successful=successful,
        ip_address=ip_address,
        user_agent=user_agent,
        timestamp=datetime.utcnow()
    )
    
    db.session.add(attempt)
    db.session.commit()
    
    # Check for suspicious activity
    if not successful:
        check_for_suspicious_activity(user_id, ip_address)

def check_for_suspicious_activity(user_id, ip_address=None):
    """Check for suspicious login activity and take preventive measures"""
    from models import LoginAttempt
    
    # Get recent failed attempts
    one_hour_ago = datetime.utcnow() - timedelta(hours=1)
    recent_failed_attempts = LoginAttempt.query.filter(
        LoginAttempt.user_id == user_id,
        LoginAttempt.successful == False,
        LoginAttempt.timestamp > one_hour_ago
    ).count()
    
    # Check if there are too many failed attempts (e.g., more than 5 in the last hour)
    if recent_failed_attempts >= 5:
        # Lock the account temporarily
        user = User.query.get(user_id)
        if user:
            user.account_locked = True
            user.account_lock_reason = "Too many failed login attempts"
            user.account_lock_expiry = datetime.utcnow() + timedelta(hours=1)  # Lock for 1 hour
            db.session.commit()
            
            # Notify user (in a real app, this would send an email)
            logger.warning(f"Account locked for user {user_id} due to suspicious activity")
            
            # In a real app, you might also:
            # 1. Send a notification email to the user
            # 2. Add the IP to a blacklist
            # 3. Require additional verification when they try to unlock the account
            # 4. Notify admins of potential breach attempt

def send_security_notification(user_id, event_type, details=None):
    """Send security notification to user (email, SMS, etc.)"""
    user = User.query.get(user_id)
    if not user:
        logger.error(f"Cannot send notification - user {user_id} not found")
        return False
    
    # In a real application, this would send an actual email or SMS
    # For this demo, we'll just log it
    
    event_messages = {
        'login': f"New login to your account on {datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')}",
        'password_change': "Your password was changed recently. If you didn't do this, please contact support immediately.",
        'profile_update': "Your account information was updated recently.",
        'two_factor_enabled': "Two-factor authentication was enabled on your account.",
        'two_factor_disabled': "Two-factor authentication was disabled on your account.",
        'payment_received': f"Payment received: ${details.get('amount', 0)} for invoice #{details.get('invoice_number', '')}",
        'server_provisioned': f"New server provisioned: {details.get('server_name', '')}",
        'server_suspended': f"Server suspended: {details.get('server_name', '')}",
        'server_reactivated': f"Server reactivated: {details.get('server_name', '')}"
    }
    
    message = event_messages.get(event_type, f"Security event: {event_type}")
    if details:
        message += f"\nDetails: {details}"
    
    logger.info(f"Security notification for user {user_id} ({user.email}): {message}")
    
    # Record notification in database
    from models import Notification
    notification = Notification(
        user_id=user_id,
        title=f"Security Alert: {event_type.replace('_', ' ').title()}",
        message=message,
        is_read=False,
        notification_type='security',
        created_at=datetime.utcnow()
    )
    
    db.session.add(notification)
    db.session.commit()
    
    return True

def sanitize_input(value, max_length=None):
    """
    Sanitize user input to prevent XSS attacks
    Returns sanitized string or None if input is unsafe
    """
    if value is None:
        return None
        
    # Convert to string if not already
    if not isinstance(value, str):
        value = str(value)
        
    # Trim to max length if specified
    if max_length and len(value) > max_length:
        value = value[:max_length]
        
    # HTML escape the value to prevent XSS
    value = html.escape(value)
    
    return value

def validate_hostname(hostname):
    """
    Validate hostname format
    Returns True if valid, False otherwise
    """
    if not hostname:
        return False
        
    # Basic hostname validation (letters, numbers, hyphens, periods)
    pattern = r'^[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?(\.[a-zA-Z0-9]([a-zA-Z0-9\-]{0,61}[a-zA-Z0-9])?)*$'
    return bool(re.match(pattern, hostname))

def validate_email(email):
    """
    Validate email format
    Returns True if valid, False otherwise
    """
    if not email:
        return False
        
    # Basic email validation
    pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
    return bool(re.match(pattern, email))

def validate_password_strength(password):
    """
    Validate password strength
    Returns a tuple of (valid, reason) where valid is a boolean
    """
    if not password or len(password) < 8:
        return (False, "Password must be at least 8 characters long")
        
    # Check for at least one uppercase, one lowercase, one digit, and one special character
    has_upper = any(c.isupper() for c in password)
    has_lower = any(c.islower() for c in password)
    has_digit = any(c.isdigit() for c in password)
    has_special = any(c in string.punctuation for c in password)
    
    if not has_upper:
        return (False, "Password must contain at least one uppercase letter")
    if not has_lower:
        return (False, "Password must contain at least one lowercase letter")
    if not has_digit:
        return (False, "Password must contain at least one digit")
    if not has_special:
        return (False, "Password must contain at least one special character")
        
    return (True, "Password meets strength requirements")

def generate_random_password(length=12):
    """
    Generate a strong random password
    """
    # Ensure we have all required character types
    uppercase = random.choice(string.ascii_uppercase)
    lowercase = random.choice(string.ascii_lowercase)
    digit = random.choice(string.digits)
    special = random.choice(string.punctuation)
    
    # Fill the rest with a mix of characters
    remaining_length = length - 4
    all_chars = string.ascii_letters + string.digits + string.punctuation
    remaining = ''.join(random.choice(all_chars) for _ in range(remaining_length))
    
    # Combine and shuffle
    password = uppercase + lowercase + digit + special + remaining
    password_list = list(password)
    random.shuffle(password_list)
    return ''.join(password_list)

def rate_limit_decorator(limit=5, per=60):
    """
    Decorator to apply rate limiting to routes
    limit: maximum number of requests allowed
    per: time period in seconds
    """
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            # Get IP address
            ip = request.remote_addr
            
            # Create rate limit key
            endpoint = request.endpoint
            key = f"rate_limit:{ip}:{endpoint}"
            
            # Get current count from session
            now = datetime.utcnow().timestamp()
            rate_limit_data = session.get(key, {"count": 0, "reset_at": now + per})
            
            # If reset time has passed, reset the counter
            if now > rate_limit_data["reset_at"]:
                rate_limit_data = {"count": 0, "reset_at": now + per}
            
            # Increment count
            rate_limit_data["count"] += 1
            session[key] = rate_limit_data
            
            # Check if rate limit is exceeded
            if rate_limit_data["count"] > limit:
                # Log the rate limit exceeded
                logger.warning(f"Rate limit exceeded for {ip} on {endpoint}")
                
                # Return 429 Too Many Requests
                return "Rate limit exceeded. Please try again later.", 429
            
            # Call the original function
            return f(*args, **kwargs)
        return wrapped
    return decorator

def requires_role(role_name):
    """
    Decorator to ensure user has the required role
    """
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            from flask_login import current_user
            
            # Check if user is logged in
            if not current_user.is_authenticated:
                flash("You must log in to access this page", "warning")
                return redirect(url_for('auth.login', next=request.path))
                
            # Check if user has the required role
            if not current_user.has_role(role_name):
                logger.warning(f"User {current_user.id} attempted to access {request.path} without {role_name} role")
                flash("You don't have permission to access this page", "danger")
                abort(403)
                
            return f(*args, **kwargs)
        return wrapped
    return decorator