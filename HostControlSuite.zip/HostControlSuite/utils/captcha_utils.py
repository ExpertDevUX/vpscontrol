import requests
import logging
import os
from flask import request
from models import Settings

logger = logging.getLogger(__name__)

def verify_turnstile_token(token):
    """
    Verify a Cloudflare Turnstile token
    
    Args:
        token (str): The turnstile token from the client
        
    Returns:
        bool: True if verification successful, False otherwise
    """
    # Check if CAPTCHA is disabled in settings
    captcha_enabled = Settings.get_value('captcha_enabled', 'false').lower() == 'true'
    if not captcha_enabled:
        logger.info("CAPTCHA verification skipped (disabled in settings)")
        return True
    
    if not token:
        logger.warning("No Turnstile token provided")
        return False
        
    # Get the secret key from environment variables
    secret_key = os.environ.get('TURNSTILE_SECRET_KEY')
    if not secret_key:
        logger.error("Turnstile secret key not configured")
        return False
        
    # Get the IP address of the user
    ip = request.remote_addr
    
    # Make the verification request to Cloudflare
    data = {
        'secret': secret_key,
        'response': token,
        'remoteip': ip
    }
    
    try:
        resp = requests.post('https://challenges.cloudflare.com/turnstile/v0/siteverify', data=data)
        result = resp.json()
        
        if result.get('success'):
            logger.info("Turnstile verification successful")
            return True
        else:
            error_codes = result.get('error-codes', [])
            logger.warning(f"Turnstile verification failed: {error_codes}")
            return False
    except Exception as e:
        logger.error(f"Error verifying Turnstile token: {str(e)}")
        return False