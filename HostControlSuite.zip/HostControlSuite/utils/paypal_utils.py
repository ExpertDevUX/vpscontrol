"""
PayPal Payment Processing Utilities
"""
import os
import logging
import json
import requests
from datetime import datetime, timedelta
from models import Transaction, Invoice, Settings
from app import db

logger = logging.getLogger(__name__)

class PayPalAPI:
    """PayPal API integration for payment processing"""
    
    def __init__(self):
        """Initialize PayPal API with configuration from environment variables"""
        # Determine if we're in sandbox mode based on settings
        try:
            sandbox_setting = Settings.get_value('paypal_sandbox', 'true')
            self.sandbox_mode = sandbox_setting.lower() == 'true'
        except RuntimeError:
            # If outside application context, default to true
            logger.warning("Running outside application context, defaulting to sandbox mode")
            self.sandbox_mode = True
        
        # Set the API base URL based on mode
        if self.sandbox_mode:
            self.api_base_url = "https://api-m.sandbox.paypal.com"
        else:
            self.api_base_url = "https://api-m.paypal.com"
            
        # Try to get credentials from database settings first
        try:
            db_client_id = Settings.get_value('paypal_client_id', '')
            db_secret_key = Settings.get_value('paypal_secret_key', '')
            
            # If database settings exist, use them
            if db_client_id and db_secret_key:
                self.client_id = db_client_id
                self.client_secret = db_secret_key
                self.credentials_source = 'database'
                logger.info("Using PayPal credentials from database settings")
            else:
                # Fall back to environment variables
                self.client_id = os.environ.get('PAYPAL_CLIENT_ID')
                self.client_secret = os.environ.get('PAYPAL_SECRET_KEY')
                self.credentials_source = 'environment' if self.client_id and self.client_secret else None
                
                if self.client_id and self.client_secret:
                    logger.info("Using PayPal credentials from environment variables")
        except Exception as e:
            logger.warning(f"Error accessing database settings for PayPal: {str(e)}")
            # Fall back to environment variables
            self.client_id = os.environ.get('PAYPAL_CLIENT_ID')
            self.client_secret = os.environ.get('PAYPAL_SECRET_KEY')
            self.credentials_source = 'environment' if self.client_id and self.client_secret else None
            
            if self.client_id and self.client_secret:
                logger.info("Using PayPal credentials from environment variables (after database error)")
        
        # Check if credentials are configured from either source
        if not self.client_id or not self.client_secret:
            logger.error("PayPal credentials are not configured in database settings or environment variables")
            self.is_configured = False
        else:
            self.is_configured = True
            
        # Token storage
        self.access_token = None
        self.token_expires_at = datetime.utcnow()
    
    def get_access_token(self):
        """
        Get a PayPal OAuth access token
        """
        if not self.is_configured:
            logger.error("Cannot get PayPal access token - credentials not configured")
            return None
            
        # If we already have a valid token, return it
        if self.access_token and self.token_expires_at > datetime.utcnow():
            return self.access_token
            
        # Otherwise, get a new token
        url = f"{self.api_base_url}/v1/oauth2/token"
        headers = {
            "Accept": "application/json",
            "Accept-Language": "en_US"
        }
        data = {
            "grant_type": "client_credentials"
        }
        
        try:
            response = requests.post(
                url, 
                auth=(self.client_id, self.client_secret),
                headers=headers,
                data=data
            )
            
            if response.status_code == 200:
                token_data = response.json()
                self.access_token = token_data.get('access_token')
                # Convert expiry from seconds to datetime
                expires_in = token_data.get('expires_in', 3600)  # Default to 1 hour
                self.token_expires_at = datetime.utcnow() + timedelta(seconds=expires_in - 60)  # 1 minute buffer
                return self.access_token
            else:
                logger.error(f"Failed to get PayPal access token: {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Error getting PayPal access token: {str(e)}")
            return None
    
    def create_order(self, invoice, return_url, cancel_url):
        """
        Create a PayPal order for a given invoice
        
        Args:
            invoice: The Invoice object to create an order for
            return_url: URL to redirect to after successful payment
            cancel_url: URL to redirect to if payment is cancelled
            
        Returns:
            Dictionary with 'id' (order ID) and 'approval_url' (redirect URL) on success,
            None on failure
        """
        if not self.is_configured:
            logger.error("Cannot create PayPal order - credentials not configured")
            return None
            
        # Get access token
        access_token = self.get_access_token()
        if not access_token:
            return None
            
        # Create order
        url = f"{self.api_base_url}/v2/checkout/orders"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {access_token}"
        }
        
        # Format the items in the invoice
        order_items = []
        
        # Add server items
        for server in invoice.servers:
            server_item = {
                "name": f"VPS Server: {server.name or 'Custom Server'}",
                "description": f"{server.cpu_cores} CPU, {server.memory_gb}GB RAM, {server.storage_gb}GB Storage",
                "quantity": "1",
                "unit_amount": {
                    "currency_code": "USD",
                    "value": str(server.price)
                },
                "category": "DIGITAL_GOODS"
            }
            order_items.append(server_item)
            
        # Add any license items
        for license in invoice.licenses:
            license_item = {
                "name": f"License: {license.name or 'Custom License'}",
                "description": f"License key valid for {license.duration_days} days",
                "quantity": "1",
                "unit_amount": {
                    "currency_code": "USD",
                    "value": str(license.price)
                },
                "category": "DIGITAL_GOODS"
            }
            order_items.append(license_item)
        
        # Create the PayPal order request payload
        # Get brand name (company name) safely to avoid application context issues
        try:
            brand_name = Settings.get_value('company_name', 'VPS Control Panel')
        except RuntimeError:
            # If outside application context, use default
            logger.warning("Running outside application context, using default company name")
            brand_name = 'VPS Control Panel'
            
        payload = {
            "intent": "CAPTURE",
            "purchase_units": [
                {
                    "reference_id": f"inv-{invoice.id}",
                    "description": f"Invoice #{invoice.invoice_number}",
                    "amount": {
                        "currency_code": "USD",
                        "value": str(invoice.total_amount),
                        "breakdown": {
                            "item_total": {
                                "currency_code": "USD",
                                "value": str(invoice.total_amount)
                            }
                        }
                    },
                    "items": order_items
                }
            ],
            "application_context": {
                "brand_name": brand_name,
                "landing_page": "BILLING",
                "shipping_preference": "NO_SHIPPING",
                "user_action": "PAY_NOW",
                "return_url": return_url,
                "cancel_url": cancel_url
            }
        }
        
        try:
            response = requests.post(url, headers=headers, data=json.dumps(payload))
            
            if response.status_code in (200, 201):
                order_data = response.json()
                order_id = order_data.get('id')
                
                # Extract the approval URL
                approval_url = None
                for link in order_data.get('links', []):
                    if link.get('rel') == 'approve':
                        approval_url = link.get('href')
                        break
                
                if not approval_url:
                    logger.error(f"Could not find approval URL in PayPal order response: {order_data}")
                    return None
                
                return {
                    'id': order_id,
                    'approval_url': approval_url
                }
            else:
                logger.error(f"Failed to create PayPal order: {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Error creating PayPal order: {str(e)}")
            return None
    
    def capture_order(self, order_id, invoice_id):
        """
        Capture payment for a previously approved PayPal order
        
        Args:
            order_id: The PayPal order ID to capture
            invoice_id: The invoice ID associated with this order
            
        Returns:
            True if capture was successful, False otherwise
        """
        if not self.is_configured:
            logger.error("Cannot capture PayPal order - credentials not configured")
            return False
            
        # Get access token
        access_token = self.get_access_token()
        if not access_token:
            return False
            
        # Capture the order
        url = f"{self.api_base_url}/v2/checkout/orders/{order_id}/capture"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {access_token}"
        }
        
        try:
            response = requests.post(url, headers=headers)
            
            if response.status_code in (200, 201):
                capture_data = response.json()
                capture_status = capture_data.get('status', '').upper()
                
                # Check if the capture was successful
                if capture_status == 'COMPLETED':
                    # Get the transaction details
                    capture_id = None
                    payment_amount = None
                    
                    for purchase_unit in capture_data.get('purchase_units', []):
                        payments = purchase_unit.get('payments', {})
                        captures = payments.get('captures', [])
                        
                        if captures and len(captures) > 0:
                            capture_id = captures[0].get('id')
                            payment_amount = float(captures[0].get('amount', {}).get('value', 0))
                    
                    if not capture_id:
                        logger.error(f"Could not find capture ID in PayPal response: {capture_data}")
                        return False
                    
                    # Get the invoice
                    invoice = Invoice.query.get(invoice_id)
                    if not invoice:
                        logger.error(f"Invoice {invoice_id} not found")
                        return False
                    
                    # Create transaction record
                    transaction = Transaction(
                        transaction_id=capture_id,
                        gateway='paypal',
                        amount=payment_amount,
                        status='success',
                        invoice_id=invoice_id,
                        response_data=json.dumps(capture_data)
                    )
                    
                    # Mark invoice as paid
                    invoice.status = 'paid'
                    invoice.paid_date = datetime.utcnow()
                    
                    db.session.add(transaction)
                    db.session.commit()
                    
                    return True
                else:
                    logger.error(f"PayPal capture has unexpected status: {capture_status}")
                    return False
            else:
                logger.error(f"Failed to capture PayPal order: {response.text}")
                return False
                
        except Exception as e:
            logger.error(f"Error capturing PayPal order: {str(e)}")
            return False
    
    def get_payment_details(self, transaction_id):
        """
        Get details of a PayPal payment/capture
        
        Args:
            transaction_id: The PayPal capture ID
            
        Returns:
            Payment details dictionary or None on failure
        """
        if not self.is_configured:
            logger.error("Cannot get PayPal payment details - credentials not configured")
            return None
            
        # Get access token
        access_token = self.get_access_token()
        if not access_token:
            return None
            
        # Get capture details
        url = f"{self.api_base_url}/v2/payments/captures/{transaction_id}"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {access_token}"
        }
        
        try:
            response = requests.get(url, headers=headers)
            
            if response.status_code == 200:
                return response.json()
            else:
                logger.error(f"Failed to get PayPal payment details: {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Error getting PayPal payment details: {str(e)}")
            return None
    
    def refund_payment(self, transaction_id, amount=None, reason=None):
        """
        Refund a PayPal payment
        
        Args:
            transaction_id: The PayPal capture ID to refund
            amount: Optional amount to refund (if not provided, full amount is refunded)
            reason: Optional reason for the refund
            
        Returns:
            Refund details dictionary or None on failure
        """
        if not self.is_configured:
            logger.error("Cannot process PayPal refund - credentials not configured")
            return None
            
        # Get access token
        access_token = self.get_access_token()
        if not access_token:
            return None
            
        # Prepare the refund
        url = f"{self.api_base_url}/v2/payments/captures/{transaction_id}/refund"
        headers = {
            "Content-Type": "application/json",
            "Authorization": f"Bearer {access_token}"
        }
        
        # Build the payload
        payload = {}
        if amount:
            payload["amount"] = {
                "value": str(amount),
                "currency_code": "USD"
            }
        if reason:
            payload["note_to_payer"] = reason
        
        try:
            response = requests.post(
                url, 
                headers=headers, 
                data=json.dumps(payload) if payload else None
            )
            
            if response.status_code in (200, 201, 202):
                return response.json()
            else:
                logger.error(f"Failed to process PayPal refund: {response.text}")
                return None
                
        except Exception as e:
            logger.error(f"Error processing PayPal refund: {str(e)}")
            return None