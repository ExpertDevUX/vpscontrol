import logging
import random
from datetime import datetime, timedelta

# This module now interfaces with real cloud provider APIs using our cloud_manager module
# It also provides a fallback mock implementation for testing

logger = logging.getLogger(__name__)

def provision_server(hostname, template, operating_system, user_id, billing_cycle='monthly'):
    """
    Provision a new virtual server
    
    This function integrates with cloud providers through the cloud_manager module.
    1. Finds the associated cloud provider for the template
    2. Makes API calls to create a new VM
    3. Returns the connection details
    
    Args:
        hostname: The hostname for the new server
        template: The server template (specs)
        operating_system: The OS to install
        user_id: The user ID who owns this server
        billing_cycle: The billing cycle (monthly, quarterly, semi_annual, annual, biennial, quadrennial)
    
    Returns a dictionary with server details
    """
    logger.info(f"Provisioning server {hostname} with {operating_system} for user {user_id} with {billing_cycle} billing")
    
    # Calculate expiry date based on billing cycle
    expiry_date = calculate_expiry_date(billing_cycle)
    
    # Check if this is a cloud provider template
    if hasattr(template, 'provider') and template.provider:
        # Use the cloud provider integration
        from routes.cloud import provision_server_on_provider
        
        result = provision_server_on_provider(
            provider=template.provider,
            template=template, 
            operating_system=operating_system,
            hostname=hostname,
            user=user_id
        )
        
        # Unpack result safely, handling both tuple unpacking and None result
        if isinstance(result, tuple) and len(result) == 2:
            server_data, error = result
        else:
            server_data, error = None, "Unexpected result from provision_server_on_provider"
        
        if error or not server_data:
            logger.error(f"Error provisioning server with cloud provider: {error}")
            # Fall back to mock implementation
            logger.warning("Falling back to mock server implementation")
            return _provision_mock_server(hostname, template, operating_system, user_id, billing_cycle, expiry_date)
        
        # Add missing fields to server_data, ensuring it's a dict
        if isinstance(server_data, dict):
            server_data['hostname'] = hostname
            server_data['creation_time'] = datetime.utcnow()
            server_data['expiry_date'] = expiry_date
        else:
            logger.error(f"Invalid server_data type: {type(server_data)}")
            return _provision_mock_server(hostname, template, operating_system, user_id, billing_cycle, expiry_date)
        
        logger.info(f"Server {hostname} provisioned successfully with IP {server_data.get('ip_address')}, " + 
                   f"SSH port {server_data.get('ssh_port')}, expires on {expiry_date}")
        
        return server_data
    else:
        # No cloud provider, use mock implementation
        logger.warning(f"No cloud provider found for template {template.name}, using mock implementation")
        return _provision_mock_server(hostname, template, operating_system, user_id, billing_cycle, expiry_date)

def _provision_mock_server(hostname, template, operating_system, user_id, billing_cycle, expiry_date):
    """Mock implementation for testing or when cloud provider isn't available"""
    # Simulate API delay
    import time
    time.sleep(2)
    
    # Generate random connection details for demo
    ip_address = f"192.168.{random.randint(1, 254)}.{random.randint(1, 254)}"
    username = f"user{random.randint(1000, 9999)}"
    password = f"pass{random.randint(1000, 9999)}"
    ssh_port = 22  # Default SSH port, can be randomized for enhanced security
    
    logger.info(f"Server {hostname} provisioned with MOCK implementation: IP {ip_address}, SSH port {ssh_port}")
    
    return {
        'hostname': hostname,
        'ip_address': ip_address,
        'username': username,
        'password': password,
        'ssh_port': ssh_port,
        'status': 'active',
        'creation_time': datetime.utcnow(),
        'expiry_date': expiry_date
    }

def delete_server(server_id):
    """
    Delete a virtual server
    
    This function will:
    1. Check if the server is associated with a cloud provider
    2. If yes, delete via cloud provider API
    3. If no, simulate deletion (mock implementation)
    """
    logger.info(f"Deleting server with ID {server_id}")
    
    # Get the server information
    from models import Server
    server = Server.query.get(server_id)
    
    if not server:
        logger.error(f"Server {server_id} not found")
        return False
    
    # Check if the server has a provider and provider_server_id
    if hasattr(server, 'template') and server.template and hasattr(server.template, 'provider') and server.template.provider:
        provider = server.template.provider
        provider_server_id = getattr(server, 'provider_server_id', None)
        
        if provider_server_id:
            # Use cloud provider API to delete
            from routes.cloud import server_action
            success, message = server_action(provider, provider_server_id, 'delete')
            
            if not success:
                logger.error(f"Error deleting server {server_id} from cloud provider: {message}")
                return False
            
            logger.info(f"Server {server_id} deleted successfully from cloud provider")
            return True
    
    # No cloud provider or provider_server_id, use mock implementation
    logger.warning(f"No cloud provider found for server {server_id}, using mock implementation")
    import time
    time.sleep(2)
    
    return True

def start_server(server_id):
    """
    Start a virtual server
    
    This function will:
    1. Check if the server is associated with a cloud provider
    2. If yes, start via cloud provider API
    3. If no, simulate starting (mock implementation)
    """
    logger.info(f"Starting server with ID {server_id}")
    
    # Get the server information
    from models import Server
    server = Server.query.get(server_id)
    
    if not server:
        logger.error(f"Server {server_id} not found")
        return False
    
    # Check if the server has a provider and provider_server_id
    if hasattr(server, 'template') and server.template and hasattr(server.template, 'provider') and server.template.provider:
        provider = server.template.provider
        provider_server_id = getattr(server, 'provider_server_id', None)
        
        if provider_server_id:
            # Use cloud provider API to start
            from routes.cloud import server_action
            success, message = server_action(provider, provider_server_id, 'start')
            
            if not success:
                logger.error(f"Error starting server {server_id} from cloud provider: {message}")
                return False
            
            logger.info(f"Server {server_id} started successfully from cloud provider")
            return True
    
    # No cloud provider or provider_server_id, use mock implementation
    logger.warning(f"No cloud provider found for server {server_id}, using mock implementation")
    import time
    time.sleep(1)
    
    return True

def stop_server(server_id):
    """
    Stop a virtual server
    
    This function will:
    1. Check if the server is associated with a cloud provider
    2. If yes, stop via cloud provider API
    3. If no, simulate stopping (mock implementation)
    """
    logger.info(f"Stopping server with ID {server_id}")
    
    # Get the server information
    from models import Server
    server = Server.query.get(server_id)
    
    if not server:
        logger.error(f"Server {server_id} not found")
        return False
    
    # Check if the server has a provider and provider_server_id
    if hasattr(server, 'template') and server.template and hasattr(server.template, 'provider') and server.template.provider:
        provider = server.template.provider
        provider_server_id = getattr(server, 'provider_server_id', None)
        
        if provider_server_id:
            # Use cloud provider API to stop
            from routes.cloud import server_action
            success, message = server_action(provider, provider_server_id, 'stop')
            
            if not success:
                logger.error(f"Error stopping server {server_id} from cloud provider: {message}")
                return False
            
            logger.info(f"Server {server_id} stopped successfully from cloud provider")
            return True
    
    # No cloud provider or provider_server_id, use mock implementation
    logger.warning(f"No cloud provider found for server {server_id}, using mock implementation")
    import time
    time.sleep(1)
    
    return True

def restart_server(server_id):
    """
    Restart a virtual server
    
    This function will:
    1. Check if the server is associated with a cloud provider
    2. If yes, restart via cloud provider API
    3. If no, simulate restarting (mock implementation)
    """
    logger.info(f"Restarting server with ID {server_id}")
    
    # Get the server information
    from models import Server
    server = Server.query.get(server_id)
    
    if not server:
        logger.error(f"Server {server_id} not found")
        return False
    
    # Check if the server has a provider and provider_server_id
    if hasattr(server, 'template') and server.template and hasattr(server.template, 'provider') and server.template.provider:
        provider = server.template.provider
        provider_server_id = getattr(server, 'provider_server_id', None)
        
        if provider_server_id:
            # Use cloud provider API to restart
            from routes.cloud import server_action
            success, message = server_action(provider, provider_server_id, 'restart')
            
            if not success:
                logger.error(f"Error restarting server {server_id} from cloud provider: {message}")
                return False
            
            logger.info(f"Server {server_id} restarted successfully from cloud provider")
            return True
    
    # No cloud provider or provider_server_id, use mock implementation
    logger.warning(f"No cloud provider found for server {server_id}, using mock implementation")
    import time
    time.sleep(2)
    
    return True

def get_server_status(server_id):
    """
    Get the current status and resource usage of a server
    
    This function will:
    1. Check if the server is associated with a cloud provider
    2. If yes, get status via cloud provider API
    3. If no, simulate status (mock implementation)
    """
    logger.info(f"Getting status for server with ID {server_id}")
    
    # Get the server information
    from models import Server
    server = Server.query.get(server_id)
    
    if not server:
        logger.error(f"Server {server_id} not found")
        return {
            'status': 'unknown',
            'cpu_usage': 0,
            'ram_usage': 0,
            'disk_usage': 0,
            'network_in': 0,
            'network_out': 0,
            'uptime': 0
        }
    
    # Check if the server has a provider and provider_server_id
    if hasattr(server, 'template') and server.template and hasattr(server.template, 'provider') and server.template.provider:
        provider = server.template.provider
        provider_server_id = getattr(server, 'provider_server_id', None)
        
        if provider_server_id:
            # Use cloud provider API to get status
            from routes.cloud import get_server_info
            result = get_server_info(provider, provider_server_id)
            
            # Unpack result safely, handling both tuple unpacking and None result
            if isinstance(result, tuple) and len(result) == 2:
                server_info, error = result
            else:
                server_info, error = None, "Unexpected result from get_server_info"
            
            if error or not server_info:
                logger.error(f"Error getting server status from cloud provider: {error}")
                # Fall back to mock implementation
                return _get_mock_server_status(server.status)
            
            # Format the data from the cloud provider
            status = server_info.get('status', 'unknown')
            
            # Map provider-specific status to our standard statuses
            if status.lower() in ['running', 'active']:
                status = 'running'
            elif status.lower() in ['stopped', 'off', 'shutdown']:
                status = 'stopped'
            elif status.lower() in ['suspended', 'paused']:
                status = 'suspended'
            elif status.lower() in ['pending', 'provisioning', 'creating']:
                status = 'pending'
            
            # Many cloud providers don't expose CPU/RAM usage via API
            # We'll use the status to determine mock values for these
            if status == 'running':
                cpu_usage = random.uniform(5, 95)
                ram_usage = random.uniform(20, 80)
                disk_usage = random.uniform(10, 70)
                network_in = random.uniform(0, 100)
                network_out = random.uniform(0, 100)
                uptime = server_info.get('uptime', random.randint(1, 30 * 24 * 60 * 60))
            else:
                cpu_usage = 0
                ram_usage = 0
                disk_usage = server_info.get('disk_usage', random.uniform(10, 30))  # Disk usage persists even when powered off
                network_in = 0
                network_out = 0
                uptime = 0
            
            return {
                'status': status,
                'cpu_usage': cpu_usage,
                'ram_usage': ram_usage,
                'disk_usage': disk_usage,
                'network_in': network_in,
                'network_out': network_out,
                'uptime': uptime
            }
    
    # No cloud provider or provider_server_id, use mock implementation
    logger.warning(f"No cloud provider found for server {server_id}, using mock implementation")
    return _get_mock_server_status(server.status)

def _get_mock_server_status(status='running'):
    """Generate mock server status for testing"""
    if status == 'running' or status == 'active':
        return {
            'status': 'running',
            'cpu_usage': random.uniform(5, 95),
            'ram_usage': random.uniform(20, 80),
            'disk_usage': random.uniform(10, 70),
            'network_in': random.uniform(0, 100),
            'network_out': random.uniform(0, 100),
            'uptime': random.randint(1, 30 * 24 * 60 * 60)  # Up to 30 days in seconds
        }
    elif status == 'stopped':
        return {
            'status': 'stopped',
            'cpu_usage': 0,
            'ram_usage': 0,
            'disk_usage': random.uniform(10, 70),  # Disk usage persists when powered off
            'network_in': 0,
            'network_out': 0,
            'uptime': 0
        }
    elif status == 'suspended':
        return {
            'status': 'suspended',
            'cpu_usage': 0,
            'ram_usage': 0,
            'disk_usage': random.uniform(10, 70),  # Disk usage persists when suspended
            'network_in': 0,
            'network_out': 0,
            'uptime': 0
        }
    else:
        return {
            'status': status,
            'cpu_usage': 0,
            'ram_usage': 0,
            'disk_usage': 0,
            'network_in': 0,
            'network_out': 0,
            'uptime': 0
        }

def reinstall_os(server_id, operating_system):
    """
    Reinstall the operating system on a server
    
    This function will:
    1. Check if the server is associated with a cloud provider
    2. If yes, use the cloud provider to rebuild/reinstall the server
    3. If no, simulate the reinstallation process
    """
    logger.info(f"Reinstalling {operating_system} on server with ID {server_id}")
    
    # Get the server information
    from models import Server
    server = Server.query.get(server_id)
    
    if not server:
        logger.error(f"Server {server_id} not found")
        return None
    
    # Check if the server has a provider and provider_server_id
    # Note: Cloud providers often don't support in-place OS reinstallation
    # Usually they require a rebuild/recreate operation, which we simulate here
    if hasattr(server, 'template') and server.template and hasattr(server.template, 'provider') and server.template.provider:
        provider = server.template.provider
        provider_server_id = getattr(server, 'provider_server_id', None)
        
        if provider_server_id:
            logger.info(f"Using cloud provider API to reinstall OS on server {server_id}")
            
            # For most cloud providers, we would:
            # 1. Delete the existing instance (or take a snapshot if needed)
            # 2. Create a new instance with the same specs but different OS
            
            # In a real implementation, this would make API calls to the cloud provider
            # Here, we'll simulate the process
            import time
            time.sleep(5)
            
            # Generate new credentials
            new_password = f"pass{random.randint(1000, 9999)}"
            ssh_port = 22
            
            return {
                'status': 'active',
                'password': new_password,
                'ssh_port': ssh_port,
                'completion_time': datetime.utcnow()
            }
    
    # No cloud provider, use mock implementation
    logger.warning(f"No cloud provider found for server {server_id}, using mock implementation")
    
    # Simulate API delay
    import time
    time.sleep(5)
    
    # Generate a new password for the reinstalled system
    new_password = f"pass{random.randint(1000, 9999)}"
    ssh_port = 22  # Default SSH port
    
    return {
        'status': 'active',
        'password': new_password,
        'ssh_port': ssh_port,
        'completion_time': datetime.utcnow()
    }

def calculate_expiry_date(billing_cycle):
    """
    Calculate the expiry date based on billing cycle
    
    Args:
        billing_cycle: The billing cycle (monthly, quarterly, semi_annual, annual, biennial, quadrennial, hourly)
    
    Returns:
        datetime: The expiry date
    """
    now = datetime.utcnow()
    
    if billing_cycle == 'hourly':
        return now + timedelta(hours=1)
    elif billing_cycle == 'monthly':
        return now + timedelta(days=30)
    elif billing_cycle == 'quarterly':
        return now + timedelta(days=90)
    elif billing_cycle == 'semi_annual':
        return now + timedelta(days=180)
    elif billing_cycle == 'annual':
        return now + timedelta(days=365)
    elif billing_cycle == 'biennial':
        return now + timedelta(days=730)
    elif billing_cycle == 'quadrennial':
        return now + timedelta(days=1460)
    else:
        # Default to monthly
        logger.warning(f"Unknown billing cycle: {billing_cycle}, defaulting to monthly")
        return now + timedelta(days=30)

def suspend_server(server_id):
    """
    Suspend a server due to contract expiration
    
    This function will:
    1. Check if the server is associated with a cloud provider
    2. If yes, stop the server via cloud provider API
    3. Update the server status in the database to 'suspended'
    """
    logger.info(f"Suspending server with ID {server_id} due to contract expiration")
    
    from models import Server
    from app import db
    
    server = Server.query.get(server_id)
    if not server:
        logger.error(f"Server {server_id} not found")
        return False
    
    # Check if the server has a provider and provider_server_id
    if hasattr(server, 'template') and server.template and hasattr(server.template, 'provider') and server.template.provider:
        provider = server.template.provider
        provider_server_id = getattr(server, 'provider_server_id', None)
        
        if provider_server_id:
            # Use cloud provider API to stop the server
            logger.info(f"Using cloud provider API to stop server {server_id}")
            
            # Call the cloud provider to stop the server
            from routes.cloud import server_action
            success, message = server_action(provider, provider_server_id, 'stop')
            
            if not success:
                logger.error(f"Error suspending server {server_id} via cloud provider: {message}")
                # Continue to update the database status even if the API call fails
            else:
                logger.info(f"Server {server_id} stopped via cloud provider API")
    
    # Update the database status regardless of cloud provider result
    server.status = 'suspended'
    db.session.commit()
    logger.info(f"Server {server_id} marked as suspended in database")
    
    return True

def reactivate_server(server_id, new_expiry_date=None):
    """
    Reactivate a suspended server
    
    This function will:
    1. Check if the server is associated with a cloud provider
    2. If yes, start the server via cloud provider API
    3. Update the server status in the database
    
    Args:
        server_id: The ID of the server to reactivate
        new_expiry_date: Optional new expiry date (if None, keeps the current date)
    """
    logger.info(f"Reactivating suspended server with ID {server_id}")
    
    from models import Server
    from app import db
    
    server = Server.query.get(server_id)
    if not server:
        logger.error(f"Server {server_id} not found")
        return False
    
    # Check if the server has a provider and provider_server_id
    if hasattr(server, 'template') and server.template and hasattr(server.template, 'provider') and server.template.provider:
        provider = server.template.provider
        provider_server_id = getattr(server, 'provider_server_id', None)
        
        if provider_server_id:
            # Use cloud provider API to start the server
            logger.info(f"Using cloud provider API to start server {server_id}")
            
            # Call the cloud provider to start the server
            from routes.cloud import server_action
            success, message = server_action(provider, provider_server_id, 'start')
            
            if not success:
                logger.error(f"Error reactivating server {server_id} via cloud provider: {message}")
                # Continue to update the database status even if the API call fails
            else:
                logger.info(f"Server {server_id} started via cloud provider API")
    
    # Update the database status regardless of cloud provider result
    server.status = 'active'
    if new_expiry_date:
        server.expiry_date = new_expiry_date
    db.session.commit()
    logger.info(f"Server {server_id} marked as active in database")
    
    return True

def check_expired_servers():
    """
    Check for servers that have expired and suspend them
    This should be run periodically via a scheduler or cron job
    """
    logger.info("Checking for expired servers")
    
    from models import Server
    from app import db
    
    now = datetime.utcnow()
    
    # Find active servers that have passed their expiry date
    expired_servers = Server.query.filter(
        Server.status == 'active',
        Server.expiry_date < now
    ).all()
    
    logger.info(f"Found {len(expired_servers)} expired servers")
    
    # Suspend each expired server
    for server in expired_servers:
        logger.info(f"Server {server.id} ({server.hostname}) has expired on {server.expiry_date}")
        suspend_server(server.id)
    
    return len(expired_servers)
