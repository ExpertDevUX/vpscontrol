import logging
import os
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from email.mime.application import MIMEApplication
from email.mime.base import MIMEBase
from email import encoders
from io import BytesIO

logger = logging.getLogger(__name__)

# Email configuration
SMTP_SERVER = os.environ.get('SMTP_SERVER', 'smtp.example.com')
SMTP_PORT = int(os.environ.get('SMTP_PORT', 587))
SMTP_USERNAME = os.environ.get('SMTP_USERNAME', 'noreply@example.com')
SMTP_PASSWORD = os.environ.get('SMTP_PASSWORD', 'password')
SENDER_EMAIL = os.environ.get('SENDER_EMAIL', 'noreply@example.com')
SENDER_NAME = os.environ.get('SENDER_NAME', 'VPS Control Panel')

def send_email(recipient_email, subject, html_content, text_content=None, attachments=None):
    """
    Send an email using the configured SMTP server
    
    Args:
        recipient_email (str): Email address of the recipient
        subject (str): Email subject
        html_content (str): HTML content of the email
        text_content (str): Plain text content as fallback (generated from HTML if None)
        attachments (list): List of attachment objects, each should be a dict with:
                           - 'filename': name of the attachment
                           - 'content': BytesIO or file-like object with content
                           - 'mime_type': MIME type of the attachment (e.g., 'application/pdf')
    
    Returns:
        bool: True if email was sent successfully, False otherwise
    """
    try:
        # Create message container with alternative parts
        message = MIMEMultipart()
        message['Subject'] = subject
        message['From'] = f"{SENDER_NAME} <{SENDER_EMAIL}>"
        message['To'] = recipient_email
        
        # Create alternative part for text/html versions
        alt_part = MIMEMultipart('alternative')
        
        # Generate plain text content from HTML if not provided
        if text_content is None:
            from html2text import html2text
            text_content = html2text(html_content)
        
        # Attach text and HTML parts to the alternative part
        part1 = MIMEText(text_content, 'plain')
        part2 = MIMEText(html_content, 'html')
        alt_part.attach(part1)
        alt_part.attach(part2)
        
        # Attach the alternative part to the main message
        message.attach(alt_part)
        
        # Add attachments if provided
        if attachments:
            for attachment in attachments:
                filename = attachment.get('filename', 'attachment.dat')
                content = attachment.get('content')
                mime_type = attachment.get('mime_type', 'application/octet-stream')
                
                if content:
                    # If content is BytesIO or file-like object
                    if isinstance(content, BytesIO):
                        att = MIMEApplication(content.read(), _subtype=mime_type.split('/')[-1])
                        att.add_header('Content-Disposition', 'attachment', filename=filename)
                        message.attach(att)
                    # If content is raw bytes
                    elif isinstance(content, bytes):
                        att = MIMEApplication(content, _subtype=mime_type.split('/')[-1])
                        att.add_header('Content-Disposition', 'attachment', filename=filename)
                        message.attach(att)
                    # If content is a file path
                    elif isinstance(content, str) and os.path.isfile(content):
                        with open(content, 'rb') as f:
                            att = MIMEApplication(f.read(), _subtype=mime_type.split('/')[-1])
                            att.add_header('Content-Disposition', 'attachment', filename=filename)
                            message.attach(att)
        
        # Send email
        with smtplib.SMTP(SMTP_SERVER, SMTP_PORT) as server:
            server.starttls()
            server.login(SMTP_USERNAME, SMTP_PASSWORD)
            server.send_message(message)
        
        logger.info(f"Email sent to {recipient_email}: {subject}")
        return True
    
    except Exception as e:
        logger.error(f"Failed to send email to {recipient_email}: {str(e)}")
        return False

def send_welcome_email(user):
    """Send welcome email to a new user"""
    subject = "Welcome to VPS Control Panel"
    
    html_content = f"""
    <html>
        <body>
            <h1>Welcome to VPS Control Panel, {user.first_name}!</h1>
            <p>Thank you for registering with us. Your account has been created successfully.</p>
            <p>With your account, you can:</p>
            <ul>
                <li>Order and manage Virtual Private Servers</li>
                <li>Monitor resource usage and performance</li>
                <li>Manage billing and payments</li>
                <li>Get technical support from our team</li>
            </ul>
            <p>If you have any questions, please don't hesitate to contact our support team.</p>
            <p>Best regards,<br>The VPS Control Panel Team</p>
        </body>
    </html>
    """
    
    return send_email(user.email, subject, html_content)

def send_invoice_notification(user, invoice):
    """Send invoice notification email with PDF invoice attachment"""
    from utils.pdf_generator import generate_invoice_pdf
    
    subject = f"New Invoice #{invoice.invoice_number}"
    
    html_content = f"""
    <html>
        <body>
            <h1>New Invoice</h1>
            <p>Dear {user.first_name},</p>
            <p>A new invoice has been created for your account:</p>
            <ul>
                <li>Invoice Number: {invoice.invoice_number}</li>
                <li>Amount: ${invoice.total_amount:.2f}</li>
                <li>Due Date: {invoice.due_date.strftime('%Y-%m-%d')}</li>
            </ul>
            <p>Please find the detailed invoice attached to this email. You can also log in to your account to view and pay this invoice online.</p>
            <p>Best regards,<br>The VPS Control Panel Team</p>
        </body>
    </html>
    """
    
    # Generate PDF invoice
    try:
        pdf_buffer = generate_invoice_pdf(invoice.id)
        
        # Add PDF as attachment
        attachments = [{
            'filename': f'Invoice-{invoice.invoice_number}.pdf',
            'content': pdf_buffer,
            'mime_type': 'application/pdf'
        }]
        
        return send_email(user.email, subject, html_content, attachments=attachments)
    except Exception as e:
        logger.error(f"Failed to generate PDF for invoice {invoice.id}: {str(e)}")
        # Send email without PDF if generation fails
        return send_email(user.email, subject, html_content)

def send_payment_confirmation(user, invoice, transaction):
    """Send payment confirmation email with signed PDF receipt"""
    from utils.pdf_generator import generate_invoice_pdf, attach_digital_signature
    
    subject = f"Payment Confirmation for Invoice #{invoice.invoice_number}"
    
    html_content = f"""
    <html>
        <body>
            <h1>Payment Confirmation</h1>
            <p>Dear {user.first_name},</p>
            <p>We have received your payment for Invoice #{invoice.invoice_number}:</p>
            <ul>
                <li>Amount: ${transaction.amount:.2f}</li>
                <li>Payment Method: {transaction.gateway}</li>
                <li>Transaction ID: {transaction.transaction_id}</li>
                <li>Date: {transaction.transaction_date.strftime('%Y-%m-%d %H:%M')}</li>
            </ul>
            <p>Please find your signed receipt attached to this email for your records.</p>
            <p>Thank you for your payment.</p>
            <p>Best regards,<br>The VPS Control Panel Team</p>
        </body>
    </html>
    """
    
    # Generate PDF invoice receipt with signature
    try:
        # Generate PDF invoice
        pdf_buffer = generate_invoice_pdf(invoice.id)
        
        # Add digital signature (in production, this would use a real certificate)
        signed_pdf = attach_digital_signature(pdf_buffer)
        
        # Add PDF as attachment
        attachments = [{
            'filename': f'Receipt-{invoice.invoice_number}.pdf',
            'content': signed_pdf,
            'mime_type': 'application/pdf'
        }]
        
        return send_email(user.email, subject, html_content, attachments=attachments)
    except Exception as e:
        logger.error(f"Failed to generate signed PDF receipt for invoice {invoice.id}: {str(e)}")
        # Send email without PDF if generation fails
        return send_email(user.email, subject, html_content)

def send_server_provision_notification(user, server):
    """Send server provision notification email"""
    subject = f"Your New VPS Server is Ready: {server.hostname}"
    
    html_content = f"""
    <html>
        <body>
            <h1>Your VPS Server is Ready</h1>
            <p>Dear {user.first_name},</p>
            <p>Your new VPS server has been provisioned and is now ready to use:</p>
            <ul>
                <li>Hostname: {server.hostname}</li>
                <li>IP Address: {server.ip_address}</li>
                <li>Username: {server.username}</li>
                <li>Password: {server.password}</li>
            </ul>
            <p>Please log in to your control panel to manage your server.</p>
            <p>For security reasons, we recommend changing your server's password as soon as possible.</p>
            <p>Best regards,<br>The VPS Control Panel Team</p>
        </body>
    </html>
    """
    
    return send_email(user.email, subject, html_content)

def send_ticket_notification(user, ticket, message):
    """Send ticket update notification email"""
    subject = f"Support Ticket #{ticket.id} Update: {ticket.subject}"
    
    is_admin_reply = message.is_from_admin
    
    html_content = f"""
    <html>
        <body>
            <h1>Support Ticket Update</h1>
            <p>Dear {user.first_name},</p>
            <p>{'Our support team has' if is_admin_reply else 'You have'} added a new reply to your support ticket:</p>
            <ul>
                <li>Ticket ID: #{ticket.id}</li>
                <li>Subject: {ticket.subject}</li>
                <li>Status: {ticket.status}</li>
            </ul>
            <div style="border-left: 4px solid #ccc; padding-left: 10px; margin: 10px 0;">
                <p>{message.message}</p>
            </div>
            <p>Please log in to your account to view the full ticket history.</p>
            <p>Best regards,<br>The VPS Control Panel Team</p>
        </body>
    </html>
    """
    
    return send_email(user.email, subject, html_content)

def send_server_expiry_notification(user, server, days_remaining):
    """Send server expiry notification email"""
    subject = f"Your VPS Server {server.hostname} Will Expire Soon"
    
    html_content = f"""
    <html>
        <body>
            <h1>VPS Server Expiry Notice</h1>
            <p>Dear {user.first_name},</p>
            <p>Your VPS server is scheduled to expire in {days_remaining} days:</p>
            <ul>
                <li>Hostname: {server.hostname}</li>
                <li>IP Address: {server.ip_address}</li>
                <li>Expiry Date: {server.expiry_date.strftime('%Y-%m-%d')}</li>
            </ul>
            <p>To avoid service interruption, please log in to your account and renew your server before the expiry date.</p>
            <p>Best regards,<br>The VPS Control Panel Team</p>
        </body>
    </html>
    """
    
    return send_email(user.email, subject, html_content)
