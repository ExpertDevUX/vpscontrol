import random
import string
import logging
from datetime import datetime

logger = logging.getLogger(__name__)

def generate_invoice_number():
    """Generate a unique invoice number"""
    # Format: INV-YYYYMMDD-XXXXX where X is a random character
    date_part = datetime.utcnow().strftime('%Y%m%d')
    random_part = ''.join(random.choices(string.ascii_uppercase + string.digits, k=5))
    return f"INV-{date_part}-{random_part}"

def calculate_tax(amount, tax_rate=0.0):
    """Calculate tax for an amount"""
    # Tax rate is a percentage, e.g. 10.0 for 10%
    return amount * (tax_rate / 100)

def calculate_total(amount, tax_amount):
    """Calculate total with tax"""
    return amount + tax_amount

def get_price_multiplier(billing_cycle):
    """
    Get price multiplier based on billing cycle
    
    Args:
        billing_cycle: The billing cycle (monthly, quarterly, semi_annual, annual, biennial, quadrennial, hourly)
    
    Returns:
        float: The price multiplier (e.g. 1.0 for monthly, 3.0 for quarterly, etc.)
    """
    if billing_cycle == 'hourly':
        return 1/720  # Approximately 1/730th of a month (assuming 730 hours in a month)
    elif billing_cycle == 'monthly':
        return 1.0
    elif billing_cycle == 'quarterly':
        return 3.0
    elif billing_cycle == 'semi_annual':
        return 6.0
    elif billing_cycle == 'annual':
        return 12.0
    elif billing_cycle == 'biennial':
        return 24.0
    elif billing_cycle == 'quadrennial':
        return 48.0
    else:
        # Default to monthly
        logger.warning(f"Unknown billing cycle: {billing_cycle}, defaulting to monthly")
        return 1.0