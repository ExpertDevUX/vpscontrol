"""
Database initialization and utility functions
"""
import os
import logging
import psycopg2
from psycopg2 import sql
from psycopg2.extensions import ISOLATION_LEVEL_AUTOCOMMIT

logger = logging.getLogger(__name__)

def init_database():
    """
    Initialize the PostgreSQL database if it doesn't exist.
    This function checks for the existence of the configured database,
    and creates it if it doesn't exist.
    """
    # Parse the DATABASE_URL to extract database name and connection info
    db_url = os.environ.get('DATABASE_URL')
    
    if not db_url:
        logger.warning("DATABASE_URL not set. Cannot initialize database.")
        return False
    
    # Basic parsing of the DATABASE_URL
    # Example format: postgresql://username:password@host:port/dbname
    try:
        # Extract the database name from the URL
        db_name = db_url.split('/')[-1]
        
        # Create connection string without the database name for initial connection
        conn_parts = db_url.split('/')
        conn_string = '/'.join(conn_parts[:-1]) + '/postgres'  # Connect to default 'postgres' database
        
        # Connect to the default PostgreSQL database to check if our database exists
        conn = psycopg2.connect(conn_string)
        conn.set_isolation_level(ISOLATION_LEVEL_AUTOCOMMIT)
        cursor = conn.cursor()
        
        # Check if the database exists
        cursor.execute("SELECT 1 FROM pg_database WHERE datname = %s", (db_name,))
        exists = cursor.fetchone()
        
        if not exists:
            # Create the database if it doesn't exist
            logger.info(f"Creating database '{db_name}'...")
            cursor.execute(sql.SQL("CREATE DATABASE {}").format(sql.Identifier(db_name)))
            logger.info(f"Database '{db_name}' created successfully.")
        else:
            logger.info(f"Database '{db_name}' already exists.")
        
        cursor.close()
        conn.close()
        return True
        
    except Exception as e:
        logger.error(f"Error initializing database: {str(e)}")
        return False

def backup_database(backup_file=None):
    """
    Backup the database to a file.
    
    Args:
        backup_file: Optional filename for the backup, defaults to 'backup_{timestamp}.sql'
    
    Returns:
        Path to the backup file or None on failure
    """
    from datetime import datetime
    
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    backup_file = backup_file or f"backup_{timestamp}.sql"
    
    db_url = os.environ.get('DATABASE_URL')
    
    if not db_url:
        logger.warning("DATABASE_URL not set. Cannot backup database.")
        return None
    
    try:
        # Extract connection details from DATABASE_URL
        # Example format: postgresql://username:password@host:port/dbname
        parts = db_url.replace('postgresql://', '').split('/')
        conn_string = parts[0]
        db_name = parts[1]
        
        if '@' in conn_string:
            auth, host_port = conn_string.split('@')
            username, password = auth.split(':')
        else:
            host_port = conn_string
            username = password = ''
        
        if ':' in host_port:
            host, port = host_port.split(':')
        else:
            host = host_port
            port = '5432'
        
        # Construct the pg_dump command
        cmd = f'PGPASSWORD="{password}" pg_dump -h {host} -p {port} -U {username} -d {db_name} -F p -f {backup_file}'
        
        # Execute the command
        result = os.system(cmd)
        
        if result == 0:
            logger.info(f"Database backup created successfully: {backup_file}")
            return backup_file
        else:
            logger.error(f"Failed to create database backup. Command returned: {result}")
            return None
            
    except Exception as e:
        logger.error(f"Error backing up database: {str(e)}")
        return None