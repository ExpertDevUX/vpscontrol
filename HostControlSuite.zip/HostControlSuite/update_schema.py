#!/usr/bin/env python3
"""
Database migration script for updating the Server model with provider_server_id field
"""

import os
import sys
from datetime import datetime
import logging

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

try:
    from sqlalchemy import text
    from app import db, app
    logger.info("Successfully imported app")
except ImportError as e:
    logger.error(f"Error importing app: {e}")
    sys.exit(1)

def add_provider_server_id_column():
    """
    Add provider_server_id column to the Server table if it doesn't exist
    """
    with app.app_context():
        try:
            # Check if the column already exists to avoid errors
            from sqlalchemy import inspect
            inspector = inspect(db.engine)
            columns = [column['name'] for column in inspector.get_columns('server')]
            
            if 'provider_server_id' in columns:
                logger.info("Column provider_server_id already exists in server table")
                return True
            
            # Add the column
            logger.info("Adding provider_server_id column to server table")
            with db.engine.connect() as conn:
                conn.execute(text('ALTER TABLE server ADD COLUMN provider_server_id VARCHAR(255)'))
                conn.commit()
            logger.info("Column provider_server_id added successfully")
            return True
            
        except Exception as e:
            logger.error(f"Error adding provider_server_id column: {e}")
            return False

if __name__ == "__main__":
    logger.info("Starting database migration script")
    
    if add_provider_server_id_column():
        logger.info("Migration completed successfully")
    else:
        logger.error("Migration failed")
        sys.exit(1)