/**
 * VPS Control functionality for VPS Control Panel
 * Handles server control actions and resource usage charts
 */

// Initialize when document is ready
document.addEventListener('DOMContentLoaded', function() {
    // Initialize VPS detail page charts
    const serverDetailPage = document.querySelector('.vps-details-page');
    if (serverDetailPage) {
        const serverId = serverDetailPage.getAttribute('data-server-id');
        initializeUsageCharts(serverId);
        
        // Set up periodic refresh
        setInterval(() => {
            refreshServerStatus(serverId);
        }, 30000); // Every 30 seconds
        
        // Add click handlers to control buttons
        setupControlButtons();
    }
    
    // Initialize control buttons on VPS list page
    const vpsListPage = document.querySelector('.vps-list-page');
    if (vpsListPage) {
        setupListPageControls();
    }
});

/**
 * Initialize usage charts for VPS details page
 */
function initializeUsageCharts(serverId) {
    fetch(`/vps/api/usage/${serverId}`, {
        headers: {
            'X-CSRFToken': getCsrfToken()
        }
    })
        .then(response => response.json())
        .then(data => {
            // CPU usage chart
            createLineChart('cpuChart', 'CPU Usage (%)', data.labels, data.cpu_data, 'rgba(255, 99, 132, 0.5)', 'rgba(255, 99, 132, 1)');
            
            // RAM usage chart
            createLineChart('ramChart', 'RAM Usage (%)', data.labels, data.ram_data, 'rgba(54, 162, 235, 0.5)', 'rgba(54, 162, 235, 1)');
            
            // Disk usage chart
            createLineChart('diskChart', 'Disk Usage (%)', data.labels, data.disk_data, 'rgba(255, 206, 86, 0.5)', 'rgba(255, 206, 86, 1)');
            
            // Network traffic chart
            createNetworkChart('networkChart', data.labels, data.network_data);
        })
        .catch(error => {
            console.error('Error loading usage data:', error);
        });
}

/**
 * Create a line chart for resource usage
 */
function createLineChart(canvasId, label, labels, data, backgroundColor, borderColor) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: label,
                data: data,
                backgroundColor: backgroundColor,
                borderColor: borderColor,
                borderWidth: 2,
                tension: 0.1,
                fill: true
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y.toFixed(1) + '%';
                        }
                    }
                }
            }
        }
    });
}

/**
 * Create a network traffic chart with both inbound and outbound data
 */
function createNetworkChart(canvasId, labels, networkData) {
    const canvas = document.getElementById(canvasId);
    if (!canvas) return;
    
    // Extract in and out data
    const inData = [];
    const outData = [];
    
    networkData.forEach(item => {
        inData.push(item.in);
        outData.push(item.out);
    });
    
    const ctx = canvas.getContext('2d');
    new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [
                {
                    label: 'Network In (MB)',
                    data: inData,
                    backgroundColor: 'rgba(75, 192, 192, 0.5)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 2,
                    tension: 0.1,
                    fill: true
                },
                {
                    label: 'Network Out (MB)',
                    data: outData,
                    backgroundColor: 'rgba(153, 102, 255, 0.5)',
                    borderColor: 'rgba(153, 102, 255, 1)',
                    borderWidth: 2,
                    tension: 0.1,
                    fill: true
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return value + ' MB';
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y.toFixed(2) + ' MB';
                        }
                    }
                }
            }
        }
    });
}

/**
 * Refresh server status and update UI
 */
function refreshServerStatus(serverId) {
    fetch(`/vps/api/status/${serverId}`, {
        headers: {
            'X-CSRFToken': getCsrfToken()
        }
    })
        .then(response => response.json())
        .then(data => {
            // Update status badge
            const statusBadge = document.querySelector('.server-status-badge');
            if (statusBadge) {
                statusBadge.textContent = data.status;
                statusBadge.className = 'server-status-badge status-badge';
                statusBadge.classList.add(`status-${data.status}`);
            }
            
            // Update resource indicators
            updateResourceIndicator('cpu', data.cpu_usage);
            updateResourceIndicator('ram', data.ram_usage);
            updateResourceIndicator('disk', data.disk_usage);
            
            // Update timestamp
            const timestampElement = document.querySelector('.status-timestamp');
            if (timestampElement) {
                timestampElement.textContent = `Last updated: ${data.timestamp}`;
            }
        })
        .catch(error => {
            console.error('Error refreshing server status:', error);
        });
}

/**
 * Update a resource usage indicator
 */
function updateResourceIndicator(resourceType, value) {
    const indicator = document.querySelector(`.${resourceType}-usage-indicator`);
    if (!indicator) return;
    
    // Update progress bar
    const progressBar = indicator.querySelector('.progress-bar');
    if (progressBar) {
        progressBar.style.width = `${value}%`;
        progressBar.setAttribute('aria-valuenow', value);
        
        // Set color based on usage level
        progressBar.className = 'progress-bar';
        if (value > 90) {
            progressBar.classList.add('bg-danger');
        } else if (value > 70) {
            progressBar.classList.add('bg-warning');
        } else {
            progressBar.classList.add('bg-success');
        }
    }
    
    // Update text value
    const valueElement = indicator.querySelector('.value');
    if (valueElement) {
        valueElement.textContent = `${Math.round(value)}%`;
    }
}

/**
 * Set up VPS control button event handlers
 */
function setupControlButtons() {
    // Start server button
    const startBtn = document.getElementById('startServerBtn');
    if (startBtn) {
        startBtn.addEventListener('click', function() {
            showActionConfirmation('start', 'Start Server', 'Are you sure you want to start this server?');
        });
    }
    
    // Stop server button
    const stopBtn = document.getElementById('stopServerBtn');
    if (stopBtn) {
        stopBtn.addEventListener('click', function() {
            showActionConfirmation('stop', 'Stop Server', 'Are you sure you want to stop this server? All services will be unavailable until the server is started again.');
        });
    }
    
    // Restart server button
    const restartBtn = document.getElementById('restartServerBtn');
    if (restartBtn) {
        restartBtn.addEventListener('click', function() {
            showActionConfirmation('restart', 'Restart Server', 'Are you sure you want to restart this server? There will be a brief downtime during the restart.');
        });
    }
    
    // Reinstall OS button
    const reinstallBtn = document.getElementById('reinstallOSBtn');
    if (reinstallBtn) {
        reinstallBtn.addEventListener('click', function() {
            showReinstallConfirmation();
        });
    }
}

/**
 * Show confirmation modal for server actions
 */
function showActionConfirmation(action, title, message) {
    const modal = document.getElementById('actionConfirmModal');
    if (!modal) return;
    
    // Set modal content
    const modalTitle = modal.querySelector('.modal-title');
    const modalBody = modal.querySelector('.modal-body');
    const actionInput = document.getElementById('serverAction');
    
    modalTitle.textContent = title;
    modalBody.textContent = message;
    actionInput.value = action;
    
    // Show modal
    const modalInstance = new bootstrap.Modal(modal);
    modalInstance.show();
}

/**
 * Show confirmation modal for OS reinstall with OS selection
 */
function showReinstallConfirmation() {
    const modal = document.getElementById('reinstallOSModal');
    if (!modal) return;
    
    // Show modal
    const modalInstance = new bootstrap.Modal(modal);
    modalInstance.show();
}

/**
 * Get CSRF token from the meta tag
 */
function getCsrfToken() {
    const metaTag = document.querySelector('meta[name="csrf-token"]');
    return metaTag ? metaTag.getAttribute('content') : '';
}

/**
 * Set up control buttons on the VPS list page
 */
function setupListPageControls() {
    // Power buttons
    const powerButtons = document.querySelectorAll('.vps-power-btn');
    powerButtons.forEach(button => {
        button.addEventListener('click', function(e) {
            e.preventDefault();
            
            const serverId = this.getAttribute('data-server-id');
            const action = this.getAttribute('data-action');
            const serverName = this.getAttribute('data-server-name');
            
            let confirmMessage = '';
            let title = '';
            
            switch (action) {
                case 'start':
                    title = 'Start Server';
                    confirmMessage = `Are you sure you want to start ${serverName}?`;
                    break;
                case 'stop':
                    title = 'Stop Server';
                    confirmMessage = `Are you sure you want to stop ${serverName}? All services will be unavailable until the server is started again.`;
                    break;
                case 'restart':
                    title = 'Restart Server';
                    confirmMessage = `Are you sure you want to restart ${serverName}? There will be a brief downtime during the restart.`;
                    break;
            }
            
            if (confirm(confirmMessage)) {
                // Show loading spinner
                this.innerHTML = '<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>';
                this.disabled = true;
                
                // Submit the action form
                const form = document.createElement('form');
                form.method = 'POST';
                form.action = `/vps/server_action/${serverId}`;
                
                // Add CSRF token - make sure to use the correct token
                const csrfToken = document.querySelector('meta[name="csrf-token"]').getAttribute('content');
                const csrfInput = document.createElement('input');
                csrfInput.type = 'hidden';
                csrfInput.name = 'csrf_token';
                csrfInput.value = csrfToken;
                form.appendChild(csrfInput);
                
                const actionInput = document.createElement('input');
                actionInput.type = 'hidden';
                actionInput.name = 'action';
                actionInput.value = action;
                
                form.appendChild(actionInput);
                document.body.appendChild(form);
                form.submit();
            }
        });
    });
}
