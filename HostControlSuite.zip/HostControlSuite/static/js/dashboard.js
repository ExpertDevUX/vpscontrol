/**
 * Dashboard functionality for VPS Control Panel
 * Includes chart initialization and real-time updates
 * Optimized for performance with lazy loading
 */

// Initialize only necessary functionality when document is ready
document.addEventListener('DOMContentLoaded', function() {
    // Only initialize what's visible - optimize for performance
    
    // Update any server status indicators that are visible
    const statusElements = document.querySelectorAll('[data-server-id]');
    if (statusElements.length > 0) {
        // Only update servers if we have them on the page
        updateAllServerStatuses();
        
        // Set up auto-refresh for server statuses, but with less frequent updates
        // to reduce server load and improve performance
        setInterval(updateAllServerStatuses, 120000); // Every 2 minutes instead of 1
    }
    
    // Load charts only if they exist on the page - this is now handled by the lazy loader in base.html
    // Charts will be initialized when the charts.js script is loaded
});

/**
 * Initialize revenue chart for admin dashboard
 */
function initializeRevenueChart(canvas) {
    // Get data from data attributes
    const chartData = JSON.parse(canvas.getAttribute('data-chart'));
    
    // Create the chart
    const ctx = canvas.getContext('2d');
    const revenueChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chartData.labels,
            datasets: [{
                label: 'Revenue',
                data: chartData.data,
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    ticks: {
                        callback: function(value) {
                            return '$' + value;
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return '$' + context.parsed.y.toFixed(2);
                        }
                    }
                }
            }
        }
    });
}

/**
 * Initialize resource usage summary chart for client dashboard
 */
function initializeResourceSummaryChart(canvas) {
    // Get data from data attributes
    const chartData = JSON.parse(canvas.getAttribute('data-chart'));
    
    // Create the chart
    const ctx = canvas.getContext('2d');
    const resourceChart = new Chart(ctx, {
        type: 'bar',
        data: {
            labels: chartData.servers,
            datasets: [
                {
                    label: 'CPU Usage (%)',
                    data: chartData.cpu,
                    backgroundColor: 'rgba(255, 99, 132, 0.5)',
                    borderColor: 'rgba(255, 99, 132, 1)',
                    borderWidth: 1
                },
                {
                    label: 'RAM Usage (%)',
                    data: chartData.ram,
                    backgroundColor: 'rgba(54, 162, 235, 0.5)',
                    borderColor: 'rgba(54, 162, 235, 1)',
                    borderWidth: 1
                },
                {
                    label: 'Disk Usage (%)',
                    data: chartData.disk,
                    backgroundColor: 'rgba(255, 206, 86, 0.5)',
                    borderColor: 'rgba(255, 206, 86, 1)',
                    borderWidth: 1
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    max: 100,
                    ticks: {
                        callback: function(value) {
                            return value + '%';
                        }
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            return context.dataset.label + ': ' + context.parsed.y.toFixed(1) + '%';
                        }
                    }
                }
            }
        }
    });
}

/**
 * Update all server status indicators on the page
 */
function updateAllServerStatuses() {
    const statusElements = document.querySelectorAll('[data-server-id]');
    
    statusElements.forEach(element => {
        const serverId = element.getAttribute('data-server-id');
        updateServerStatus(serverId);
    });
}

/**
 * Update the status indicator for a specific server
 */
function updateServerStatus(serverId) {
    const statusElement = document.querySelector(`[data-server-id="${serverId}"]`);
    if (!statusElement) return;
    
    fetch(`/vps/api/status/${serverId}`, {
        headers: {
            'X-CSRFToken': getCsrfToken()
        }
    })
        .then(response => response.json())
        .then(data => {
            // Update status badge
            const statusBadge = statusElement.querySelector('.status-badge');
            if (statusBadge) {
                statusBadge.textContent = data.status;
                statusBadge.className = 'status-badge';
                statusBadge.classList.add(`status-${data.status}`);
            }
            
            // Update resource usage bars if they exist
            updateResourceBar(statusElement, 'cpu', data.cpu_usage);
            updateResourceBar(statusElement, 'ram', data.ram_usage);
            updateResourceBar(statusElement, 'disk', data.disk_usage);
            
            // Update timestamp
            const timestampElement = statusElement.querySelector('.status-timestamp');
            if (timestampElement) {
                timestampElement.textContent = `Last updated: ${data.timestamp}`;
            }
        })
        .catch(error => {
            console.error('Error updating server status:', error);
        });
}

/**
 * Get CSRF token from the meta tag
 */
function getCsrfToken() {
    const metaTag = document.querySelector('meta[name="csrf-token"]');
    return metaTag ? metaTag.getAttribute('content') : '';
}

/**
 * Update a resource usage progress bar
 */
function updateResourceBar(container, resourceType, value) {
    const barElement = container.querySelector(`.${resourceType}-usage-bar`);
    if (!barElement) return;
    
    // Update progress bar width
    const progressBar = barElement.querySelector('.progress-bar');
    if (progressBar) {
        progressBar.style.width = `${value}%`;
        progressBar.setAttribute('aria-valuenow', value);
        
        // Set color based on usage level
        progressBar.className = 'progress-bar';
        if (value > 90) {
            progressBar.classList.add('bg-danger');
        } else if (value > 70) {
            progressBar.classList.add('bg-warning');
        } else {
            progressBar.classList.add('bg-success');
        }
        
        // Update percentage text
        const percentageElement = barElement.querySelector('.percentage');
        if (percentageElement) {
            percentageElement.textContent = `${Math.round(value)}%`;
        }
    }
}
