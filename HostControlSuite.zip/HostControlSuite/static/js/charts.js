/**
 * Charts utility functions for VPS Control Panel
 * Provides reusable chart initialization functions
 * Optimized with lazy loading support
 */

// Self-initializing module - will run when the script is loaded
(function() {
    // Initialize all charts with the js-chart class
    const chartElements = document.querySelectorAll('.js-chart');
    
    chartElements.forEach(canvas => {
        // Check for specific chart types
        if (canvas.id === 'resourceSummaryChart') {
            initializeResourceSummaryChart(canvas);
        } else if (canvas.id === 'revenueChart') {
            // Use the new enhanced revenue chart visualization
            initializeEnhancedRevenueChart(canvas);
        } else {
            // For any other charts with data-chart attribute
            const chartData = canvas.getAttribute('data-chart');
            if (chartData) {
                try {
                    const data = JSON.parse(chartData);
                    // Determine chart type based on data structure or data-type attribute
                    const chartType = canvas.getAttribute('data-type') || 'line';
                    initializeGenericChart(canvas, data, chartType);
                } catch (e) {
                    console.error('Error parsing chart data:', e);
                }
            }
        }
    });
})();

/**
 * Initialize a generic chart based on data
 */
function initializeGenericChart(canvas, data, type = 'line') {
    const ctx = canvas.getContext('2d');
    
    // Create appropriate chart based on type
    if (type === 'bar') {
        return new Chart(ctx, {
            type: 'bar',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    } else if (type === 'pie' || type === 'doughnut') {
        return new Chart(ctx, {
            type: type,
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    } else {
        // Default to line chart
        return new Chart(ctx, {
            type: 'line',
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false
            }
        });
    }
}

/**
 * Initialize a line chart
 * 
 * @param {string} elementId - The ID of the canvas element
 * @param {Array} labels - The labels for the x-axis
 * @param {Array} data - The data points
 * @param {string} label - The dataset label
 * @param {string} color - The color for the dataset (RGB format)
 * @param {Object} options - Additional chart options
 * @returns {Chart} The initialized Chart.js instance
 */
function initLineChart(elementId, labels, data, label, color, options = {}) {
    const canvas = document.getElementById(elementId);
    if (!canvas) return null;
    
    const ctx = canvas.getContext('2d');
    
    // Default options
    const defaultOptions = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    };
    
    // Merge options
    const chartOptions = { ...defaultOptions, ...options };
    
    // Create and return the chart
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: label,
                data: data,
                backgroundColor: `rgba(${color}, 0.2)`,
                borderColor: `rgba(${color}, 1)`,
                borderWidth: 2,
                tension: 0.3,
                fill: true
            }]
        },
        options: chartOptions
    });
}

/**
 * Initialize a bar chart
 * 
 * @param {string} elementId - The ID of the canvas element
 * @param {Array} labels - The labels for the x-axis
 * @param {Array} data - The data points
 * @param {string} label - The dataset label
 * @param {string} color - The color for the dataset (RGB format)
 * @param {Object} options - Additional chart options
 * @returns {Chart} The initialized Chart.js instance
 */
function initBarChart(elementId, labels, data, label, color, options = {}) {
    const canvas = document.getElementById(elementId);
    if (!canvas) return null;
    
    const ctx = canvas.getContext('2d');
    
    // Default options
    const defaultOptions = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    };
    
    // Merge options
    const chartOptions = { ...defaultOptions, ...options };
    
    // Create and return the chart
    return new Chart(ctx, {
        type: 'bar',
        data: {
            labels: labels,
            datasets: [{
                label: label,
                data: data,
                backgroundColor: `rgba(${color}, 0.6)`,
                borderColor: `rgba(${color}, 1)`,
                borderWidth: 1
            }]
        },
        options: chartOptions
    });
}

/**
 * Initialize a pie chart
 * 
 * @param {string} elementId - The ID of the canvas element
 * @param {Array} labels - The data labels
 * @param {Array} data - The data values
 * @param {Array} backgroundColors - Array of background colors
 * @param {Object} options - Additional chart options
 * @returns {Chart} The initialized Chart.js instance
 */
function initPieChart(elementId, labels, data, backgroundColors, options = {}) {
    const canvas = document.getElementById(elementId);
    if (!canvas) return null;
    
    const ctx = canvas.getContext('2d');
    
    // Default options
    const defaultOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'right'
            }
        }
    };
    
    // Merge options
    const chartOptions = { ...defaultOptions, ...options };
    
    // Create and return the chart
    return new Chart(ctx, {
        type: 'pie',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: backgroundColors,
                borderWidth: 1
            }]
        },
        options: chartOptions
    });
}

/**
 * Initialize a doughnut chart
 * 
 * @param {string} elementId - The ID of the canvas element
 * @param {Array} labels - The data labels
 * @param {Array} data - The data values
 * @param {Array} backgroundColors - Array of background colors
 * @param {Object} options - Additional chart options
 * @returns {Chart} The initialized Chart.js instance
 */
function initDoughnutChart(elementId, labels, data, backgroundColors, options = {}) {
    const canvas = document.getElementById(elementId);
    if (!canvas) return null;
    
    const ctx = canvas.getContext('2d');
    
    // Default options
    const defaultOptions = {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
            legend: {
                position: 'right'
            }
        },
        cutout: '70%'
    };
    
    // Merge options
    const chartOptions = { ...defaultOptions, ...options };
    
    // Create and return the chart
    return new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: labels,
            datasets: [{
                data: data,
                backgroundColor: backgroundColors,
                borderWidth: 1
            }]
        },
        options: chartOptions
    });
}

/**
 * Initialize a multi-series chart (line or bar)
 * 
 * @param {string} elementId - The ID of the canvas element
 * @param {string} type - Chart type ('line' or 'bar')
 * @param {Array} labels - The labels for the x-axis
 * @param {Array} datasets - Array of dataset objects
 * @param {Object} options - Additional chart options
 * @returns {Chart} The initialized Chart.js instance
 */
function initMultiChart(elementId, type, labels, datasets, options = {}) {
    const canvas = document.getElementById(elementId);
    if (!canvas) return null;
    
    const ctx = canvas.getContext('2d');
    
    // Default options
    const defaultOptions = {
        responsive: true,
        maintainAspectRatio: false,
        scales: {
            y: {
                beginAtZero: true
            }
        }
    };
    
    // Merge options
    const chartOptions = { ...defaultOptions, ...options };
    
    // Create and return the chart
    return new Chart(ctx, {
        type: type,
        data: {
            labels: labels,
            datasets: datasets
        },
        options: chartOptions
    });
}

/**
 * Update chart data
 * 
 * @param {Chart} chart - The Chart.js instance to update
 * @param {Array} labels - New labels
 * @param {Array} data - New data points
 * @param {number} datasetIndex - Index of the dataset to update (default: 0)
 */
function updateChartData(chart, labels, data, datasetIndex = 0) {
    if (!chart) return;
    
    // Update labels if provided
    if (labels && labels.length > 0) {
        chart.data.labels = labels;
    }
    
    // Update dataset data if provided
    if (data && data.length > 0 && chart.data.datasets[datasetIndex]) {
        chart.data.datasets[datasetIndex].data = data;
    }
    
    // Update the chart
    chart.update();
}

/**
 * Create a resource usage gauge chart
 * 
 * @param {string} elementId - The ID of the canvas element
 * @param {number} value - Current value (0-100)
 * @param {string} label - Chart label
 * @param {Array} thresholds - Threshold values for color changes [warning, danger]
 * @returns {Chart} The initialized Chart.js instance
 */
function createGaugeChart(elementId, value, label, thresholds = [70, 90]) {
    const canvas = document.getElementById(elementId);
    if (!canvas) return null;
    
    const ctx = canvas.getContext('2d');
    
    // Determine color based on value and thresholds
    let color = 'rgba(40, 167, 69, 0.8)'; // success/green
    if (value >= thresholds[1]) {
        color = 'rgba(220, 53, 69, 0.8)'; // danger/red
    } else if (value >= thresholds[0]) {
        color = 'rgba(255, 193, 7, 0.8)'; // warning/yellow
    }
    
    // Calculate remaining portion (empty space)
    const remaining = 100 - value;
    
    return new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: [label, ''],
            datasets: [{
                data: [value, remaining],
                backgroundColor: [
                    color,
                    'rgba(200, 200, 200, 0.1)'
                ],
                borderWidth: 0,
                cutout: '80%'
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            circumference: 180,
            rotation: 270,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    displayColors: false,
                    callbacks: {
                        label: function(context) {
                            return `${context.parsed}%`;
                        }
                    }
                }
            }
        },
        plugins: [{
            id: 'gaugeText',
            beforeDraw: function(chart) {
                const width = chart.width;
                const height = chart.height;
                const ctx = chart.ctx;
                
                ctx.restore();
                
                // Value text
                const fontSize = Math.round(height / 5);
                ctx.font = `bold ${fontSize}px Arial`;
                ctx.textBaseline = 'middle';
                ctx.textAlign = 'center';
                ctx.fillStyle = '#fff';
                
                const text = `${value}%`;
                const textX = width / 2;
                const textY = height - fontSize * 0.6;
                
                ctx.fillText(text, textX, textY);
                
                // Label text
                const labelFontSize = Math.round(height / 8);
                ctx.font = `${labelFontSize}px Arial`;
                ctx.fillStyle = 'rgba(255, 255, 255, 0.7)';
                ctx.fillText(label, textX, textY - fontSize * 1.2);
                
                ctx.save();
            }
        }]
    });
}

/**
 * Initialize an enhanced revenue chart with line progression visualization
 * 
 * @param {HTMLCanvasElement} canvas - The canvas element
 * @returns {Chart} The initialized Chart.js instance
 */
function initializeEnhancedRevenueChart(canvas) {
    if (!canvas) return null;
    
    const ctx = canvas.getContext('2d');
    
    // Parse the data from the canvas data attribute
    let chartData;
    try {
        chartData = JSON.parse(canvas.getAttribute('data-chart') || '{}');
    } catch (e) {
        console.error('Error parsing revenue chart data:', e);
        return null;
    }
    
    // Extract labels and data
    const labels = chartData.labels || [];
    const revenueData = chartData.data || [];
    
    // Calculate month-over-month growth rates
    const growthRates = [];
    for (let i = 1; i < revenueData.length; i++) {
        const prevMonth = revenueData[i-1];
        const currentMonth = revenueData[i];
        
        // Calculate percentage growth (handle division by zero)
        let growthRate = 0;
        if (prevMonth > 0) {
            growthRate = ((currentMonth - prevMonth) / prevMonth) * 100;
        } else if (currentMonth > 0) {
            growthRate = 100; // Special case: from 0 to something
        }
        
        growthRates.push(growthRate);
    }
    
    // Create point styles with indicators of growth or decline
    const pointStyles = revenueData.map((value, index) => {
        if (index === 0) return 'circle'; // First point has no growth data
        const growth = growthRates[index-1];
        return growth >= 0 ? 'triangle' : 'rectRot'; // Use triangle for growth, rotated rectangle for decline
    });
    
    // Create point background colors based on growth
    const pointBackgroundColors = revenueData.map((value, index) => {
        if (index === 0) return 'rgba(13, 110, 253, 1)'; // Default blue for first point
        const growth = growthRates[index-1];
        if (growth > 15) return 'rgba(25, 135, 84, 1)'; // Strong growth (green)
        if (growth >= 0) return 'rgba(13, 202, 240, 1)'; // Moderate growth (cyan)
        if (growth >= -15) return 'rgba(255, 193, 7, 1)'; // Mild decline (yellow)
        return 'rgba(220, 53, 69, 1)'; // Strong decline (red)
    });
    
    // Create point radius based on amount (bigger circles for higher revenue)
    const maxRevenue = Math.max(...revenueData);
    const pointRadius = revenueData.map(value => {
        // Scale from 4 to 8 based on relative size
        const normalizedValue = value / maxRevenue;
        return 4 + (normalizedValue * 4);
    });
    
    // Add a gradient fill under the line
    const gradient = ctx.createLinearGradient(0, 0, 0, canvas.height);
    gradient.addColorStop(0, 'rgba(13, 110, 253, 0.5)');
    gradient.addColorStop(1, 'rgba(13, 110, 253, 0.0)');
    
    // Create enhanced chart
    return new Chart(ctx, {
        type: 'line',
        data: {
            labels: labels,
            datasets: [{
                label: 'Monthly Revenue',
                data: revenueData,
                borderColor: 'rgba(13, 110, 253, 1)',
                backgroundColor: gradient,
                borderWidth: 2,
                tension: 0.4, // Add slight curve to the line
                fill: true,
                pointStyle: pointStyles,
                pointRadius: pointRadius,
                pointBackgroundColor: pointBackgroundColors,
                pointBorderColor: '#fff',
                pointBorderWidth: 2,
                pointHoverRadius: 8,
                pointHoverBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            scales: {
                y: {
                    beginAtZero: true,
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    },
                    ticks: {
                        callback: function(value) {
                            return '$' + value.toLocaleString();
                        }
                    }
                },
                x: {
                    grid: {
                        color: 'rgba(255, 255, 255, 0.1)'
                    }
                }
            },
            plugins: {
                tooltip: {
                    callbacks: {
                        title: function(tooltipItems) {
                            return tooltipItems[0].label;
                        },
                        label: function(context) {
                            let label = 'Revenue: $' + context.parsed.y.toLocaleString();
                            
                            // Add growth rate info for all points except the first one
                            if (context.dataIndex > 0) {
                                const growth = growthRates[context.dataIndex-1];
                                const growthPrefix = growth >= 0 ? '+' : '';
                                label += `\nGrowth: ${growthPrefix}${growth.toFixed(1)}%`;
                            }
                            
                            return label;
                        }
                    }
                },
                legend: {
                    display: false
                }
            }
        }
    });
}
