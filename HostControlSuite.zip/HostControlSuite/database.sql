-- VPS Control Panel Database Schema

-- Create the database
CREATE DATABASE IF NOT EXISTS vps_panel CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE vps_panel;

-- Role table
CREATE TABLE IF NOT EXISTS role (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(80) NOT NULL UNIQUE,
    description VARCHAR(255)
);

-- User table
CREATE TABLE IF NOT EXISTS user (
    id INT AUTO_INCREMENT PRIMARY KEY,
    username VARCHAR(64) NOT NULL UNIQUE,
    email VARCHAR(120) NOT NULL UNIQUE,
    password_hash VARCHAR(256) NOT NULL,
    first_name VARCHAR(64),
    last_name VARCHAR(64),
    company_name VARCHAR(128),
    address VARCHAR(256),
    city VARCHAR(64),
    state VARCHAR(64),
    country VARCHAR(64),
    zip_code VARCHAR(20),
    phone VARCHAR(20),
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- User-Role many-to-many relationship
CREATE TABLE IF NOT EXISTS user_roles (
    user_id INT NOT NULL,
    role_id INT NOT NULL,
    PRIMARY KEY (user_id, role_id),
    FOREIGN KEY (user_id) REFERENCES user(id) ON DELETE CASCADE,
    FOREIGN KEY (role_id) REFERENCES role(id) ON DELETE CASCADE
);

-- Server Template table
CREATE TABLE IF NOT EXISTS server_template (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    cpu_cores INT NOT NULL,
    ram_mb INT NOT NULL,
    disk_gb INT NOT NULL,
    bandwidth_gb INT NOT NULL,
    price_monthly FLOAT NOT NULL,
    description TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Server table
CREATE TABLE IF NOT EXISTS server (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL,
    hostname VARCHAR(255) NOT NULL,
    ip_address VARCHAR(45) NOT NULL,
    status VARCHAR(20) DEFAULT 'pending',
    operating_system VARCHAR(100),
    username VARCHAR(64),
    password VARCHAR(256),
    cpu_cores INT NOT NULL,
    ram_mb INT NOT NULL,
    disk_gb INT NOT NULL,
    bandwidth_gb INT NOT NULL,
    bandwidth_used_gb FLOAT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    expiry_date DATETIME,
    last_renewal_date DATETIME,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    user_id INT NOT NULL,
    template_id INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user(id),
    FOREIGN KEY (template_id) REFERENCES server_template(id)
);

-- Server Usage table
CREATE TABLE IF NOT EXISTS server_usage (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cpu_usage_percent FLOAT,
    ram_usage_percent FLOAT,
    disk_usage_percent FLOAT,
    network_in_mb FLOAT,
    network_out_mb FLOAT,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    server_id INT NOT NULL,
    FOREIGN KEY (server_id) REFERENCES server(id) ON DELETE CASCADE
);

-- Invoice table
CREATE TABLE IF NOT EXISTS invoice (
    id INT AUTO_INCREMENT PRIMARY KEY,
    invoice_number VARCHAR(20) NOT NULL UNIQUE,
    amount FLOAT NOT NULL,
    tax_amount FLOAT DEFAULT 0,
    total_amount FLOAT NOT NULL,
    status VARCHAR(20) DEFAULT 'unpaid',
    issue_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    due_date DATETIME NOT NULL,
    paid_date DATETIME,
    notes TEXT,
    user_id INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user(id)
);

-- Invoice Item table
CREATE TABLE IF NOT EXISTS invoice_item (
    id INT AUTO_INCREMENT PRIMARY KEY,
    description VARCHAR(255) NOT NULL,
    amount FLOAT NOT NULL,
    quantity INT DEFAULT 1,
    server_id INT,
    invoice_id INT NOT NULL,
    FOREIGN KEY (server_id) REFERENCES server(id),
    FOREIGN KEY (invoice_id) REFERENCES invoice(id) ON DELETE CASCADE
);

-- Transaction table
CREATE TABLE IF NOT EXISTS transaction (
    id INT AUTO_INCREMENT PRIMARY KEY,
    transaction_id VARCHAR(100) UNIQUE,
    gateway VARCHAR(50),
    amount FLOAT NOT NULL,
    status VARCHAR(20),
    transaction_date DATETIME DEFAULT CURRENT_TIMESTAMP,
    invoice_id INT NOT NULL,
    FOREIGN KEY (invoice_id) REFERENCES invoice(id)
);

-- Ticket table
CREATE TABLE IF NOT EXISTS ticket (
    id INT AUTO_INCREMENT PRIMARY KEY,
    subject VARCHAR(255) NOT NULL,
    status VARCHAR(20) DEFAULT 'open',
    priority VARCHAR(20) DEFAULT 'medium',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    closed_at DATETIME,
    user_id INT NOT NULL,
    FOREIGN KEY (user_id) REFERENCES user(id)
);

-- Ticket Message table
CREATE TABLE IF NOT EXISTS ticket_message (
    id INT AUTO_INCREMENT PRIMARY KEY,
    message TEXT NOT NULL,
    is_from_admin BOOLEAN DEFAULT FALSE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    ticket_id INT NOT NULL,
    user_id INT NOT NULL,
    FOREIGN KEY (ticket_id) REFERENCES ticket(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES user(id)
);

-- Add initial roles
INSERT INTO role (name, description) VALUES 
    ('admin', 'Administrator with full access'),
    ('client', 'Client with limited access');

-- Add a default admin user (change password in production)
INSERT INTO user (username, email, password_hash, first_name, last_name, is_active) VALUES 
    ('admin', 'admin@example.com', '$2b$12$oRvGWNLYK2jfSaK.Jz7Y2.D1NwzCicGfXZdEeTmYPViWRJRdDRKYG', 'Admin', 'User', TRUE);

-- Link admin user to admin role
INSERT INTO user_roles (user_id, role_id) VALUES 
    (1, 1);

-- Add default server templates
INSERT INTO server_template (name, cpu_cores, ram_mb, disk_gb, bandwidth_gb, price_monthly, description, is_active) VALUES 
    ('Basic VPS', 1, 1024, 20, 1000, 5.99, 'Entry level VPS suitable for small websites and applications', TRUE),
    ('Standard VPS', 2, 2048, 40, 2000, 10.99, 'Standard VPS suitable for medium traffic websites', TRUE),
    ('Premium VPS', 4, 4096, 80, 3000, 19.99, 'Premium VPS with high performance for busy websites', TRUE),
    ('Enterprise VPS', 8, 8192, 160, 5000, 39.99, 'Enterprise grade VPS for resource-intensive applications', TRUE);
