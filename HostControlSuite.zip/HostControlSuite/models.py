from datetime import datetime
import secrets
import hashlib
import base64
import os
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
from app import db
from flask_login import UserMixin

# Association table for User and Role many-to-many relationship
user_roles = db.Table('user_roles',
    db.Column('user_id', db.Integer, db.ForeignKey('user.id'), primary_key=True),
    db.Column('role_id', db.Integer, db.ForeignKey('role.id'), primary_key=True)
)

class Role(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(80), unique=True, nullable=False)
    description = db.Column(db.String(255))

class User(UserMixin, db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(64), unique=True, nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password_hash = db.Column(db.String(256), nullable=False)
    first_name = db.Column(db.String(64))
    last_name = db.Column(db.String(64))
    company_name = db.Column(db.String(128))
    address = db.Column(db.String(256))
    city = db.Column(db.String(64))
    state = db.Column(db.String(64))
    country = db.Column(db.String(64))
    zip_code = db.Column(db.String(20))
    phone = db.Column(db.String(20))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Security fields
    two_factor_enabled = db.Column(db.Boolean, default=False)
    two_factor_secret = db.Column(db.String(32))
    last_login_at = db.Column(db.DateTime)
    last_login_ip = db.Column(db.String(45))
    account_locked = db.Column(db.Boolean, default=False)
    account_lock_reason = db.Column(db.String(255))
    account_lock_expiry = db.Column(db.DateTime)
    security_email_enabled = db.Column(db.Boolean, default=True)
    security_sms_enabled = db.Column(db.Boolean, default=False)
    email_verified = db.Column(db.Boolean, default=False)
    phone_verified = db.Column(db.Boolean, default=False)
    failed_login_attempts = db.Column(db.Integer, default=0)
    
    # Affiliate program fields
    affiliate_code = db.Column(db.String(16), unique=True)
    referred_by = db.Column(db.Integer, db.ForeignKey('user.id'))
    affiliate_earnings = db.Column(db.Float, default=0.0)
    is_affiliate = db.Column(db.Boolean, default=False)
    affiliate_tier = db.Column(db.Integer, default=0)  # Tier level in affiliate program
    monthly_spending = db.Column(db.Float, default=0.0)  # To track $20/month requirement
    affiliate_status = db.Column(db.String(20), default='inactive')  # inactive, pending, active
    
    # Relationships
    roles = db.relationship('Role', secondary=user_roles, lazy='subquery',
                          backref=db.backref('users', lazy=True))
    servers = db.relationship('Server', backref='user', lazy=True)
    invoices = db.relationship('Invoice', backref='user', lazy=True)
    tickets = db.relationship('Ticket', backref='user', lazy=True)
    login_attempts = db.relationship('LoginAttempt', backref='user', lazy=True)
    notifications = db.relationship('Notification', backref='user', lazy=True)
    payment_methods = db.relationship('PaymentMethod', backref='user', lazy=True)
    referrals = db.relationship('User', backref=db.backref('referrer', remote_side=[id]), lazy=True)
    
    def has_role(self, role_name):
        return any(role.name == role_name for role in self.roles)
    
    def check_account_lockout(self):
        """Check if account is locked out"""
        if not self.account_locked:
            return False
        
        # If lock has expired, unlock the account
        if self.account_lock_expiry and datetime.utcnow() > self.account_lock_expiry:
            self.account_locked = False
            self.account_lock_reason = None
            self.account_lock_expiry = None
            self.failed_login_attempts = 0
            db.session.commit()
            return False
            
        return True
    
    def update_login_stats(self, ip_address):
        """Update login statistics"""
        self.last_login_at = datetime.utcnow()
        self.last_login_ip = ip_address
        self.failed_login_attempts = 0
        db.session.commit()

class CloudProvider(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    provider_type = db.Column(db.String(50), nullable=False)  # aws, digitalocean, linode, vultr, etc.
    api_key = db.Column(db.String(255))
    api_secret = db.Column(db.String(255))
    region = db.Column(db.String(100))
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    notes = db.Column(db.Text)
    
    # Relationships
    templates = db.relationship('ServerTemplate', backref='provider', lazy=True)

class ServerTemplate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    cpu_cores = db.Column(db.Integer, nullable=False)
    ram_mb = db.Column(db.Integer, nullable=False)
    disk_gb = db.Column(db.Integer, nullable=False)
    bandwidth_gb = db.Column(db.Integer, nullable=False)
    price_monthly = db.Column(db.Float, nullable=False)
    description = db.Column(db.Text)
    is_active = db.Column(db.Boolean, default=True)
    featured = db.Column(db.Boolean, default=False)
    display_order = db.Column(db.Integer, default=0)
    provider_plan_id = db.Column(db.String(100))  # ID used by cloud provider API
    operating_systems = db.Column(db.String(255))  # Comma-separated list of available OS
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign keys
    provider_id = db.Column(db.Integer, db.ForeignKey('cloud_provider.id'))
    
    # Relationships
    servers = db.relationship('Server', backref='template', lazy=True)
    cart_items = db.relationship('CartItem', backref='template', lazy=True)

class Server(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    hostname = db.Column(db.String(255), nullable=False)
    ip_address = db.Column(db.String(45), nullable=False)
    status = db.Column(db.String(20), default='pending')  # pending, active, suspended, terminated
    operating_system = db.Column(db.String(100))
    username = db.Column(db.String(64))
    password = db.Column(db.String(256))
    ssh_port = db.Column(db.Integer, default=22)
    
    # Resource allocation
    cpu_cores = db.Column(db.Integer, nullable=False)
    ram_mb = db.Column(db.Integer, nullable=False)
    disk_gb = db.Column(db.Integer, nullable=False)
    bandwidth_gb = db.Column(db.Integer, nullable=False)
    bandwidth_used_gb = db.Column(db.Float, default=0)
    
    # Deployment status tracking
    deployment_status = db.Column(db.String(20), default='pending')  # pending, in_progress, complete, error
    deployment_progress = db.Column(db.Integer, default=0)  # 0-100 percent
    deployment_started_at = db.Column(db.DateTime)
    deployment_completed_at = db.Column(db.DateTime)
    deployment_error_message = db.Column(db.Text)
    deployment_log = db.Column(db.Text)  # Stores the deployment log for this server
    
    # Dates
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    expiry_date = db.Column(db.DateTime)
    last_renewal_date = db.Column(db.DateTime)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    template_id = db.Column(db.Integer, db.ForeignKey('server_template.id'), nullable=False)
    
    # Cloud provider integration
    provider_server_id = db.Column(db.String(255))  # ID used to identify the server with the cloud provider API
    
    # Relationships
    usage_logs = db.relationship('ServerUsage', backref='server', lazy=True)
    
    def get_status_badge_color(self):
        """Get bootstrap color class for server status badge"""
        status_colors = {
            'pending': 'warning',
            'active': 'success',
            'suspended': 'danger',
            'terminated': 'secondary',
            'provisioning': 'info'
        }
        return status_colors.get(self.status.lower(), 'primary')
    
    def get_progress_bar_color(self):
        """Get bootstrap color class for progress bar"""
        if self.deployment_status == 'error':
            return 'danger'
        elif self.deployment_status == 'complete':
            return 'success'
        else:
            return 'info'
            
    def add_deployment_log(self, log_entry):
        """Add a log entry to the deployment log"""
        timestamp = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
        new_log = f"[{timestamp}] {log_entry}\n"
        
        if self.deployment_log:
            self.deployment_log += new_log
        else:
            self.deployment_log = new_log
        
        db.session.commit()

class ServerUsage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    cpu_usage_percent = db.Column(db.Float)
    ram_usage_percent = db.Column(db.Float)
    disk_usage_percent = db.Column(db.Float)
    network_in_mb = db.Column(db.Float)
    network_out_mb = db.Column(db.Float)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Foreign keys
    server_id = db.Column(db.Integer, db.ForeignKey('server.id'), nullable=False)

class Invoice(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    invoice_number = db.Column(db.String(20), unique=True, nullable=False)
    amount = db.Column(db.Float, nullable=False)
    tax_amount = db.Column(db.Float, default=0)
    total_amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20), default='unpaid')  # unpaid, paid, cancelled, refunded
    issue_date = db.Column(db.DateTime, default=datetime.utcnow)
    due_date = db.Column(db.DateTime, nullable=False)
    paid_date = db.Column(db.DateTime)
    notes = db.Column(db.Text)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Relationships
    items = db.relationship('InvoiceItem', backref='invoice', lazy=True)
    transactions = db.relationship('Transaction', backref='invoice', lazy=True)

class InvoiceItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    description = db.Column(db.String(255), nullable=False)
    amount = db.Column(db.Float, nullable=False)
    quantity = db.Column(db.Integer, default=1)
    server_id = db.Column(db.Integer, db.ForeignKey('server.id'))
    
    # Foreign keys
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoice.id'), nullable=False)

class Transaction(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    transaction_id = db.Column(db.String(100), unique=True)
    gateway = db.Column(db.String(50))  # paypal, stripe, etc.
    amount = db.Column(db.Float, nullable=False)
    status = db.Column(db.String(20))  # success, failed, pending
    transaction_date = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Foreign keys
    invoice_id = db.Column(db.Integer, db.ForeignKey('invoice.id'), nullable=False)

class Ticket(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    subject = db.Column(db.String(255), nullable=False)
    status = db.Column(db.String(20), default='open')  # open, answered, closed
    priority = db.Column(db.String(20), default='medium')  # low, medium, high, critical
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    closed_at = db.Column(db.DateTime)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Relationships
    messages = db.relationship('TicketMessage', backref='ticket', lazy=True)

class TicketMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    message = db.Column(db.Text, nullable=False)
    is_from_admin = db.Column(db.Boolean, default=False)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Foreign keys
    ticket_id = db.Column(db.Integer, db.ForeignKey('ticket.id'), nullable=False)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)


class Cart(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('cart', uselist=False, lazy=True))
    items = db.relationship('CartItem', backref='cart', lazy=True, cascade="all, delete-orphan")
    
    @property
    def subtotal(self):
        """Calculate cart subtotal"""
        return sum(item.subtotal for item in self.items)
    
    @property
    def item_count(self):
        """Get number of items in cart"""
        return len(self.items)

class CartItem(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    quantity = db.Column(db.Integer, default=1)
    billing_cycle = db.Column(db.String(20), default='monthly')  # hourly, monthly, quarterly, semi_annual, annual, biennial, quadrennial
    operating_system = db.Column(db.String(100))
    hostname = db.Column(db.String(255))
    addons = db.Column(db.String(255))  # Comma-separated list of addons: backup,ddos,monitoring,extra_ram,cpu_priority
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    
    # Foreign keys
    cart_id = db.Column(db.Integer, db.ForeignKey('cart.id'), nullable=False)
    template_id = db.Column(db.Integer, db.ForeignKey('server_template.id'), nullable=False)
    
    @property
    def subtotal(self):
        """Calculate item subtotal"""
        # Apply discount for longer billing cycles
        from utils.billing_utils import get_price_multiplier
        
        # Get base multiplier based on billing cycle
        multiplier = get_price_multiplier(self.billing_cycle)
        
        # Apply discounts for longer billing cycles
        if self.billing_cycle == 'hourly':
            discount = 0.0  # No discount for hourly billing
        elif self.billing_cycle == 'monthly':
            discount = 0.0  # No discount for monthly billing
        elif self.billing_cycle == 'quarterly':
            discount = 0.05  # 5% discount for quarterly billing
        elif self.billing_cycle == 'semi_annual':
            discount = 0.1  # 10% discount for 6-month billing
        elif self.billing_cycle == 'annual':
            discount = 0.15  # 15% discount for annual billing
        elif self.billing_cycle == 'biennial':
            discount = 0.2  # 20% discount for 2-year billing
        elif self.billing_cycle == 'quadrennial':
            discount = 0.25  # 25% discount for 4-year billing
        else:
            discount = 0.0  # Default - no discount
        
        # Start with base price
        base_price = self.template.price_monthly
        
        # Calculate addon costs
        addon_price = 0.0
        if self.addons:
            addon_list = self.addons.split(',')
            for addon in addon_list:
                if addon == 'backup':
                    addon_price += base_price * 0.15  # 15% for backups
                elif addon == 'ddos':
                    addon_price += base_price * 0.10  # 10% for DDoS protection
                elif addon == 'monitoring':
                    addon_price += base_price * 0.08  # 8% for enhanced monitoring
                elif addon == 'extra_ram':
                    addon_price += base_price * 0.20  # 20% for extra RAM
                elif addon == 'cpu_priority':
                    addon_price += base_price * 0.12  # 12% for CPU priority boost
        
        # Calculate price with discount and addons
        unit_price = (base_price + addon_price) * multiplier * (1 - discount)
        return unit_price * self.quantity

class LoginAttempt(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    ip_address = db.Column(db.String(45))
    user_agent = db.Column(db.String(255))
    successful = db.Column(db.Boolean, default=False)
    timestamp = db.Column(db.DateTime, default=datetime.utcnow)

class Notification(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    title = db.Column(db.String(255), nullable=False)
    message = db.Column(db.Text, nullable=False)
    is_read = db.Column(db.Boolean, default=False)
    notification_type = db.Column(db.String(50), default='general')  # general, security, billing, system
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    read_at = db.Column(db.DateTime)
    
class PaymentMethod(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    payment_type = db.Column(db.String(30), nullable=False)  # credit_card, paypal, google_pay, crypto
    name = db.Column(db.String(100))  # Friendly name for the payment method
    is_default = db.Column(db.Boolean, default=False)
    card_last_four = db.Column(db.String(4))  # Last 4 digits of card
    card_brand = db.Column(db.String(20))  # Visa, MasterCard, etc.
    card_expiry_month = db.Column(db.Integer)
    card_expiry_year = db.Column(db.Integer)
    billing_address = db.Column(db.String(255))
    billing_city = db.Column(db.String(100))
    billing_state = db.Column(db.String(100))
    billing_country = db.Column(db.String(100))
    billing_zip = db.Column(db.String(20))
    token = db.Column(db.String(255))  # Payment processor token
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)

class Settings(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    setting_key = db.Column(db.String(100), unique=True, nullable=False)
    setting_value = db.Column(db.Text)
    setting_description = db.Column(db.String(255))
    is_public = db.Column(db.Boolean, default=False)  # Whether the setting can be exposed to clients
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    @classmethod
    def get_value(cls, key, default=None):
        """Get a setting value by key"""
        setting = cls.query.filter_by(setting_key=key).first()
        if setting:
            # Handle boolean values
            if setting.setting_value.lower() == 'true':
                return True
            elif setting.setting_value.lower() == 'false':
                return False
            # Handle integer values
            try:
                return int(setting.setting_value)
            except ValueError:
                pass
            # Return as string
            return setting.setting_value
        return default
    
    @classmethod
    def set_value(cls, key, value, description=None, is_public=False):
        """Set a setting value"""
        setting = cls.query.filter_by(setting_key=key).first()
        if setting:
            setting.setting_value = str(value)
            if description:
                setting.setting_description = description
            setting.is_public = is_public
        else:
            setting = cls(
                setting_key=key,
                setting_value=str(value),
                setting_description=description,
                is_public=is_public
            )
            db.session.add(setting)
        db.session.commit()
        return setting


class LicenseTemplate(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    product_name = db.Column(db.String(100), nullable=False)
    version = db.Column(db.String(50))
    description = db.Column(db.Text)
    max_servers = db.Column(db.Integer, default=1)
    validity_days = db.Column(db.Integer, default=365)
    features = db.Column(db.Text)  # Store as JSON string
    is_active = db.Column(db.Boolean, default=True)
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Relationships
    licenses = db.relationship('License', backref='template', lazy=True)
    
    def __repr__(self):
        return f'<LicenseTemplate {self.name}>'

class License(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    license_key = db.Column(db.String(255), unique=True, nullable=False)
    encrypted_key = db.Column(db.Text, nullable=False)
    product_name = db.Column(db.String(100), nullable=False)
    version = db.Column(db.String(50))
    max_servers = db.Column(db.Integer, default=1)
    is_active = db.Column(db.Boolean, default=True)
    issue_date = db.Column(db.DateTime, default=datetime.utcnow)
    expiry_date = db.Column(db.DateTime)
    last_check_date = db.Column(db.DateTime)
    hardware_id = db.Column(db.String(255))
    ip_restriction = db.Column(db.String(255))
    notes = db.Column(db.Text)
    features = db.Column(db.Text)  # Store as JSON string
    created_at = db.Column(db.DateTime, default=datetime.utcnow)
    updated_at = db.Column(db.DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    
    # Foreign keys
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    template_id = db.Column(db.Integer, db.ForeignKey('license_template.id'), nullable=True)
    
    # Relationships
    user = db.relationship('User', backref=db.backref('licenses', lazy=True))
    
    @staticmethod
    def generate_license_key(user_id, product_name, max_servers=1, validity_days=365, template_id=None, version=None, notes=None, features=None):
        """Generate a unique license key"""
        # Create a random token
        random_token = secrets.token_hex(16)
        
        # Create a hash based on user_id, product, current time and the random token
        key_base = f"{user_id}-{product_name}-{datetime.utcnow().isoformat()}-{random_token}"
        key_hash = hashlib.sha256(key_base.encode()).hexdigest()
        
        # Format the license key in a user-friendly format (XXXX-XXXX-XXXX-XXXX)
        license_key = "-".join([key_hash[i:i+4].upper() for i in range(0, 16, 4)])
        
        # Calculate expiry date
        expiry_date = datetime.utcnow().replace(hour=23, minute=59, second=59)
        expiry_date = expiry_date.replace(day=expiry_date.day + validity_days)
        
        # Create encryption key for this license
        encryption_key = os.environ.get('LICENSE_ENCRYPTION_KEY', 'default_encryption_key_change_in_production')
        
        # Data to be encrypted
        license_data = {
            'license_key': license_key,
            'user_id': user_id,
            'product_name': product_name,
            'max_servers': max_servers,
            'issue_date': datetime.utcnow().isoformat(),
            'expiry_date': expiry_date.isoformat(),
            'features': features
        }
        
        # Convert to string
        license_data_str = str(license_data)
        
        # Encrypt the license data
        encrypted_data = License.encrypt_license_data(license_data_str, encryption_key)
        
        # Create and save the license
        license = License(
            license_key=license_key,
            encrypted_key=encrypted_data,
            product_name=product_name,
            version=version,
            max_servers=max_servers,
            expiry_date=expiry_date,
            notes=notes,
            features=features,
            user_id=user_id,
            template_id=template_id
        )
        
        db.session.add(license)
        db.session.commit()
        
        return license_key
    
    @staticmethod
    def encrypt_license_data(data, key):
        """Encrypt license data using AES"""
        # Ensure the key is 32 bytes long (256 bits)
        encryption_key = hashlib.sha256(key.encode()).digest()
        
        # Generate a random 16-byte initialization vector
        iv = os.urandom(16)
        
        # Create AES cipher in CBC mode
        cipher = AES.new(encryption_key, AES.MODE_CBC, iv)
        
        # Pad the data to be a multiple of 16 bytes (AES block size)
        padded_data = pad(data.encode(), 16)
        
        # Encrypt the data
        encrypted_data = cipher.encrypt(padded_data)
        
        # Combine the IV and encrypted data and encode in base64
        encrypted_package = base64.b64encode(iv + encrypted_data).decode('utf-8')
        
        return encrypted_package
    
    @staticmethod
    def decrypt_license_data(encrypted_data, key):
        """Decrypt license data"""
        try:
            # Ensure the key is 32 bytes long (256 bits)
            encryption_key = hashlib.sha256(key.encode()).digest()
            
            # Decode the base64 encoded encrypted package
            encrypted_package = base64.b64decode(encrypted_data.encode('utf-8'))
            
            # Extract the IV (first 16 bytes) and the encrypted data
            iv = encrypted_package[:16]
            encrypted_data = encrypted_package[16:]
            
            # Create AES cipher in CBC mode with the same IV
            cipher = AES.new(encryption_key, AES.MODE_CBC, iv)
            
            # Decrypt the data and remove padding
            decrypted_data = unpad(cipher.decrypt(encrypted_data), 16)
            
            return decrypted_data.decode('utf-8')
        except Exception as e:
            return f"Error decrypting license: {str(e)}"
    
    def verify_license(self, hardware_id=None, ip_address=None):
        """Verify if the license is valid"""
        current_time = datetime.utcnow()
        
        # Check if license is active
        if not self.is_active:
            return False, "License is not active"
        
        # Check expiry date
        if self.expiry_date and current_time > self.expiry_date:
            return False, "License has expired"
        
        # Check hardware ID restriction if applicable
        if self.hardware_id and hardware_id and self.hardware_id != hardware_id:
            return False, "Hardware ID mismatch"
        
        # Check IP restriction if applicable
        if self.ip_restriction and ip_address and self.ip_restriction != ip_address:
            return False, "IP address not authorized"
        
        # Update last check date
        self.last_check_date = current_time
        db.session.commit()
        
        return True, "License is valid"
