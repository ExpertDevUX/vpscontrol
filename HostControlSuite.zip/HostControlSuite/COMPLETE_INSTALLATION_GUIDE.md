# Complete VPS Control Panel Installation Guide

This comprehensive guide provides detailed instructions for installing and configuring the VPS Control Panel on your own server. Follow these steps carefully to set up a fully functional instance.

**Author:** Tony Pham  
**Contact:** info@hwosecurity.org

## System Requirements

- **Operating System**: Ubuntu 20.04 LTS or newer (recommended), any Linux distribution, Windows Server, or macOS
- **CPU**: 2+ cores recommended
- **Memory**: Minimum 2GB RAM (4GB recommended)
- **Storage**: 20GB+ free disk space
- **Database**: PostgreSQL 12+ (recommended) or MySQL 8+
- **Python**: Version 3.10+ (3.11 or 3.12 recommended)

## Prerequisites Installation

### On Ubuntu/Debian

```bash
# Update system packages
sudo apt update
sudo apt upgrade -y

# Install required system packages
sudo apt install -y python3 python3-pip python3-venv git postgresql postgresql-contrib libpq-dev

# Start and enable PostgreSQL service
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Install additional dependencies for PDF generation and QR codes
sudo apt install -y libcairo2-dev libjpeg-dev libgif-dev
```

### On CentOS/RHEL

```bash
# Update system packages
sudo dnf update -y

# Install required system packages
sudo dnf install -y python3 python3-pip git postgresql-server postgresql-devel

# Initialize and start PostgreSQL
sudo postgresql-setup --initdb
sudo systemctl start postgresql
sudo systemctl enable postgresql

# Install additional dependencies
sudo dnf install -y cairo-devel libjpeg-devel
```

## Step 1: Database Setup

Create a PostgreSQL database for the application:

```bash
# Switch to postgres user
sudo -i -u postgres

# Create a new user for the application
createuser --interactive --pwprompt vpscontrol
# Enter password when prompted

# Create a new database
createdb --owner=vpscontrol vpscontrolpanel

# Exit postgres user shell
exit
```

## Step 2: Application Installation

```bash
# Create a directory for the application
mkdir -p /opt/vpscontrol
cd /opt/vpscontrol

# Clone the repository (or download and extract the ZIP file)
git clone https://github.com/yourusername/vps-control-panel.git .
# If you don't have a Git repository, you can copy your files here

# Create and activate a virtual environment
python3 -m venv venv
source venv/bin/activate

# Install required Python packages
pip install -r requirements.txt

# If requirements.txt is not available, install packages manually:
pip install Flask Flask-SQLAlchemy Flask-Login Flask-WTF SQLAlchemy Werkzeug gunicorn email-validator psycopg2-binary pycryptodome pyotp boto3 reportlab PyPDF2 qrcode anthropic html2text python-dotenv
```

## Step 3: Environment Configuration

Create a `.env` file in your project directory with the database connection string and other settings:

```bash
# Copy the example environment file
cp .env.example .env

# Edit the environment file with your settings
nano .env
```

Ensure at minimum the following variables are set correctly:

```
DATABASE_URL=postgresql://vpscontrol:your_password@localhost:5432/vpscontrolpanel
SESSION_SECRET=a_secure_random_string
```

You can generate a secure random string with:
```bash
python -c "import secrets; print(secrets.token_hex(32))"
```

## Step 4: Database Initialization

The application is designed to initialize the database automatically, but you can also run it manually:

```bash
# Activate virtual environment if not already active
source venv/bin/activate

# Run database initialization script
python -c "from database import init_database; init_database()"
```

## Step 5: Running the Application for Testing

Before setting up for production, test that the application works:

```bash
# Make sure your virtual environment is activated
source venv/bin/activate

# Run the application
python main.py
```

The application should start on port 5000. Visit http://your_server_ip:5000 in your browser. 

Log in with default credentials:
- Username: `admin`
- Email: `admin@example.com`
- Password: `admin123`

**Important:** Change these credentials immediately after first login!

## Step 6: Production Deployment

For production, we recommend using Gunicorn with Nginx as a reverse proxy.

### Configure Gunicorn Service

Create a systemd service file:

```bash
sudo nano /etc/systemd/system/vpscontrol.service
```

Add the following content:

```
[Unit]
Description=VPS Control Panel
After=network.target postgresql.service

[Service]
User=your_username
Group=www-data
WorkingDirectory=/opt/vpscontrol
Environment="PATH=/opt/vpscontrol/venv/bin"
EnvironmentFile=/opt/vpscontrol/.env
ExecStart=/opt/vpscontrol/venv/bin/gunicorn --bind 127.0.0.1:5000 --workers 3 main:app
Restart=always
RestartSec=5

[Install]
WantedBy=multi-user.target
```

Replace `your_username` with the username that will run the application.

### Enable and Start the Service

```bash
sudo systemctl daemon-reload
sudo systemctl enable vpscontrol
sudo systemctl start vpscontrol
```

Check the status to ensure it's running:

```bash
sudo systemctl status vpscontrol
```

### Configure Nginx as Reverse Proxy

Install Nginx if not already installed:

```bash
sudo apt install -y nginx
```

Create a Nginx configuration file:

```bash
sudo nano /etc/nginx/sites-available/vpscontrol
```

Add the following configuration:

```
server {
    listen 80;
    server_name your_domain.com;

    location / {
        proxy_pass http://127.0.0.1:5000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
}
```

Replace `your_domain.com` with your actual domain name.

### Enable the Nginx Configuration

```bash
sudo ln -s /etc/nginx/sites-available/vpscontrol /etc/nginx/sites-enabled/
sudo nginx -t  # Test the configuration
sudo systemctl restart nginx
```

### SSL Configuration with Let's Encrypt (Highly Recommended)

Secure your site with HTTPS:

```bash
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your_domain.com
```

Follow the prompts to complete the SSL certificate installation.

## Step 7: Security Recommendations

1. **Firewall Configuration**:
   ```bash
   sudo ufw allow 22/tcp  # SSH
   sudo ufw allow 80/tcp  # HTTP
   sudo ufw allow 443/tcp # HTTPS
   sudo ufw enable
   ```

2. **Regular Backups**:
   Set up daily database backups:
   ```bash
   # Create a backup script
   sudo nano /opt/vpscontrol/backup.sh
   ```
   
   Add the following content:
   ```bash
   #!/bin/bash
   BACKUP_DIR="/opt/vpscontrol/backups"
   TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
   mkdir -p $BACKUP_DIR
   
   # Activate virtual environment
   source /opt/vpscontrol/venv/bin/activate
   
   # Run backup
   cd /opt/vpscontrol
   python -c "from database import backup_database; backup_database('$BACKUP_DIR/backup_$TIMESTAMP.sql')"
   
   # Remove backups older than 30 days
   find $BACKUP_DIR -name "backup_*.sql" -type f -mtime +30 -delete
   ```
   
   Make it executable and add to crontab:
   ```bash
   sudo chmod +x /opt/vpscontrol/backup.sh
   sudo crontab -e
   ```
   
   Add the line:
   ```
   0 3 * * * /opt/vpscontrol/backup.sh > /opt/vpscontrol/backups/backup_log.txt 2>&1
   ```

3. **Update Regularly**:
   Create an update script:
   ```bash
   sudo nano /opt/vpscontrol/update.sh
   ```
   
   Add:
   ```bash
   #!/bin/bash
   cd /opt/vpscontrol
   
   # Pull latest changes if using git
   git pull
   
   # Activate virtual environment
   source venv/bin/activate
   
   # Update dependencies
   pip install -r requirements.txt
   
   # Restart service
   sudo systemctl restart vpscontrol
   ```
   
   Make executable:
   ```bash
   sudo chmod +x /opt/vpscontrol/update.sh
   ```

## Step 8: Recommended Monitoring Setup

We recommend setting up basic system monitoring:

```bash
sudo apt install -y prometheus-node-exporter
```

For more comprehensive monitoring, consider installing:
- Prometheus for metrics collection
- Grafana for dashboards
- Loki for log aggregation

## Step 9: Database Maintenance

Schedule PostgreSQL vacuuming:

```bash
sudo nano /etc/postgresql/12/main/postgresql.conf
```

Find and set:
```
autovacuum = on
```

## Troubleshooting

### Common Issues

1. **Database Connection Issues**
   - Check that PostgreSQL is running: `sudo systemctl status postgresql`
   - Verify connection details in `.env` file
   - Ensure database user has proper permissions
   
2. **Application Won't Start**
   - Check logs: `sudo journalctl -u vpscontrol`
   - Verify Python dependencies: `pip install -r requirements.txt`
   - Ensure proper file permissions in application directory
   
3. **Web Interface Not Loading**
   - Check Nginx configuration and logs: `sudo nginx -t` and `sudo tail -f /var/log/nginx/error.log`
   - Verify Gunicorn is running: `sudo systemctl status vpscontrol`
   - Check firewall settings: `sudo ufw status`

4. **Environment Variables Not Loaded**
   - Check if `.env` file is properly formatted with no spaces around the `=` sign
   - Ensure the path to `.env` is correct in `vpscontrol.service`
   - Restart the service after modifying environment variables

### Debug Mode

For debugging, you can temporarily run the application in debug mode:

```bash
# Activate virtual environment
source venv/bin/activate

# Set environment variable for debug mode
export FLASK_ENV=development

# Run with debugging
python main.py
```

## Support and Contributions

For additional support, please contact:
- **Author:** Tony Pham
- **Email:** info@hwosecurity.org

## Conclusion

Your VPS Control Panel should now be installed, secured, and running in production mode with proper monitoring and backup procedures in place. Remember to regularly update the application and its dependencies for security and feature improvements.

---

For additional configuration options and customizations, please refer to the [README.md](README.md) documentation.