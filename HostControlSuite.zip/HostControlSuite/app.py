import os
import logging
from datetime import datetime
from flask import Flask, request, abort
from flask_sqlalchemy import SQLAlchemy
from sqlalchemy.orm import DeclarativeBase
from flask_login import LoginManager
from config import get_config

# Configure logging
logging.basicConfig(level=logging.DEBUG)
logger = logging.getLogger(__name__)

# Create base class for models
class Base(DeclarativeBase):
    pass

# Initialize SQLAlchemy with the base class
db = SQLAlchemy(model_class=Base)

# Define get_env function for templates
def get_env(env_var, default=''):
    """Get environment variable value safely"""
    return os.environ.get(env_var, default)

# Create and configure Flask application
app = Flask(__name__)

# Load configuration
config = get_config()
app.config.from_object(config)

# Set a secret key from config
app.secret_key = app.config.get('SECRET_KEY')

# CSRF protection disabled as per user request
app.config['WTF_CSRF_ENABLED'] = False

# Add global functions to Jinja templates
app.jinja_env.globals.update(now=datetime.now, get_env=get_env)

# Initialize the app with the extension
db.init_app(app)

# Initialize Login Manager
login_manager = LoginManager()
login_manager.init_app(app)
login_manager.login_view = 'auth.login'
login_manager.login_message_category = 'info'

# Import models to create tables
with app.app_context():
    import models
    db.create_all()
    logger.info("Database tables created")

    # Check if admin exists, if not create one
    from models import User, Role, Settings
    from werkzeug.security import generate_password_hash
    
    admin_role = Role.query.filter_by(name='admin').first()
    if not admin_role:
        admin_role = Role(name='admin', description='Administrator')
        db.session.add(admin_role)
        db.session.commit()
        logger.info("Admin role created")
    
    admin_user = User.query.filter_by(email='admin@example.com').first()
    if not admin_user:
        admin_user = User(
            username='admin',
            email='admin@example.com',
            password_hash=generate_password_hash('admin123'),
            first_name='Admin',
            last_name='User',
            is_active=True
        )
        admin_user.roles.append(admin_role)
        db.session.add(admin_user)
        db.session.commit()
        logger.info("Admin user created")
        
    # Initialize settings if they don't exist
    if not Settings.query.filter_by(setting_key='captcha_enabled').first():
        Settings.set_value(
            'captcha_enabled', 
            'false', 
            'Enable or disable CAPTCHA on login and registration pages',
            is_public=True
        )
        logger.info("CAPTCHA setting initialized (disabled by default)")

# Import and register blueprints
from routes.auth import auth_bp
from routes.admin import admin_bp
from routes.client import client_bp
from routes.vps import vps_bp
from routes.billing import billing_bp
from routes.support import support_bp
from routes.license import license_bp
from routes.deployment import deployment_bp
from routes.migrate import migrate_bp
from routes.cloud import cloud_bp
from routes.cart import cart_bp
from routes.payment import payment_bp
from routes.chat import chat_bp

app.register_blueprint(auth_bp)
app.register_blueprint(admin_bp, url_prefix='/admin')
app.register_blueprint(client_bp, url_prefix='/client')
app.register_blueprint(vps_bp, url_prefix='/vps')
app.register_blueprint(billing_bp, url_prefix='/billing')
app.register_blueprint(support_bp, url_prefix='/support')
app.register_blueprint(license_bp, url_prefix='/license')
app.register_blueprint(deployment_bp, url_prefix='/deployment')
app.register_blueprint(migrate_bp, url_prefix='/migrate')
app.register_blueprint(cloud_bp)
app.register_blueprint(cart_bp, url_prefix='/cart')
app.register_blueprint(payment_bp, url_prefix='/payment')
app.register_blueprint(chat_bp, url_prefix='/chat')

# Load user for login_manager
@login_manager.user_loader
def load_user(user_id):
    from models import User
    return User.query.get(int(user_id))

# Register error handlers
@app.errorhandler(404)
def page_not_found(e):
    return 'Page not found', 404

@app.errorhandler(500)
def internal_server_error(e):
    return 'Internal server error', 500
