# VPS Control Panel Dependencies

Below is a list of dependencies required for running the VPS Control Panel. Use your package manager (pip, pip3, etc.) to install these dependencies.

**Author:** Tony Pham  
**Contact:** info@hwosecurity.org

## Core Dependencies
- Flask==2.3.3
- Flask-SQLAlchemy==3.1.1
- Flask-Login==0.6.3
- Flask-WTF==1.2.1
- SQLAlchemy==2.0.23
- Werkzeug==2.3.7
- gunicorn==23.0.0
- email-validator==2.1.0.post1

## Database Connectors
- psycopg2-binary==2.9.9
- PyMySQL==1.1.0
- mysqlclient==2.2.0

## Security
- pycryptodome==3.19.0
- pyotp==2.9.0

## Cloud Providers
- boto3==1.34.31

## Document Generation
- reportlab==4.0.9
- PyPDF2==3.0.1
- qrcode==7.4.2

## AI Integration
- anthropic==0.19.1

## Utilities
- html2text==2024.2.26
- python-dotenv==1.0.1

## For Development Only (optional)
- pytest==7.4.3
- pytest-cov==4.1.0
- black==23.12.0
- flake8==6.1.0

## Installing Dependencies

You can install all required dependencies using:

```bash
pip install Flask==2.3.3 Flask-SQLAlchemy==3.1.1 Flask-Login==0.6.3 Flask-WTF==1.2.1 SQLAlchemy==2.0.23 Werkzeug==2.3.7 gunicorn==23.0.0 email-validator==2.1.0.post1 psycopg2-binary==2.9.9 PyMySQL==1.1.0 mysqlclient==2.2.0 pycryptodome==3.19.0 pyotp==2.9.0 boto3==1.34.31 reportlab==4.0.9 PyPDF2==3.0.1 qrcode==7.4.2 anthropic==0.19.1 html2text==2024.2.26 python-dotenv==1.0.1
```

Or for development environment:

```bash
pip install Flask==2.3.3 Flask-SQLAlchemy==3.1.1 Flask-Login==0.6.3 Flask-WTF==1.2.1 SQLAlchemy==2.0.23 Werkzeug==2.3.7 gunicorn==23.0.0 email-validator==2.1.0.post1 psycopg2-binary==2.9.9 PyMySQL==1.1.0 mysqlclient==2.2.0 pycryptodome==3.19.0 pyotp==2.9.0 boto3==1.34.31 reportlab==4.0.9 PyPDF2==3.0.1 qrcode==7.4.2 anthropic==0.19.1 html2text==2024.2.26 python-dotenv==1.0.1 pytest==7.4.3 pytest-cov==4.1.0 black==23.12.0 flake8==6.1.0
```