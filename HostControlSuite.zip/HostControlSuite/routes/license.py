from flask import Blueprint, render_template, request, redirect, url_for, flash, jsonify, send_file
from flask_login import login_required, current_user
from datetime import datetime, timedelta
import io
import json
import os

from models import db, License, User, LicenseTemplate
from routes.admin import admin_required

license_bp = Blueprint('license', __name__)

@license_bp.route('/')
@login_required
def index():
    """List licenses for current user"""
    if current_user.has_role('admin'):
        licenses = License.query.order_by(License.created_at.desc()).all()
    else:
        licenses = License.query.filter_by(user_id=current_user.id).order_by(License.created_at.desc()).all()
    
    return render_template('license/index.html', licenses=licenses)

@license_bp.route('/view/<int:license_id>')
@login_required
def view(license_id):
    """View license details"""
    license = License.query.get_or_404(license_id)
    
    # Security check - only owner or admin can view
    if license.user_id != current_user.id and not current_user.has_role('admin'):
        flash('You do not have permission to view this license', 'danger')
        return redirect(url_for('license.index'))
    
    return render_template('license/view.html', license=license)

@license_bp.route('/generate', methods=['GET', 'POST'])
@login_required
@admin_required
def generate():
    """Generate a new license (admin only)"""
    if request.method == 'POST':
        product_name = request.form.get('product_name')
        version = request.form.get('version')
        max_servers = int(request.form.get('max_servers', 1))
        validity_days = int(request.form.get('validity_days', 365))
        notes = request.form.get('notes')
        
        # Admin can generate for any user
        user_id = int(request.form.get('user_id'))
        
        # Generate license key
        license_key = License.generate_license_key(user_id, product_name, max_servers, validity_days)
        
        # Create license object
        expiry_date = datetime.utcnow() + timedelta(days=validity_days)
        
        # Generate a random encryption key for this license
        # In a real system, you might want to store this securely or derive it from user data
        encryption_key = os.urandom(16)
        
        # Encrypt the license data
        license_data = {
            'license_key': license_key,
            'user_id': user_id,
            'product_name': product_name,
            'version': version,
            'max_servers': max_servers,
            'issue_date': datetime.utcnow().isoformat(),
            'expiry_date': expiry_date.isoformat() if validity_days > 0 else None
        }
        
        encrypted_data = License.encrypt_license_data(json.dumps(license_data), encryption_key)
        
        new_license = License(
            license_key=license_key,
            encrypted_key=encrypted_data.hex(),
            product_name=product_name,
            version=version,
            max_servers=max_servers,
            is_active=True,
            issue_date=datetime.utcnow(),
            expiry_date=expiry_date if validity_days > 0 else None,
            notes=notes,
            user_id=user_id
        )
        
        db.session.add(new_license)
        db.session.commit()
        
        flash(f'License key generated successfully: {license_key}', 'success')
        return redirect(url_for('license.view', license_id=new_license.id))
    
    # GET request - show the form
    users = User.query.all()
    
    return render_template('license/generate.html', users=users)

@license_bp.route('/verify/<license_key>')
def verify(license_key):
    """Verify a license (public endpoint)"""
    license = License.query.filter_by(license_key=license_key).first()
    
    if not license:
        return jsonify({
            'valid': False,
            'message': 'License key not found'
        })
    
    # Get optional hardware_id and ip from request
    hardware_id = request.args.get('hardware_id')
    ip_address = request.args.get('ip', request.remote_addr)
    
    # Verify the license
    valid, message = license.verify_license(hardware_id, ip_address)
    
    # Update last check date
    license.last_check_date = datetime.utcnow()
    db.session.commit()
    
    return jsonify({
        'valid': valid,
        'message': message,
        'product': license.product_name,
        'version': license.version,
        'expiry_date': license.expiry_date.isoformat() if license.expiry_date else None
    })

@license_bp.route('/update/<int:license_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def update(license_id):
    """Update license details"""
    license = License.query.get_or_404(license_id)
    
    if request.method == 'POST':
        # Update license details
        license.product_name = request.form.get('product_name')
        license.version = request.form.get('version')
        license.max_servers = int(request.form.get('max_servers', 1))
        license.notes = request.form.get('notes')
        license.is_active = 'is_active' in request.form
        
        # Handle expiry date
        if request.form.get('has_expiry') == 'yes':
            expiry_str = request.form.get('expiry_date')
            try:
                license.expiry_date = datetime.strptime(expiry_str, '%Y-%m-%d')
            except ValueError:
                flash('Invalid expiry date format. Use YYYY-MM-DD', 'danger')
                return redirect(url_for('license.update', license_id=license.id))
        else:
            license.expiry_date = None
        
        # Handle restrictions
        license.hardware_id = request.form.get('hardware_id') or None
        license.ip_restriction = request.form.get('ip_restriction') or None
        
        db.session.commit()
        flash('License has been updated successfully', 'success')
        return redirect(url_for('license.view', license_id=license.id))
    
    # GET request - show the form
    return render_template('license/update.html', license=license)

@license_bp.route('/revoke/<int:license_id>', methods=['POST'])
@login_required
@admin_required
def revoke(license_id):
    """Revoke a license"""
    license = License.query.get_or_404(license_id)
    
    license.is_active = False
    db.session.commit()
    
    flash(f'License key {license.license_key} has been revoked', 'success')
    return redirect(url_for('license.view', license_id=license.id))

@license_bp.route('/download/<int:license_id>')
@login_required
def download(license_id):
    """Download license key file"""
    license = License.query.get_or_404(license_id)
    
    # Security check - only owner or admin can download
    if license.user_id != current_user.id and not current_user.has_role('admin'):
        flash('You do not have permission to download this license', 'danger')
        return redirect(url_for('license.index'))
    
    # Create a license file
    license_data = {
        'license_key': license.license_key,
        'product_name': license.product_name,
        'version': license.version,
        'max_servers': license.max_servers,
        'issue_date': license.issue_date.isoformat(),
        'expiry_date': license.expiry_date.isoformat() if license.expiry_date else None,
        'encrypted': license.encrypted_key
    }
    
    # Create a file-like object
    file_data = io.BytesIO()
    file_data.write(json.dumps(license_data, indent=2).encode('utf-8'))
    file_data.seek(0)
    
    # Generate a filename
    filename = f"{license.product_name.lower().replace(' ', '_')}_license_{license.license_key[:8]}.lic"
    
    return send_file(
        file_data,
        mimetype='application/octet-stream',
        as_attachment=True,
        download_name=filename
    )

# License Template Management

@license_bp.route('/templates')
@login_required
@admin_required
def templates():
    """List all license templates"""
    templates = LicenseTemplate.query.order_by(LicenseTemplate.name).all()
    return render_template('license/templates.html', templates=templates)

@license_bp.route('/templates/create', methods=['GET', 'POST'])
@login_required
@admin_required
def create_template():
    """Create a new license template"""
    if request.method == 'POST':
        name = request.form.get('name')
        product_name = request.form.get('product_name')
        version = request.form.get('version')
        description = request.form.get('description')
        max_servers = int(request.form.get('max_servers', 1))
        validity_days = int(request.form.get('validity_days', 365))
        
        # Handle features (JSON string)
        features_list = request.form.getlist('feature')
        features = json.dumps(features_list) if features_list else None
        
        template = LicenseTemplate(
            name=name,
            product_name=product_name,
            version=version,
            description=description,
            max_servers=max_servers,
            validity_days=validity_days,
            features=features,
            is_active=True
        )
        
        db.session.add(template)
        db.session.commit()
        
        flash(f'License template "{name}" created successfully', 'success')
        return redirect(url_for('license.templates'))
    
    return render_template('license/template_form.html', template=None)

@license_bp.route('/templates/edit/<int:template_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_template(template_id):
    """Edit an existing license template"""
    template = LicenseTemplate.query.get_or_404(template_id)
    
    if request.method == 'POST':
        template.name = request.form.get('name')
        template.product_name = request.form.get('product_name')
        template.version = request.form.get('version')
        template.description = request.form.get('description')
        template.max_servers = int(request.form.get('max_servers', 1))
        template.validity_days = int(request.form.get('validity_days', 365))
        template.is_active = 'is_active' in request.form
        
        # Handle features (JSON string)
        features_list = request.form.getlist('feature')
        template.features = json.dumps(features_list) if features_list else None
        
        db.session.commit()
        
        flash(f'License template "{template.name}" updated successfully', 'success')
        return redirect(url_for('license.templates'))
    
    # Parse features from JSON
    features = []
    if template.features:
        try:
            features = json.loads(template.features)
        except:
            features = []
    
    return render_template('license/template_form.html', template=template, features=features)

@license_bp.route('/templates/delete/<int:template_id>', methods=['POST'])
@login_required
@admin_required
def delete_template(template_id):
    """Delete a license template"""
    template = LicenseTemplate.query.get_or_404(template_id)
    
    # Check if any licenses are using this template
    if License.query.filter_by(template_id=template.id).count() > 0:
        flash('Cannot delete template that is in use by licenses', 'danger')
        return redirect(url_for('license.templates'))
    
    db.session.delete(template)
    db.session.commit()
    
    flash(f'License template "{template.name}" deleted successfully', 'success')
    return redirect(url_for('license.templates'))

@license_bp.route('/generate-from-template/<int:template_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def generate_from_template(template_id):
    """Generate a license from a template"""
    template = LicenseTemplate.query.get_or_404(template_id)
    
    if request.method == 'POST':
        user_id = int(request.form.get('user_id'))
        notes = request.form.get('notes')
        
        # Use template values to generate license
        license_key = License.generate_license_key(
            user_id=user_id,
            product_name=template.product_name,
            max_servers=template.max_servers,
            validity_days=template.validity_days,
            template_id=template.id,
            version=template.version,
            notes=notes,
            features=template.features
        )
        
        # Find the newly created license
        new_license = License.query.filter_by(license_key=license_key).first()
        
        flash(f'License key generated successfully from template: {license_key}', 'success')
        if new_license:
            return redirect(url_for('license.view', license_id=new_license.id))
        else:
            return redirect(url_for('license.templates'))
    
    users = User.query.all()
    return render_template('license/generate_from_template.html', template=template, users=users)