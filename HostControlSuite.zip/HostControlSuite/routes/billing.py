from flask import Blueprint, request, jsonify, redirect, url_for, flash, render_template, session
from flask_login import login_required, current_user
from datetime import datetime, timedelta
import logging
import os
import random
from io import BytesIO

from app import db
from models import Invoice, InvoiceItem, Transaction, Server, User
from utils.vps_manager import provision_server, reactivate_server, calculate_expiry_date
from utils.paypal_utils import PayPalAPI

# Domain for URL construction
DOMAIN = os.environ.get('REPLIT_DEV_DOMAIN') if os.environ.get('REPLIT_DEPLOYMENT') != '' else os.environ.get('REPLIT_DOMAINS', '').split(',')[0]

billing_bp = Blueprint('billing', __name__)
logger = logging.getLogger(__name__)

@billing_bp.route('/process-payment', methods=['POST'])
@login_required
def process_payment():
    """Process a payment for an invoice"""
    invoice_id = request.form.get('invoice_id')
    payment_method = request.form.get('payment_method')
    crypto_type = request.form.get('crypto_type')
    
    if not invoice_id:
        flash('Invalid invoice', 'danger')
        return redirect(url_for('client.billing'))
    
    invoice = Invoice.query.filter_by(id=invoice_id, user_id=current_user.id).first_or_404()
    
    # Check if invoice is already paid
    if invoice.status == 'paid':
        flash('This invoice has already been paid', 'warning')
        return redirect(url_for('client.invoice_details', invoice_id=invoice.id))
    
    # We're only using Google Pay and PayPal, so this condition won't be used
    
    elif payment_method == 'googlepay':
        # In a real implementation, we would redirect to Google Pay
        # For demo purposes, we'll create a transaction record directly
        try:
            # Demo implementation - in a real app this would integrate with Google Pay
            transaction = Transaction(
                transaction_id=f"GOOGLEPAY-{invoice.id}-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
                gateway='googlepay',
                amount=invoice.total_amount,
                status='success',
                invoice_id=invoice.id
            )
            
            # Mark invoice as paid
            invoice.status = 'paid'
            invoice.paid_date = datetime.utcnow()
            
            db.session.add(transaction)
            db.session.commit()
            
            # Process the order (create servers, etc.)
            process_paid_invoice(invoice.id)
            
            flash('Payment processed successfully via Google Pay', 'success')
            return redirect(url_for('client.invoice_details', invoice_id=invoice.id))
        except Exception as e:
            logger.error(f"Error processing Google Pay payment: {str(e)}")
            flash(f"Payment processing error: {str(e)}", 'danger')
            return redirect(url_for('client.invoice_details', invoice_id=invoice.id))
    
    elif payment_method == 'paypal':
        # Check if PayPal is properly configured
        paypal_client_id = os.environ.get('PAYPAL_CLIENT_ID')
        paypal_secret_key = os.environ.get('PAYPAL_SECRET_KEY')
        
        if not paypal_client_id or not paypal_secret_key:
            logger.warning("PayPal credentials are not configured")
            flash('PayPal is not properly configured. Please choose another payment method or contact support.', 'warning')
            return redirect(url_for('client.invoice_details', invoice_id=invoice.id))
        
        try:
            # Initialize PayPal API
            paypal_api = PayPalAPI()
            
            # Return URL after successful payment
            return_url = f"https://{DOMAIN}/billing/paypal-return?invoice_id={invoice.id}"
            # Cancel URL if user cancels the payment
            cancel_url = f"https://{DOMAIN}/client/invoice/{invoice.id}"
            
            # Create PayPal order
            order_result = paypal_api.create_order(invoice, return_url, cancel_url)
            
            if not order_result or 'approval_url' not in order_result:
                logger.error("Failed to create PayPal order")
                flash('Error creating PayPal payment. Please try again or contact support.', 'danger')
                return redirect(url_for('client.invoice_details', invoice_id=invoice.id))
                
            # Store the PayPal order ID in the session
            session['paypal_order_id'] = order_result['id']
            session['paypal_invoice_id'] = invoice.id
            
            # Redirect the user to PayPal for payment approval
            return redirect(order_result['approval_url'])
            
        except Exception as e:
            logger.error(f"Error processing PayPal payment: {str(e)}")
            flash(f"Payment processing error: {str(e)}", 'danger')
            return redirect(url_for('client.invoice_details', invoice_id=invoice.id))
    
    elif payment_method == 'crypto':
        # Check if a crypto type was selected
        if not crypto_type:
            flash('Please select a cryptocurrency', 'warning')
            return redirect(url_for('client.invoice_details', invoice_id=invoice.id))
        
        # Generate a unique payment address for the selected cryptocurrency
        # In a real implementation, this would integrate with a crypto payment processor
        crypto_address = generate_crypto_address(crypto_type)
        
        # For demo purposes, we'll render a template with crypto payment details
        return render_template('client/crypto_payment.html', 
                              invoice=invoice, 
                              crypto_type=crypto_type, 
                              crypto_address=crypto_address)
    
    elif payment_method == 'bank_transfer':
        # Mark invoice as pending - in real implementation this would await manual verification
        invoice.status = 'pending'
        
        # Create transaction record
        transaction = Transaction(
            transaction_id=f"BANK-{invoice.id}-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
            gateway='bank_transfer',
            amount=invoice.total_amount,
            status='pending',
            invoice_id=invoice.id
        )
        
        db.session.add(transaction)
        db.session.commit()
        
        flash('Your bank transfer has been recorded. Your invoice will be marked as paid once the payment is confirmed.', 'info')
        return redirect(url_for('client.invoice_details', invoice_id=invoice.id))
    
    else:
        # For demo purposes - fallback for other methods or testing
        # In a real system, this would not exist
        
        # Mark invoice as paid
        invoice.status = 'paid'
        invoice.paid_date = datetime.utcnow()
        
        # Create transaction record
        transaction = Transaction(
            transaction_id=f"DEMO-{invoice.id}-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
            gateway=payment_method,
            amount=invoice.total_amount,
            status='success',
            invoice_id=invoice.id
        )
        
        db.session.add(transaction)
        db.session.commit()
        
        # Process the order (create servers, etc.)
        process_paid_invoice(invoice.id)
        
        flash('Payment processed successfully', 'success')
        return redirect(url_for('client.invoice_details', invoice_id=invoice.id))

def generate_crypto_address(crypto_type):
    """
    Generate a mock crypto address for demonstration purposes
    In production, this would integrate with a crypto payment gateway
    """
    # Mock addresses for demo purposes - in production these would be generated by a payment processor
    if crypto_type == 'bitcoin':
        return '3Jb6X1buGKivDJf5xre4QxYVfMUGVbPAj7'
    elif crypto_type == 'ethereum':
        return '0x742d35Cc6634C0532925a3b844Bc454e4438f44e'
    elif crypto_type == 'dogecoin':
        return 'DFuVU3EjPP7vA5QxNsGt1VLE9x7wYmGY5T'
    elif crypto_type == 'solana':
        return '7Zeu9zcuUCnTZxVXpPrPZYyZoJGbTLAMgqpfER8PoN7X'
    else:
        # Generate a random address for other types
        return ''.join(random.choices('abcdef0123456789', k=40))

# Payment webhooks would be implemented here for Google Pay, PayPal, etc.
# For now, we're using direct payment simulation

def process_paid_invoice(invoice_id):
    """
    Process a paid invoice - provision servers, set up services, etc.
    """
    logger.info(f"Processing paid invoice {invoice_id}")
    
    invoice = Invoice.query.get(invoice_id)
    if not invoice or invoice.status != 'paid':
        logger.error(f"Cannot process invoice {invoice_id} - not found or not paid")
        return False
        
    # Get user and transaction info for email notification
    user = User.query.get(invoice.user_id)
    if not user:
        logger.error(f"User not found for invoice {invoice_id}")
        return False
        
    transaction = Transaction.query.filter_by(invoice_id=invoice_id).order_by(Transaction.transaction_date.desc()).first()
    if not transaction:
        logger.error(f"No transaction found for paid invoice {invoice_id}")
        # Continue anyway as the invoice is marked as paid
    
    # Import start_deployment_simulation from the deployment module
    from routes.deployment import start_deployment_simulation
    
    # Send payment confirmation email with receipt
    from utils.email_utils import send_payment_confirmation
    try:
        send_payment_confirmation(user, invoice, transaction)
        logger.info(f"Payment confirmation email sent to {user.email} for invoice {invoice_id}")
    except Exception as e:
        logger.error(f"Failed to send payment confirmation email: {str(e)}")
    
    # Check if this is a renewal for an existing server
    for item in invoice.items:
        if item.server_id:
            # This is a renewal - reactivate the server
            server = Server.query.get(item.server_id)
            if server and server.status == 'suspended':
                logger.info(f"Reactivating suspended server {server.id}")
                
                # Get billing cycle from the invoice item description
                billing_cycle = 'monthly'  # default
                if 'quarterly' in item.description.lower():
                    billing_cycle = 'quarterly'
                elif 'annual' in item.description.lower():
                    billing_cycle = 'annual'
                elif 'month' in item.description.lower():
                    billing_cycle = 'monthly'
                
                # Calculate new expiry date
                new_expiry_date = calculate_expiry_date(billing_cycle)
                
                # Reactivate the server
                reactivate_server(server.id, new_expiry_date)
                
                # Notify user that server has been reactivated
                from utils.email_utils import send_server_provision_notification
                try:
                    send_server_provision_notification(user, server)
                    logger.info(f"Server reactivation notification email sent for server {server.id}")
                except Exception as e:
                    logger.error(f"Failed to send server reactivation email: {str(e)}")
        else:
            # This is a new server order - provision it
            # Extract details from the invoice item description
            from models import ServerTemplate
            
            # Find template from description
            # Format: "Template Name (CPU, RAM) - billing"
            template_name = item.description.split('(')[0].strip()
            template = ServerTemplate.query.filter(ServerTemplate.name.like(f"%{template_name}%")).first()
            
            if not template:
                logger.error(f"Cannot find template for invoice item {item.id}")
                continue
            
            # Extract billing cycle
            billing_cycle = 'monthly'  # default
            if 'quarterly' in item.description.lower():
                billing_cycle = 'quarterly'
            elif 'annual' in item.description.lower():
                billing_cycle = 'annual'
            
            # Generate hostname if one wasn't specified
            hostname = f"vps{invoice.user_id}-{template.id}"
            
            # Determine OS (would normally be stored with the order)
            operating_system = "Ubuntu 20.04"  # default
            
            # Provision the server
            try:
                server_data = provision_server(hostname, template, operating_system, invoice.user_id, billing_cycle)
                
                # Create the Server object from the returned data
                from models import Server
                
                # Check if server_data is a dictionary (from mock data) or Server object
                if isinstance(server_data, dict):
                    # Create a new Server object
                    new_server = Server(
                        name=hostname,
                        hostname=server_data['hostname'],
                        ip_address=server_data['ip_address'],
                        status=server_data['status'],
                        operating_system=operating_system,
                        username=server_data['username'],
                        password=server_data['password'],
                        cpu_cores=template.cpu_cores,
                        ram_mb=template.ram_mb,
                        disk_gb=template.disk_gb,
                        bandwidth_gb=template.bandwidth_gb,
                        deployment_status='pending',
                        deployment_progress=0,
                        created_at=datetime.utcnow(),
                        expiry_date=server_data['expiry_date'],
                        user_id=invoice.user_id,
                        template_id=template.id
                    )
                    
                    # Add to database
                    db.session.add(new_server)
                    db.session.flush()  # Get the server ID
                    
                    # Link the invoice item to the server
                    item.server_id = new_server.id
                    db.session.commit()
                    
                    logger.info(f"Provisioned server {new_server.id} for invoice item {item.id}")
                    
                    # Start the deployment simulation
                    start_deployment_simulation(new_server.id)
                    logger.info(f"Started deployment simulation for server {new_server.id}")
                else:
                    # If it's already a Server object
                    item.server_id = server_data.id
                    db.session.commit()
                    logger.info(f"Provisioned server {server_data.id} for invoice item {item.id}")
                    
                    # Start the deployment simulation
                    start_deployment_simulation(server_data.id)
                    logger.info(f"Started deployment simulation for server {server_data.id}")
                
                # We won't send the server provisioning email yet - it will be sent when deployment is complete
            except Exception as e:
                logger.error(f"Error provisioning server for invoice item {item.id}: {str(e)}")
    
    # Mark any other unpaid invoices for the same items as cancelled
    # (e.g., if user had multiple unpaid renewal invoices)
    try:
        for item in invoice.items:
            if item.server_id:
                # Find any other unpaid invoices for this server
                other_invoices = db.session.query(Invoice).join(InvoiceItem).filter(
                    InvoiceItem.server_id == item.server_id,
                    Invoice.status == 'unpaid',
                    Invoice.id != invoice.id
                ).all()
                
                # Cancel these invoices
                for other_invoice in other_invoices:
                    other_invoice.status = 'cancelled'
                    logger.info(f"Cancelled redundant unpaid invoice {other_invoice.id} for server {item.server_id}")
                
                if other_invoices:
                    db.session.commit()
    except Exception as e:
        logger.error(f"Error cancelling redundant invoices: {str(e)}")
                
    return True

@billing_bp.route('/admin/invoice/cancel/<int:invoice_id>', methods=['POST'])
@login_required
def cancel_invoice(invoice_id):
    """Cancel an unpaid invoice (admin function)"""
    # Check if user has admin role
    if not current_user.has_role('admin'):
        flash('Access denied', 'danger')
        return redirect(url_for('client.billing'))
    
    invoice = Invoice.query.get_or_404(invoice_id)
    
    # Only unpaid invoices can be cancelled
    if invoice.status != 'unpaid':
        flash('Only unpaid invoices can be cancelled', 'warning')
        return redirect(url_for('admin.billing'))
    
    invoice.status = 'cancelled'
    db.session.commit()
    
    flash('Invoice cancelled successfully', 'success')
    return redirect(url_for('admin.billing'))

@billing_bp.route('/admin/invoice/create', methods=['GET', 'POST'])
@login_required
def admin_create_invoice():
    """Create invoice manually (admin function)"""
    from models import User
    
    # Check if user has admin role
    if not current_user.has_role('admin'):
        flash('Access denied', 'danger')
        return redirect(url_for('client.billing'))
    
    if request.method == 'POST':
        return create_invoice()
    
    # Get list of users for the form
    users = User.query.all()
    
    return render_template('admin/create_invoice.html', users=users)

def create_invoice():
    """Create new invoice with form data"""
    from utils.billing_utils import generate_invoice_number
    
    user_id = request.form.get('user_id')
    amount = float(request.form.get('amount', 0))
    tax_amount = float(request.form.get('tax_amount', 0))
    description = request.form.get('description', '')
    
    # Validate
    if not user_id or amount <= 0:
        flash('Invalid invoice data', 'danger')
        return redirect(url_for('billing.admin_create_invoice'))
    
    # Create invoice
    invoice_number = generate_invoice_number()
    total_amount = amount + tax_amount
    
    invoice = Invoice(
        invoice_number=invoice_number,
        amount=amount,
        tax_amount=tax_amount,
        total_amount=total_amount,
        status='unpaid',
        issue_date=datetime.utcnow(),
        due_date=datetime.utcnow() + timedelta(days=14),
        user_id=user_id,
        notes=f"Manually created by admin {current_user.username}"
    )
    
    db.session.add(invoice)
    db.session.flush()  # Get invoice ID
    
    # Create invoice item
    item = InvoiceItem(
        description=description,
        amount=amount,
        quantity=1,
        invoice_id=invoice.id
    )
    
    db.session.add(item)
    db.session.commit()
    
    flash('Invoice created successfully', 'success')
    return redirect(url_for('admin.billing'))

@billing_bp.route('/admin/invoice/mark-paid/<int:invoice_id>', methods=['POST'])
@login_required
def admin_mark_paid():
    """Mark invoice as paid manually (admin function)"""
    # Check if user has admin role
    if not current_user.has_role('admin'):
        flash('Access denied', 'danger')
        return redirect(url_for('client.billing'))
    
    if request.method == 'POST':
        return mark_paid(request.form.get('invoice_id'))
    
    flash('Invalid request', 'danger')
    return redirect(url_for('admin.billing'))

@billing_bp.route('/download-invoice/<int:invoice_id>', methods=['GET'])
@login_required
def download_invoice(invoice_id):
    """Download a PDF invoice"""
    
    # Security check - only admin or invoice owner can download
    invoice = Invoice.query.get_or_404(invoice_id)
    if invoice.user_id != current_user.id and not current_user.has_role('admin'):
        flash('Access denied', 'danger')
        return redirect(url_for('client.billing'))
    
    try:
        from utils.pdf_generator import generate_invoice_pdf, attach_digital_signature
        
        # Generate the PDF
        pdf_buffer = generate_invoice_pdf(invoice_id)
        
        # Add digital signature if paid
        if invoice.status == 'paid':
            pdf_buffer = attach_digital_signature(pdf_buffer)
        
        # Prepare the response
        from flask import send_file
        
        return send_file(
            pdf_buffer,
            download_name=f"Invoice-{invoice.invoice_number}.pdf",
            as_attachment=True,
            mimetype='application/pdf'
        )
        
    except Exception as e:
        logger.error(f"Error generating PDF invoice: {str(e)}")
        flash(f"Error generating PDF invoice: {str(e)}", 'danger')
        return redirect(url_for('client.invoice_details', invoice_id=invoice_id))

@billing_bp.route('/verify-invoice-signature', methods=['POST'])
@login_required
def verify_invoice_signature():
    """Verify the digital signature of a PDF invoice"""
    
    # Check if file was uploaded
    if 'invoice_file' not in request.files:
        flash('No file uploaded', 'danger')
        return redirect(url_for('client.billing'))
    
    file = request.files['invoice_file']
    if file.filename == '':
        flash('No file selected', 'danger')
        return redirect(url_for('client.billing'))
    
    try:
        # Read the uploaded file
        pdf_data = file.read()
        pdf_buffer = BytesIO(pdf_data)
        
        # Check if it's a PDF
        from PyPDF2 import PdfReader
        
        try:
            reader = PdfReader(pdf_buffer)
        except:
            flash('Invalid PDF file', 'danger')
            return redirect(url_for('client.billing'))
            
        # Check if it has our signature metadata
        metadata = reader.metadata
        
        if not metadata or '/SignatureMethod' not in metadata or metadata['/SignatureMethod'] != 'VPS Control Panel PDF Signature':
            flash('This invoice does not have a valid digital signature', 'warning')
            return redirect(url_for('client.billing'))
        
        # Verify the content hash if present
        if '/ContentHash' in metadata:
            import hashlib
            
            # Reset buffer position and calculate hash, skipping the metadata
            pdf_buffer.seek(0)
            # This is a simplified approach - in a real implementation, we would exclude signature data
            content_hash = hashlib.sha256(pdf_data).hexdigest()
            
            # Check if the hash matches
            if content_hash != metadata['/ContentHash']:
                flash('Invoice has been tampered with - content hash mismatch', 'danger')
                return redirect(url_for('client.billing'))
                
            # Get signature info for display
            signature_date = metadata.get('/SignatureDate', 'Unknown')
            signature_reason = metadata.get('/SignatureReason', 'Unknown')
            
            flash(f'Invoice signature verified successfully. Signed on {signature_date} for {signature_reason}', 'success')
        else:
            flash('Invoice is signed but does not contain content verification data', 'warning')
            
        return redirect(url_for('client.billing'))
            
    except Exception as e:
        logger.error(f"Error verifying invoice signature: {str(e)}")
        flash(f"Error verifying invoice signature: {str(e)}", 'danger')
        return redirect(url_for('client.billing'))

def mark_paid(invoice_id):
    """Mark an invoice as paid"""
    invoice = Invoice.query.get_or_404(invoice_id)
    
    # Only unpaid invoices can be marked as paid
    if invoice.status != 'unpaid':
        flash('Only unpaid invoices can be marked as paid', 'warning')
        return redirect(url_for('admin.billing'))
    
    # Mark as paid
    invoice.status = 'paid'
    invoice.paid_date = datetime.utcnow()
    
    # Create transaction record
    transaction = Transaction(
        transaction_id=f"MANUAL-{invoice.id}",
        gateway='manual',
        amount=invoice.total_amount,
        status='success',
        invoice_id=invoice.id
    )
    
    db.session.add(transaction)
    db.session.commit()
    
    # Process the order (create servers, etc.)
    process_paid_invoice(invoice.id)
    
    flash('Invoice marked as paid successfully', 'success')
    return redirect(url_for('admin.billing'))
    
@billing_bp.route('/paypal-return', methods=['GET'])
@login_required
def paypal_return():
    """Handle PayPal payment return and finalize the transaction"""
    # Get order_id and invoice_id from URL params or session
    order_id = request.args.get('token')  # PayPal returns the order ID as 'token'
    invoice_id = request.args.get('invoice_id')
    
    # If invoice_id was not in URL, try to get from session
    if not invoice_id and 'paypal_invoice_id' in session:
        invoice_id = session.get('paypal_invoice_id')
        
    # If order_id was not in URL, try to get from session
    if not order_id and 'paypal_order_id' in session:
        order_id = session.get('paypal_order_id')
    
    # Validate we have all required information
    if not order_id or not invoice_id:
        flash('Missing payment information. Please try again or contact support.', 'danger')
        return redirect(url_for('client.billing'))
    
    # Check that invoice exists and belongs to current user
    invoice = Invoice.query.filter_by(id=invoice_id, user_id=current_user.id).first()
    if not invoice:
        flash('Invoice not found', 'danger')
        return redirect(url_for('client.billing'))
    
    # Check if invoice is already paid
    if invoice.status == 'paid':
        flash('This invoice has already been paid', 'success')
        return redirect(url_for('client.invoice_details', invoice_id=invoice.id))
    
    # Initialize PayPal API
    paypal_api = PayPalAPI()
    
    # Capture the payment
    capture_result = paypal_api.capture_order(order_id, invoice.id)
    
    if capture_result:
        flash('Payment completed successfully!', 'success')
        # Process the paid invoice - provision servers, etc.
        process_paid_invoice(invoice.id)
        
        # Clean up session data
        if 'paypal_order_id' in session:
            del session['paypal_order_id']
        if 'paypal_invoice_id' in session:
            del session['paypal_invoice_id']
    else:
        flash('There was a problem completing your payment. Please contact support.', 'danger')
    
    return redirect(url_for('client.invoice_details', invoice_id=invoice.id))