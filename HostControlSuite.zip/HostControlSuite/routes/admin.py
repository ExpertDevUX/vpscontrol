from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from sqlalchemy import func
from datetime import datetime, timedelta
import logging
import os

from app import db
from models import User, Role, Server, ServerTemplate, Invoice, Ticket, Transaction, ServerUsage, Settings, LicenseTemplate

admin_bp = Blueprint('admin', __name__)
logger = logging.getLogger(__name__)

def admin_required(f):
    """Decorator to check if user has admin role"""
    def decorated_function(*args, **kwargs):
        if not current_user.has_role('admin'):
            flash('Admin access required.', 'danger')
            return redirect(url_for('auth.login'))
        return f(*args, **kwargs)
    decorated_function.__name__ = f.__name__
    return login_required(decorated_function)

@admin_bp.route('/')
@admin_required
def dashboard():
    # Optimize by using a single query for counts
    from sqlalchemy import case, literal_column
    
    # Get all counts in a single query to reduce database roundtrips
    counts = db.session.query(
        func.count(User.id).label('user_count'),
        func.count(Server.id).label('server_count'),
        func.sum(case((Server.status == 'active', 1), else_=0)).label('active_server_count'),
        func.sum(case((Server.status == 'pending', 1), else_=0)).label('pending_server_count')
    ).join(Server, isouter=True).first()
    
    user_count = counts.user_count
    server_count = counts.server_count
    active_server_count = counts.active_server_count or 0
    pending_server_count = counts.pending_server_count or 0
    
    # Financial statistics - cache this value to avoid recalculating
    total_revenue = db.session.query(func.sum(Transaction.amount))\
        .filter_by(status='success')\
        .scalar() or 0
    
    # Calculate exact month boundaries for the last 6 months and
    # get all revenue data in a single query instead of 6 separate ones
    now = datetime.now()
    month_ranges = []
    
    for i in range(5, -1, -1):
        month_date = (now.replace(day=1) - timedelta(days=i*30))
        month_start = datetime(month_date.year, month_date.month, 1)
        if month_date.month == 12:
            month_end = datetime(month_date.year + 1, 1, 1)
        else:
            month_end = datetime(month_date.year, month_date.month + 1, 1)
        month_ranges.append({
            'start': month_start, 
            'end': month_end,
            'label': month_start.strftime('%b %Y')
        })
    
    # Get revenue for all months in a single query with SQL CASE statements
    case_statements = []
    for i, month_range in enumerate(month_ranges):
        case_statements.append(
            func.sum(
                case(
                    (
                        (Transaction.status == 'success') & 
                        (Transaction.transaction_date >= month_range['start']) & 
                        (Transaction.transaction_date < month_range['end']),
                        Transaction.amount
                    ), 
                    else_=0
                )
            ).label(f'month_{i}')
        )
    
    # Execute a single query to get all monthly revenues
    revenue_results = db.session.query(*case_statements).first()
    
    # Format the monthly revenue data
    monthly_revenue = []
    for i, month_range in enumerate(month_ranges):
        monthly_revenue.append({
            'month': month_range['label'],
            'revenue': getattr(revenue_results, f'month_{i}') or 0
        })
    
    # Get pending tickets
    open_tickets = Ticket.query.filter_by(status='open').count()
    
    # Recent activities
    recent_users = User.query.order_by(User.created_at.desc()).limit(5).all()
    recent_servers = Server.query.order_by(Server.created_at.desc()).limit(5).all()
    recent_invoices = Invoice.query.order_by(Invoice.issue_date.desc()).limit(5).all()
    
    return render_template('admin/dashboard.html',
                          user_count=user_count,
                          server_count=server_count,
                          active_server_count=active_server_count,
                          pending_server_count=pending_server_count,
                          total_revenue=total_revenue,
                          monthly_revenue=monthly_revenue,
                          open_tickets=open_tickets,
                          recent_users=recent_users,
                          recent_servers=recent_servers,
                          recent_invoices=recent_invoices)

@admin_bp.route('/users')
@admin_required
def users():
    search_query = request.args.get('search', '')
    page = request.args.get('page', 1, type=int)
    
    query = User.query
    
    if search_query:
        query = query.filter(
            (User.username.ilike(f'%{search_query}%')) |
            (User.email.ilike(f'%{search_query}%')) |
            (User.first_name.ilike(f'%{search_query}%')) |
            (User.last_name.ilike(f'%{search_query}%'))
        )
    
    users = query.order_by(User.created_at.desc()).paginate(page=page, per_page=10)
    
    return render_template('admin/users.html', users=users, search_query=search_query)

@admin_bp.route('/users/<int:user_id>', methods=['GET', 'POST'])
@admin_required
def user_details(user_id):
    user = User.query.get_or_404(user_id)
    
    if request.method == 'POST':
        user.username = request.form.get('username')
        user.email = request.form.get('email')
        user.first_name = request.form.get('first_name')
        user.last_name = request.form.get('last_name')
        user.company_name = request.form.get('company_name', '')
        user.address = request.form.get('address', '')
        user.city = request.form.get('city', '')
        user.state = request.form.get('state', '')
        user.country = request.form.get('country', '')
        user.zip_code = request.form.get('zip_code', '')
        user.phone = request.form.get('phone', '')
        user.is_active = 'is_active' in request.form
        
        # Handle role changes
        admin_role = Role.query.filter_by(name='admin').first()
        if 'is_admin' in request.form and admin_role not in user.roles:
            user.roles.append(admin_role)
        elif 'is_admin' not in request.form and admin_role in user.roles:
            user.roles.remove(admin_role)
        
        db.session.commit()
        flash('User updated successfully', 'success')
        return redirect(url_for('admin.users'))
    
    # Get user's servers, invoices, and tickets
    servers = Server.query.filter_by(user_id=user.id).all()
    invoices = Invoice.query.filter_by(user_id=user.id).order_by(Invoice.issue_date.desc()).all()
    tickets = Ticket.query.filter_by(user_id=user.id).order_by(Ticket.created_at.desc()).all()
    
    return render_template('admin/user_details.html', 
                          user=user, 
                          servers=servers, 
                          invoices=invoices, 
                          tickets=tickets)

@admin_bp.route('/servers')
@admin_required
def servers():
    search_query = request.args.get('search', '')
    status_filter = request.args.get('status', '')
    page = request.args.get('page', 1, type=int)
    
    query = Server.query.join(User)
    
    if search_query:
        query = query.filter(
            (Server.name.ilike(f'%{search_query}%')) |
            (Server.hostname.ilike(f'%{search_query}%')) |
            (Server.ip_address.ilike(f'%{search_query}%')) |
            (User.username.ilike(f'%{search_query}%'))
        )
    
    if status_filter:
        query = query.filter(Server.status == status_filter)
    
    servers = query.order_by(Server.created_at.desc()).paginate(page=page, per_page=10)
    
    return render_template('admin/servers.html', 
                          servers=servers, 
                          search_query=search_query,
                          status_filter=status_filter)

@admin_bp.route('/server-templates', methods=['GET', 'POST'])
@admin_required
def server_templates():
    if request.method == 'POST':
        name = request.form.get('name')
        cpu_cores = int(request.form.get('cpu_cores'))
        ram_mb = int(request.form.get('ram_mb'))
        disk_gb = int(request.form.get('disk_gb'))
        bandwidth_gb = int(request.form.get('bandwidth_gb'))
        price_monthly = float(request.form.get('price_monthly'))
        description = request.form.get('description', '')
        is_active = 'is_active' in request.form
        
        template_id = request.form.get('template_id')
        
        if template_id:  # Update existing template
            template = ServerTemplate.query.get_or_404(template_id)
            template.name = name
            template.cpu_cores = cpu_cores
            template.ram_mb = ram_mb
            template.disk_gb = disk_gb
            template.bandwidth_gb = bandwidth_gb
            template.price_monthly = price_monthly
            template.description = description
            template.is_active = is_active
            
            flash('Server template updated successfully', 'success')
        else:  # Create new template
            template = ServerTemplate(
                name=name,
                cpu_cores=cpu_cores,
                ram_mb=ram_mb,
                disk_gb=disk_gb,
                bandwidth_gb=bandwidth_gb,
                price_monthly=price_monthly,
                description=description,
                is_active=is_active
            )
            db.session.add(template)
            
            flash('Server template created successfully', 'success')
            
        db.session.commit()
        return redirect(url_for('admin.server_templates'))
    
    templates = ServerTemplate.query.order_by(ServerTemplate.name).all()
    return render_template('admin/server_templates.html', templates=templates)

@admin_bp.route('/server/<int:server_id>', methods=['GET', 'POST'])
@admin_required
def server_details(server_id):
    server = Server.query.get_or_404(server_id)
    
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'update':
            server.name = request.form.get('name')
            server.hostname = request.form.get('hostname')
            server.ip_address = request.form.get('ip_address')
            server.status = request.form.get('status')
            server.operating_system = request.form.get('operating_system')
            
            # Only update password if provided
            new_password = request.form.get('password')
            if new_password:
                server.password = new_password
                
            db.session.commit()
            flash('Server updated successfully', 'success')
            
        elif action == 'change_status':
            new_status = request.form.get('new_status')
            server.status = new_status
            db.session.commit()
            
            # Add VPS status change logic here (call to VPS provider API)
            
            flash(f'Server status changed to {new_status}', 'success')
            
    # Get server usage data
    usage = ServerUsage.query.filter_by(server_id=server.id).order_by(ServerUsage.timestamp.desc()).limit(24).all()
    usage.reverse()  # Show oldest first for charts
    
    # Get user information
    user = User.query.get(server.user_id)
    
    return render_template('admin/server_details.html', 
                           server=server, 
                           usage=usage,
                           user=user)

@admin_bp.route('/billing')
@admin_required
def billing():
    status_filter = request.args.get('status', '')
    page = request.args.get('page', 1, type=int)
    
    query = Invoice.query.join(User)
    
    if status_filter:
        query = query.filter(Invoice.status == status_filter)
    
    invoices = query.order_by(Invoice.issue_date.desc()).paginate(page=page, per_page=10)
    
    # Summary statistics
    total_paid = db.session.query(func.sum(Invoice.total_amount))\
        .filter(Invoice.status == 'paid')\
        .scalar() or 0
        
    total_unpaid = db.session.query(func.sum(Invoice.total_amount))\
        .filter(Invoice.status == 'unpaid')\
        .scalar() or 0
    
    return render_template('admin/billing.html', 
                          invoices=invoices, 
                          status_filter=status_filter,
                          total_paid=total_paid,
                          total_unpaid=total_unpaid)

@admin_bp.route('/tickets')
@admin_required
def tickets():
    status_filter = request.args.get('status', '')
    page = request.args.get('page', 1, type=int)
    
    query = Ticket.query.join(User)
    
    if status_filter:
        query = query.filter(Ticket.status == status_filter)
    
    tickets = query.order_by(
        # Sort by priority and creation date
        case(
            (Ticket.priority == 'critical', 1),
            (Ticket.priority == 'high', 2),
            (Ticket.priority == 'medium', 3),
            (Ticket.priority == 'low', 4),
            else_=5
        ),
        Ticket.created_at.desc()
    ).paginate(page=page, per_page=10)
    
    return render_template('admin/tickets.html', 
                          tickets=tickets, 
                          status_filter=status_filter)

@admin_bp.route('/ticket/<int:ticket_id>', methods=['GET', 'POST'])
@admin_required
def ticket_details(ticket_id):
    from models import TicketMessage
    
    ticket = Ticket.query.get_or_404(ticket_id)
    
    if request.method == 'POST':
        action = request.form.get('action')
        
        if action == 'reply':
            message_text = request.form.get('message')
            
            if message_text:
                message = TicketMessage(
                    message=message_text,
                    is_from_admin=True,
                    ticket_id=ticket.id,
                    user_id=current_user.id
                )
                
                # Update ticket status
                ticket.status = 'answered'
                ticket.updated_at = datetime.utcnow()
                
                db.session.add(message)
                db.session.commit()
                
                flash('Reply sent successfully', 'success')
                
        elif action == 'status':
            new_status = request.form.get('status')
            ticket.status = new_status
            
            if new_status == 'closed':
                ticket.closed_at = datetime.utcnow()
                
            db.session.commit()
            flash(f'Ticket status updated to {new_status}', 'success')
            
    messages = TicketMessage.query.filter_by(ticket_id=ticket.id).order_by(TicketMessage.created_at).all()
    user = User.query.get(ticket.user_id)
    
    return render_template('admin/ticket_details.html',
                          ticket=ticket,
                          messages=messages,
                          user=user)

# Settings routes
@admin_bp.route('/license-templates')
@admin_required
def license_templates():
    """Admin dashboard for license templates"""
    templates = LicenseTemplate.query.order_by(LicenseTemplate.name).all()
    return render_template('admin/license_templates.html', templates=templates)

@admin_bp.route('/settings')
@admin_required
def settings():
    # Get all settings for the view
    # Security settings
    captcha_value = Settings.get_value('captcha_enabled', 'false')
    # Handle both string and boolean values
    if isinstance(captcha_value, bool):
        captcha_enabled = captcha_value
    else:
        captcha_enabled = captcha_value.lower() == 'true'
    
    # Email settings
    email_from = Settings.get_value('email_from', '')
    support_email = Settings.get_value('support_email', '')
    
    # Email notification settings
    email_notifications = {
        'new_ticket': Settings.get_value('email_new_ticket', 'false') == 'true',
        'invoice': Settings.get_value('email_invoice', 'false') == 'true',
        'server_status': Settings.get_value('email_server_status', 'false') == 'true'
    }
    
    # Company information
    company_name = Settings.get_value('company_name', '')
    company_website = Settings.get_value('company_website', '')
    company_address = Settings.get_value('company_address', '')
    company_phone = Settings.get_value('company_phone', '')
    
    # System settings
    maintenance_mode = Settings.get_value('maintenance_mode', 'false') == 'true'
    default_currency = Settings.get_value('default_currency', 'USD')
    timezone = Settings.get_value('timezone', 'UTC')
    date_format = Settings.get_value('date_format', 'YYYY-MM-DD')
    
    # Legal documents
    terms_of_service = Settings.get_value('terms_of_service', '')
    privacy_policy = Settings.get_value('privacy_policy', '')
    
    # Payment settings
    payment_methods = {
        'credit_card': Settings.get_value('payment_credit_card', 'true') == 'true',
        'paypal': Settings.get_value('payment_paypal', 'false') == 'true',
        'crypto': Settings.get_value('payment_crypto', 'false') == 'true',
        'bank_transfer': Settings.get_value('payment_bank_transfer', 'false') == 'true',
        'googlepay': Settings.get_value('payment_googlepay', 'false') == 'true',
    }
    
    # PayPal settings
    paypal_sandbox = Settings.get_value('paypal_sandbox', 'true') == 'true'
    paypal_configured = 'PAYPAL_CLIENT_ID' in os.environ and 'PAYPAL_SECRET_KEY' in os.environ
    
    invoice_prefix = Settings.get_value('invoice_prefix', 'INV-')
    
    # AI Assistant settings
    ai_enabled = Settings.get_value('ai_enabled', 'false') == 'true'
    ai_mode = Settings.get_value('ai_mode', 'basic')
    ai_name = Settings.get_value('ai_name', 'Support Assistant')
    ai_greeting = Settings.get_value('ai_greeting', 'Hello! How can I assist you today?')
    
    # Check if Anthropic API key is set
    anthropic_key_set = 'ANTHROPIC_API_KEY' in os.environ and bool(os.environ.get('ANTHROPIC_API_KEY'))
    
    # Combine all settings
    settings_data = {
        'captcha_enabled': captcha_enabled,
        'payment_methods': payment_methods,
        'ai_enabled': ai_enabled,
        'ai_mode': ai_mode,
        'ai_name': ai_name,
        'ai_greeting': ai_greeting
    }
    
    return render_template(
        'admin/settings.html', 
        settings=settings_data,
        email_from=email_from,
        support_email=support_email,
        email_notifications=email_notifications,
        company_name=company_name,
        company_website=company_website,
        company_address=company_address,
        company_phone=company_phone,
        maintenance_mode=maintenance_mode,
        default_currency=default_currency,
        timezone=timezone,
        date_format=date_format,
        terms_of_service=terms_of_service,
        privacy_policy=privacy_policy,
        invoice_prefix=invoice_prefix,
        paypal_sandbox=paypal_sandbox,
        paypal_configured=paypal_configured,
        get_env=os.environ.get,  # Pass the os.environ.get function to template
        anthropic_key_set=anthropic_key_set
    )

@admin_bp.route('/settings/update/<category>', methods=['POST'])
@admin_required
def update_settings(category):
    if category == 'security':
        # Update security settings
        captcha_enabled = 'captcha_enabled' in request.form
        Settings.set_value('captcha_enabled', str(captcha_enabled).lower(), 
                          'Enable CAPTCHA on login and registration forms', True)
        
        flash('Security settings updated successfully', 'success')
    
    elif category == 'email':
        # Update email settings
        email_from = request.form.get('email_from', '')
        support_email = request.form.get('support_email', '')
        
        Settings.set_value('email_from', email_from)
        Settings.set_value('support_email', support_email)
        
        # Update email notification settings
        email_new_ticket = 'email_new_ticket' in request.form
        email_invoice = 'email_invoice' in request.form
        email_server_status = 'email_server_status' in request.form
        
        Settings.set_value('email_new_ticket', str(email_new_ticket).lower())
        Settings.set_value('email_invoice', str(email_invoice).lower())
        Settings.set_value('email_server_status', str(email_server_status).lower())
        
        flash('Email settings updated successfully', 'success')
    
    elif category == 'general':
        # Update company information
        company_name = request.form.get('company_name', '')
        company_website = request.form.get('company_website', '')
        company_address = request.form.get('company_address', '')
        company_phone = request.form.get('company_phone', '')
        
        Settings.set_value('company_name', company_name)
        Settings.set_value('company_website', company_website)
        Settings.set_value('company_address', company_address)
        Settings.set_value('company_phone', company_phone)
        
        # Update system settings
        maintenance_mode = 'maintenance_mode' in request.form
        default_currency = request.form.get('default_currency', 'USD')
        timezone = request.form.get('timezone', 'UTC')
        date_format = request.form.get('date_format', 'YYYY-MM-DD')
        
        Settings.set_value('maintenance_mode', str(maintenance_mode).lower())
        Settings.set_value('default_currency', default_currency)
        Settings.set_value('timezone', timezone)
        Settings.set_value('date_format', date_format)
        
        # Update legal documents
        terms_of_service = request.form.get('terms_of_service', '')
        privacy_policy = request.form.get('privacy_policy', '')
        
        Settings.set_value('terms_of_service', terms_of_service)
        Settings.set_value('privacy_policy', privacy_policy)
        
        flash('General settings updated successfully', 'success')
    
    elif category == 'payment':
        # Update payment methods settings
        payment_credit_card = 'payment_credit_card' in request.form
        payment_paypal = 'payment_paypal' in request.form
        payment_crypto = 'payment_crypto' in request.form
        payment_bank_transfer = 'payment_bank_transfer' in request.form
        payment_googlepay = 'payment_googlepay' in request.form
        
        Settings.set_value('payment_credit_card', str(payment_credit_card).lower())
        Settings.set_value('payment_paypal', str(payment_paypal).lower())
        Settings.set_value('payment_crypto', str(payment_crypto).lower())
        Settings.set_value('payment_bank_transfer', str(payment_bank_transfer).lower())
        Settings.set_value('payment_googlepay', str(payment_googlepay).lower())
        
        # Update PayPal settings
        paypal_sandbox = 'paypal_sandbox' in request.form
        paypal_client_id = request.form.get('paypal_client_id', '')
        paypal_secret_key = request.form.get('paypal_secret_key', '')
        
        Settings.set_value('paypal_sandbox', str(paypal_sandbox).lower(), 
                         'Use PayPal Sandbox environment for testing', True)
        Settings.set_value('paypal_client_id', paypal_client_id, 
                         'PayPal Client ID for API integration', False)
        
        # Only update secret key if provided (to avoid overwriting with blank)
        if paypal_secret_key:
            Settings.set_value('paypal_secret_key', paypal_secret_key, 
                             'PayPal Secret Key for API integration', False)
        
        # Check if PayPal is properly configured (either in database or environment variables)
        env_paypal_client_id = os.environ.get('PAYPAL_CLIENT_ID')
        env_paypal_secret_key = os.environ.get('PAYPAL_SECRET_KEY')
        
        db_configured = paypal_client_id and Settings.get_value('paypal_secret_key', '')
        env_configured = env_paypal_client_id and env_paypal_secret_key
        
        if payment_paypal and not (db_configured or env_configured):
            flash('PayPal was enabled, but the API credentials are not configured. Please enter your API credentials above or set the PAYPAL_CLIENT_ID and PAYPAL_SECRET_KEY environment variables.', 'warning')
        
        # Update invoice settings
        invoice_prefix = request.form.get('invoice_prefix', 'INV-')
        Settings.set_value('invoice_prefix', invoice_prefix)
        
        flash('Payment settings updated successfully', 'success')
    
    elif category == 'ai':
        # Update AI Assistant settings
        ai_enabled = 'ai_enabled' in request.form
        ai_mode = request.form.get('ai_mode', 'basic')
        ai_name = request.form.get('ai_name', 'Support Assistant')
        ai_greeting = request.form.get('ai_greeting', 'Hello! How can I assist you today?')
        
        Settings.set_value('ai_enabled', str(ai_enabled).lower())
        Settings.set_value('ai_mode', ai_mode)
        Settings.set_value('ai_name', ai_name)
        Settings.set_value('ai_greeting', ai_greeting)
        
        flash('AI Assistant settings updated successfully', 'success')
    
    return redirect(url_for('admin.settings'))

# Helper function for SQL CASE statement
def case(*pairs, **kwargs):
    whens = []
    for pair in pairs:
        whens.append((pair[0], pair[1]))
    return func.case(whens, value=kwargs.get('else_'))
