from flask import Blueprint, render_template, request, jsonify, current_app, flash, redirect, url_for
from flask_login import login_required, current_user
from models import Settings
import logging
import json
import random
import time
from datetime import datetime
import os
import sys

# Setup Anthropic integration
try:
    import anthropic
    from anthropic import Anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

chat_bp = Blueprint('chat', __name__)
logger = logging.getLogger(__name__)

# Check if Anthropic API key is available
anthropic_key = os.environ.get('ANTHROPIC_API_KEY')

# Initialize Anthropic client if API key is available
anthropic_client = None
if ANTHROPIC_AVAILABLE and anthropic_key:
    try:
        anthropic_client = Anthropic(api_key=anthropic_key)
        logger.info("Anthropic client initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize Anthropic client: {e}")
        anthropic_client = None

# Simple knowledge base for AI responses
KNOWLEDGE_BASE = {
    "server": [
        "VPS servers are virtual private servers that provide dedicated resources in a shared environment.",
        "You can restart your server from the VPS details page by clicking the 'Restart' button.",
        "If your server is unresponsive, try power cycling it from the VPS details page.",
        "Server resources include CPU, RAM, disk space, and bandwidth allocation.",
        "You can upgrade your server resources from the billing section.",
        "To check your server status, go to the 'My Servers' section in your dashboard and look at the status indicator.",
        "Server management includes options like restart, power on/off, reinstall OS, and viewing usage statistics.",
        "If you need to upgrade your server resources, you can do this by submitting a support ticket or through the billing section.",
        "Server backup options are available in the VPS details page under the 'Backup' tab.",
        "To access your server via SSH, use the credentials provided in the VPS details page."
    ],
    "billing": [
        "Invoices are generated on the 1st of each month for monthly billing cycles.",
        "You can view all your invoices in the Billing section of your dashboard.",
        "We accept credit cards, PayPal, and cryptocurrency payments.",
        "To update your payment method, go to the Billing section and click on 'Payment Methods'.",
        "If you have questions about a specific invoice, please open a support ticket.",
        "Your next billing cycle begins on the 1st of the following month from your signup date.",
        "To cancel a service, go to the Billing section and select 'Cancel Service' for the specific VPS you wish to cancel.",
        "Late payments may result in service suspension after 3 days.",
        "We offer monthly, quarterly, and annual billing options with discounts for longer commitments.",
        "Refunds are processed within 7-10 business days depending on your payment method."
    ],
    "account": [
        "You can change your password from your account settings page.",
        "Two-factor authentication adds an extra layer of security to your account.",
        "To update your contact information, go to your profile settings.",
        "Your account details are used for billing and support communications.",
        "You can enable email notifications for important account events in your profile settings.",
        "Account security includes IP-based login restrictions and activity monitoring.",
        "You can link multiple email addresses to your account for notifications.",
        "To close your account, please submit a support ticket with verification details.",
        "Account inactivity period is set to 90 days before we send warning notifications.",
        "Your account dashboard provides a complete overview of all your services and billing information."
    ],
    "support": [
        "For urgent issues, please open a support ticket with priority set to 'High'.",
        "Our support team is available 24/7 to assist you with any issues.",
        "You can track the status of your support tickets from your dashboard.",
        "Common issues can often be resolved by checking our knowledge base.",
        "For billing-related questions, please include your invoice number in your support ticket.",
        "To open a new support ticket, go to the Support section and click on 'New Ticket'.",
        "Average response time for tickets is under 2 hours for high-priority issues.",
        "You can attach screenshots or log files to your support tickets for better assistance.",
        "Support tickets can be categorized as Technical, Billing, Sales, or General Inquiries.",
        "Our live chat support is available during business hours (9 AM - 5 PM EST)."
    ],
    "features": [
        "Our VPS Control Panel includes server management, billing, support ticketing, and license key generation.",
        "Advanced monitoring tools are available for tracking server performance.",
        "Automated backups can be configured for daily, weekly, or monthly schedules.",
        "Multi-user access allows you to grant limited permissions to team members.",
        "API access is available for automating server management tasks.",
        "Custom firewall rules can be configured through the Security section.",
        "Traffic analytics provides insights into your server's bandwidth usage.",
        "Automated scaling options are available for handling traffic spikes.",
        "Load balancing features are offered for enterprise-tier customers.",
        "White-label options allow you to customize the control panel with your brand."
    ]
}

# Fallback responses when no specific match is found
FALLBACK_RESPONSES = [
    "I'm not sure I understand. Could you please rephrase your question?",
    "I don't have specific information about that. Could you ask something related to your server, billing, account, or support?",
    "I'm still learning and don't have an answer for that question. Is there something else I can help you with?",
    "That's beyond my current knowledge. For detailed assistance, please open a support ticket.",
    "I'm unable to provide information on that topic. Would you like to know about your servers, billing, or account settings?"
]

# Greeting responses
GREETING_RESPONSES = [
    "Hello! How can I assist you today?",
    "Hi there! What can I help you with?",
    "Welcome to VPS Control Panel support. How may I help you?",
    "Greetings! What questions do you have about your VPS services?",
    "Hi! I'm your virtual assistant. How can I help you today?"
]

@chat_bp.route('/chat')
@login_required
def chat_interface():
    """Render the chat interface"""
    # Check if AI is enabled in settings
    ai_enabled = Settings.get_value('ai_enabled', 'false') == 'true'
    ai_mode = Settings.get_value('ai_mode', 'basic')
    ai_name = Settings.get_value('ai_name', 'Support Assistant')
    ai_greeting = Settings.get_value('ai_greeting', 'Hello! How can I assist you today?')
    
    # If AI is disabled, redirect to dashboard with message
    if not ai_enabled:
        flash('The support assistant is currently unavailable. Please open a support ticket for assistance.', 'info')
        return redirect(url_for('client.dashboard'))
    
    # Advanced mode requires Anthropic API
    advanced_enabled = ai_mode == 'advanced' and bool(anthropic_client)
    
    # Check if there's a query parameter for direct question
    direct_question = request.args.get('q', None)
    
    # Map common question shortcuts to full questions
    question_map = {
        'server_status': 'How do I check my server status?',
        'billing_cycle': 'When is my next billing cycle?',
        'support_ticket': 'How do I open a support ticket?',
        'restart_server': 'How do I restart my server?',
        'upgrade_resources': 'How can I upgrade my server resources?',
        'cancel_service': 'What is the process to cancel a service?',
        'payment_methods': 'What payment methods do you accept?'
    }
    
    initial_question = None
    if direct_question:
        # Try to map the question code to a full question, or use as-is
        initial_question = question_map.get(direct_question, direct_question)
    
    return render_template(
        'client/chat.html', 
        ai_integration_enabled=advanced_enabled,
        user=current_user,
        initial_question=initial_question,
        ai_name=ai_name,
        ai_greeting=ai_greeting
    )

@chat_bp.route('/api/chat', methods=['POST'])
@login_required
def chat_api():
    """API endpoint for chat interactions"""
    # Check if AI is enabled in settings
    ai_enabled = Settings.get_value('ai_enabled', 'false') == 'true'
    ai_mode = Settings.get_value('ai_mode', 'basic')
    ai_name = Settings.get_value('ai_name', 'Support Assistant')
    ai_greeting = Settings.get_value('ai_greeting', 'Hello! How can I assist you today?')
    
    # If AI is disabled, return error
    if not ai_enabled:
        return jsonify({
            'error': 'AI assistant is currently disabled',
            'timestamp': datetime.now().strftime('%H:%M')
        }), 403
    
    data = request.json
    user_message = data.get('message', '').strip().lower()
    
    # Simulate processing time for a more natural interaction
    time.sleep(0.5)
    
    # Check if it's a greeting
    if is_greeting(user_message):
        # Use custom greeting if available
        return jsonify({
            'message': ai_greeting,
            'timestamp': datetime.now().strftime('%H:%M'),
            'assistant_name': ai_name
        })
    
    # Generate a response based on user message and AI mode
    if ai_mode == 'advanced' and anthropic_client:
        response = generate_response(user_message, use_anthropic=True)
    else:
        response = generate_response(user_message, use_anthropic=False)
    
    return jsonify({
        'message': response,
        'timestamp': datetime.now().strftime('%H:%M'),
        'assistant_name': ai_name
    })

def is_greeting(message):
    """Check if the message is a greeting"""
    greetings = ['hello', 'hi', 'hey', 'greetings', 'good morning', 'good afternoon', 'good evening', 'howdy']
    return any(greeting in message for greeting in greetings)

def generate_response(message, use_anthropic=False):
    """Generate a response based on the user message"""
    # Use Anthropic API if available and requested
    if use_anthropic and anthropic_client:
        try:
            # the newest Anthropic model is "claude-3-5-sonnet-20241022" which was released October 22, 2024
            system_prompt = """You are a helpful AI assistant embedded in a VPS Control Panel. 
            Keep your responses focused on VPS management, billing, account settings, and technical support.
            Be concise but thorough, focusing on providing accurate information.
            
            Key information to know:
            1. Users can manage their VPS servers including power actions (start, stop, restart)
            2. Server resources include CPU, RAM, disk space, and bandwidth
            3. Billing is handled monthly with invoices generated on the 1st
            4. We accept credit cards, PayPal, and cryptocurrency payments
            5. Users can open support tickets for technical assistance
            6. Two-factor authentication is available for account security
            7. Advanced features include automated backups, firewall rules, and traffic analytics
            8. Server status can be checked from the 'My Servers' section in the dashboard
            9. We offer monthly, quarterly, and annual billing options with discounts
            10. Support tickets can be categorized as Technical, Billing, Sales, or General Inquiries
            
            Avoid:
            - Discussing topics unrelated to VPS hosting or server management
            - Making promises about specific features not mentioned
            - Providing technical advice that could compromise security
            
            Always direct users to open a support ticket for complex issues beyond basic assistance."""
            
            response = anthropic_client.messages.create(
                model="claude-3-5-sonnet-20241022",
                max_tokens=300,
                system=system_prompt,
                messages=[{"role": "user", "content": message}]
            )
            
            return response.content[0].text
            
        except Exception as e:
            logger.error(f"Error using Anthropic API: {e}")
            # Fall back to rule-based responses if API call fails
    
    # Rule-based fallback approach
    # Convert message to lowercase for easier matching
    message = message.lower()
    
    # Define specific question patterns that get targeted responses
    specific_patterns = {
        "how do i check (my )?server status": "To check your server status, go to the 'My Servers' section in your dashboard and look at the status indicator next to your server. Green indicates running, red indicates stopped, and yellow indicates restarting or in progress.",
        "when is my next billing cycle": "Your next billing cycle begins on the 1st of the following month from your signup date. You can view your exact billing dates in the Billing section of your dashboard.",
        "how do i open a (support )?ticket": "To open a new support ticket, go to the Support menu in the navigation bar, select 'Support Tickets', and then click the 'New Ticket' button. Fill in the details of your issue and submit the form.",
        "how (can|do) i restart my server": "You can restart your server by going to the VPS details page, clicking on the 'Actions' dropdown menu, and selecting 'Restart'. The server will initiate a graceful shutdown followed by a restart.",
        "how (can|do) i upgrade (my )?(server )?resources": "To upgrade your server resources, navigate to the Billing section, find your server subscription, and click on 'Upgrade'. You can select additional CPU, RAM, or disk space based on your needs.",
        "(what is|explain) the (process to|how do i) cancel (a )?service": "To cancel a service, go to the Billing section, locate the service you wish to cancel, and click on 'Cancel Service'. You'll be asked to confirm and provide feedback about your cancellation reason.",
        "what payment methods (do you|are) accept(ed)?": "We accept credit cards (Visa, MasterCard, American Express), PayPal, and cryptocurrency payments (Bitcoin, Ethereum). You can manage your payment methods in the Billing section under 'Payment Methods'."
    }
    
    # Check for direct matches to specific questions
    for pattern, answer in specific_patterns.items():
        import re
        if re.search(pattern, message):
            return answer
    
    # Check for keywords in message and find relevant responses
    responses = []
    
    # Check for server-related questions
    if any(keyword in message for keyword in ['server', 'vps', 'cpu', 'ram', 'disk', 'bandwidth', 'reboot', 'restart', 'status', 'power', 'ssh']):
        responses.extend(KNOWLEDGE_BASE['server'])
    
    # Check for billing-related questions
    if any(keyword in message for keyword in ['bill', 'invoice', 'payment', 'credit', 'pay', 'cost', 'price', 'subscription', 'cancel', 'refund', 'renew']):
        responses.extend(KNOWLEDGE_BASE['billing'])
    
    # Check for account-related questions
    if any(keyword in message for keyword in ['account', 'password', 'email', 'profile', 'setting', 'notification', 'login', 'security', '2fa', 'two-factor']):
        responses.extend(KNOWLEDGE_BASE['account'])
    
    # Check for support-related questions
    if any(keyword in message for keyword in ['support', 'help', 'ticket', 'issue', 'problem', 'contact', 'assistance', 'chat', 'question']):
        responses.extend(KNOWLEDGE_BASE['support'])
    
    # Check for features-related questions
    if any(keyword in message for keyword in ['feature', 'functionality', 'capability', 'tool', 'backup', 'monitoring', 'firewall', 'analytics', 'api', 'scaling']):
        responses.extend(KNOWLEDGE_BASE['features'])
    
    # If we found some relevant responses, return one randomly
    if responses:
        return random.choice(responses)
    
    # If no matches, return a fallback response
    return random.choice(FALLBACK_RESPONSES)