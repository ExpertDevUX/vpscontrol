from flask import Blueprint, render_template, redirect, url_for, flash, request
from flask_login import login_required, current_user
from datetime import datetime
import logging

from app import db
from models import User, Server, ServerTemplate, Invoice, Ticket, Transaction, ServerUsage, License

client_bp = Blueprint('client', __name__)
logger = logging.getLogger(__name__)

@client_bp.route('/')
@login_required
def dashboard():
    from sqlalchemy import func, desc, and_, or_, case, text
    from sqlalchemy.orm import joinedload, aliased

    # Use a single query for active servers with their latest usage data using a subquery
    # This replaces multiple queries with a single optimized one
    ServerUsageAlias = aliased(ServerUsage)
    latest_usage_subq = db.session.query(
        ServerUsage.server_id,
        func.max(ServerUsage.timestamp).label('max_timestamp')
    ).group_by(ServerUsage.server_id).subquery('latest_usage')
    
    # Join with the servers and server usage in a single query
    servers_with_usage = db.session.query(
        Server, 
        ServerUsageAlias
    ).outerjoin(
        latest_usage_subq, 
        Server.id == latest_usage_subq.c.server_id
    ).outerjoin(
        ServerUsageAlias, 
        and_(
            ServerUsageAlias.server_id == latest_usage_subq.c.server_id,
            ServerUsageAlias.timestamp == latest_usage_subq.c.max_timestamp
        )
    ).filter(
        Server.user_id == current_user.id,
        Server.status == 'active'
    ).all()
    
    # Format the result for the template
    active_servers = [server for server, _ in servers_with_usage]
    server_stats = []
    for server, usage in servers_with_usage:
        server_stats.append({
            'server': server,
            'usage': usage
        })
    
    # Optimize by getting recent invoices, open tickets, licenses, and unpaid amount in fewer queries
    # Use eager loading where appropriate to reduce N+1 query problems
    recent_invoices = Invoice.query.filter_by(user_id=current_user.id)\
        .options(joinedload(Invoice.items))\
        .order_by(desc(Invoice.issue_date))\
        .limit(5).all()
    
    open_tickets = Ticket.query.filter_by(user_id=current_user.id)\
        .filter(Ticket.status != 'closed')\
        .order_by(desc(Ticket.updated_at))\
        .limit(5).all()
    
    licenses = License.query.filter_by(user_id=current_user.id).all()
    
    # Calculate account balance (unpaid invoices)
    unpaid_amount = db.session.query(func.sum(Invoice.total_amount))\
        .filter_by(user_id=current_user.id, status='unpaid')\
        .scalar() or 0
    
    return render_template('client/dashboard.html',
                          active_servers=active_servers,
                          server_stats=server_stats,
                          recent_invoices=recent_invoices,
                          open_tickets=open_tickets,
                          unpaid_amount=unpaid_amount,
                          licenses=licenses)

@client_bp.route('/vps')
@login_required
def vps_list():
    # Get all user's servers
    servers = Server.query.filter_by(user_id=current_user.id).all()
    
    # Get available server templates for ordering
    templates = ServerTemplate.query.filter_by(is_active=True).all()
    
    return render_template('client/vps.html', servers=servers, templates=templates)

@client_bp.route('/vps/<int:server_id>')
@login_required
def vps_details(server_id):
    from sqlalchemy.orm import joinedload
    
    # Use eager loading to avoid N+1 query problem by loading relationships in a single query
    server = Server.query.filter_by(id=server_id, user_id=current_user.id)\
        .options(joinedload(Server.template))\
        .first_or_404()
    
    # Get server usage data for charts with a optimized query
    # We limit the data points and order them directly in the database
    # to minimize data transfer and processing
    usage_data = ServerUsage.query.filter_by(server_id=server.id)\
        .order_by(ServerUsage.timestamp.asc())\
        .limit(24).all()
    
    # Since we've ordered ascending in the database, we don't need to reverse
    # This saves a list operation
    
    # We can use the already loaded template info through the relationship
    template = server.template
    
    return render_template('client/vps_details.html', 
                          server=server, 
                          usage_data=usage_data,
                          template=template)

@client_bp.route('/vps/<int:server_id>/action', methods=['POST'])
@login_required
def vps_action(server_id):
    server = Server.query.filter_by(id=server_id, user_id=current_user.id).first_or_404()
    
    action = request.form.get('action')
    if action == 'start':
        # Call to VPS provider API would go here
        flash('Server start request sent. It may take a few moments to complete.', 'info')
    
    elif action == 'stop':
        # Call to VPS provider API would go here
        flash('Server stop request sent. It may take a few moments to complete.', 'info')
    
    elif action == 'restart':
        # Call to VPS provider API would go here
        flash('Server restart request sent. It may take a few moments to complete.', 'info')
    
    elif action == 'reinstall':
        os_template = request.form.get('os_template')
        # Call to VPS provider API would go here
        flash(f'Server reinstall with {os_template} requested. This may take several minutes to complete.', 'info')
    
    return redirect(url_for('client.vps_details', server_id=server_id))

@client_bp.route('/billing')
@login_required
def billing():
    # Get all user's invoices
    invoices = Invoice.query.filter_by(user_id=current_user.id)\
        .order_by(Invoice.issue_date.desc())\
        .all()
    
    # Get payment transactions
    transactions = Transaction.query.join(Invoice)\
        .filter(Invoice.user_id == current_user.id)\
        .order_by(Transaction.transaction_date.desc())\
        .all()
    
    # Calculate account balance (unpaid invoices)
    unpaid_amount = db.session.query(db.func.sum(Invoice.total_amount))\
        .filter_by(user_id=current_user.id, status='unpaid')\
        .scalar() or 0
    
    return render_template('client/billing.html', 
                          invoices=invoices, 
                          transactions=transactions,
                          unpaid_amount=unpaid_amount)

@client_bp.route('/invoice/<int:invoice_id>')
@login_required
def invoice_details(invoice_id):
    from sqlalchemy.orm import joinedload
    from models import InvoiceItem
    
    # Use eager loading to avoid multiple queries
    # Load invoice with its items and transactions in a single query
    invoice = Invoice.query.filter_by(id=invoice_id, user_id=current_user.id)\
        .options(
            joinedload(Invoice.items),
            joinedload(Invoice.transactions)
        ).first_or_404()
    
    # The data is already loaded via relationships
    items = invoice.items
    transactions = invoice.transactions
    
    return render_template('client/invoice_details.html',
                          invoice=invoice,
                          items=items,
                          transactions=transactions)

@client_bp.route('/invoice/<int:invoice_id>/pay', methods=['POST'])
@login_required
def pay_invoice(invoice_id):
    invoice = Invoice.query.filter_by(id=invoice_id, user_id=current_user.id).first_or_404()
    
    if invoice.status != 'unpaid':
        flash('This invoice has already been paid or cancelled.', 'warning')
        return redirect(url_for('client.invoice_details', invoice_id=invoice_id))
    
    payment_method = request.form.get('payment_method')
    
    # In a real implementation, this would redirect to a payment gateway
    # For this example, we'll just mark the invoice as paid
    
    # Create a transaction record
    transaction = Transaction(
        transaction_id=f"DEMO-{datetime.utcnow().strftime('%Y%m%d%H%M%S')}",
        gateway=payment_method,
        amount=invoice.total_amount,
        status='success',
        invoice_id=invoice.id
    )
    db.session.add(transaction)
    
    # Update invoice status
    invoice.status = 'paid'
    invoice.paid_date = datetime.utcnow()
    
    db.session.commit()
    
    flash('Payment successful! Thank you for your payment.', 'success')
    return redirect(url_for('client.invoice_details', invoice_id=invoice_id))

@client_bp.route('/tickets')
@login_required
def tickets():
    # Get all user's tickets
    tickets = Ticket.query.filter_by(user_id=current_user.id)\
        .order_by(Ticket.updated_at.desc())\
        .all()
    
    return render_template('client/tickets.html', tickets=tickets)

@client_bp.route('/tickets/new', methods=['GET', 'POST'])
@login_required
def new_ticket():
    if request.method == 'POST':
        subject = request.form.get('subject')
        message = request.form.get('message')
        priority = request.form.get('priority', 'medium')
        
        if not subject or not message:
            flash('Please provide both subject and message.', 'danger')
            return render_template('client/new_ticket.html')
        
        # Create the ticket
        ticket = Ticket(
            subject=subject,
            priority=priority,
            user_id=current_user.id
        )
        db.session.add(ticket)
        db.session.flush()  # Get the ticket ID
        
        # Create the first message
        from models import TicketMessage
        ticket_message = TicketMessage(
            message=message,
            is_from_admin=False,
            ticket_id=ticket.id,
            user_id=current_user.id
        )
        db.session.add(ticket_message)
        
        db.session.commit()
        
        flash('Ticket created successfully.', 'success')
        return redirect(url_for('client.ticket_details', ticket_id=ticket.id))
    
    return render_template('client/new_ticket.html')

@client_bp.route('/tickets/<int:ticket_id>', methods=['GET', 'POST'])
@login_required
def ticket_details(ticket_id):
    from sqlalchemy.orm import joinedload
    from models import TicketMessage
    
    # Use eager loading to preload related users for each message in a single query
    ticket = Ticket.query.filter_by(id=ticket_id, user_id=current_user.id).first_or_404()
    
    if request.method == 'POST':
        # Add reply to ticket
        message = request.form.get('message')
        
        if message:
            ticket_message = TicketMessage(
                message=message,
                is_from_admin=False,
                ticket_id=ticket.id,
                user_id=current_user.id
            )
            db.session.add(ticket_message)
            
            # Update ticket status if it was closed
            if ticket.status == 'closed':
                ticket.status = 'open'
                
            ticket.updated_at = datetime.utcnow()
            
            # Commit all changes in one transaction
            db.session.commit()
            
            flash('Reply sent successfully.', 'success')
            return redirect(url_for('client.ticket_details', ticket_id=ticket.id))
    
    # Get ticket messages with user information in a single query
    # This avoids N+1 query problem when displaying user info for each message
    messages = TicketMessage.query.filter_by(ticket_id=ticket.id)\
        .options(joinedload(TicketMessage.user))\
        .order_by(TicketMessage.created_at)\
        .all()
    
    return render_template('client/ticket_details.html', 
                          ticket=ticket, 
                          messages=messages)

@client_bp.route('/tickets/<int:ticket_id>/close', methods=['POST'])
@login_required
def close_ticket(ticket_id):
    ticket = Ticket.query.filter_by(id=ticket_id, user_id=current_user.id).first_or_404()
    
    ticket.status = 'closed'
    ticket.closed_at = datetime.utcnow()
    
    db.session.commit()
    
    flash('Ticket closed successfully.', 'success')
    return redirect(url_for('client.tickets'))
