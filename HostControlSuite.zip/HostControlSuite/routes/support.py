from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from datetime import datetime
import logging

from app import db
from models import Ticket, TicketMessage, User

support_bp = Blueprint('support', __name__)
logger = logging.getLogger(__name__)

@support_bp.route('/ticket/<int:ticket_id>/reply', methods=['POST'])
@login_required
def reply_ticket(ticket_id):
    # Check if the user owns the ticket or is an admin
    ticket = Ticket.query.get_or_404(ticket_id)
    
    if ticket.user_id != current_user.id and not current_user.has_role('admin'):
        flash('You do not have permission to reply to this ticket.', 'danger')
        return redirect(url_for('auth.index'))
    
    message_text = request.form.get('message')
    
    if not message_text:
        flash('Message cannot be empty.', 'danger')
        if current_user.has_role('admin'):
            return redirect(url_for('admin.ticket_details', ticket_id=ticket_id))
        else:
            return redirect(url_for('client.ticket_details', ticket_id=ticket_id))
    
    # Create the message
    message = TicketMessage(
        message=message_text,
        is_from_admin=current_user.has_role('admin'),
        ticket_id=ticket.id,
        user_id=current_user.id
    )
    db.session.add(message)
    
    # Update ticket status
    if current_user.has_role('admin'):
        ticket.status = 'answered'
    else:
        ticket.status = 'open'
    
    ticket.updated_at = datetime.utcnow()
    db.session.commit()
    
    flash('Reply sent successfully.', 'success')
    
    if current_user.has_role('admin'):
        return redirect(url_for('admin.ticket_details', ticket_id=ticket_id))
    else:
        return redirect(url_for('client.ticket_details', ticket_id=ticket_id))

@support_bp.route('/ticket/<int:ticket_id>/close', methods=['POST'])
@login_required
def close_ticket(ticket_id):
    # Check if the user owns the ticket or is an admin
    ticket = Ticket.query.get_or_404(ticket_id)
    
    if ticket.user_id != current_user.id and not current_user.has_role('admin'):
        flash('You do not have permission to close this ticket.', 'danger')
        return redirect(url_for('auth.index'))
    
    ticket.status = 'closed'
    ticket.closed_at = datetime.utcnow()
    db.session.commit()
    
    flash('Ticket closed successfully.', 'success')
    
    if current_user.has_role('admin'):
        return redirect(url_for('admin.tickets'))
    else:
        return redirect(url_for('client.tickets'))

@support_bp.route('/ticket/<int:ticket_id>/reopen', methods=['POST'])
@login_required
def reopen_ticket(ticket_id):
    # Check if the user owns the ticket or is an admin
    ticket = Ticket.query.get_or_404(ticket_id)
    
    if ticket.user_id != current_user.id and not current_user.has_role('admin'):
        flash('You do not have permission to reopen this ticket.', 'danger')
        return redirect(url_for('auth.index'))
    
    ticket.status = 'open'
    ticket.updated_at = datetime.utcnow()
    db.session.commit()
    
    flash('Ticket reopened successfully.', 'success')
    
    if current_user.has_role('admin'):
        return redirect(url_for('admin.ticket_details', ticket_id=ticket_id))
    else:
        return redirect(url_for('client.ticket_details', ticket_id=ticket_id))

@support_bp.route('/admin/ticket/<int:ticket_id>/priority', methods=['POST'])
def update_priority():
    from routes.admin import admin_required
    
    @admin_required
    def set_priority(ticket_id):
        ticket = Ticket.query.get_or_404(ticket_id)
        priority = request.form.get('priority')
        
        ticket.priority = priority
        db.session.commit()
        
        flash(f'Ticket priority updated to {priority}.', 'success')
        return redirect(url_for('admin.ticket_details', ticket_id=ticket_id))
    
    return set_priority()
