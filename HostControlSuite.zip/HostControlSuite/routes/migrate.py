from flask import Blueprint, flash, redirect, url_for
from flask_login import login_required
from sqlalchemy import text

from models import db
from routes.admin import admin_required

migrate_bp = Blueprint('migrate', __name__)

@migrate_bp.route('/run_migration')
@login_required
@admin_required
def run_migration():
    """Run database migration to update schema"""
    try:
        # Add features column to license table
        db.session.execute(text('ALTER TABLE "license" ADD COLUMN IF NOT EXISTS features TEXT'))

        # Add template_id column to license table  
        db.session.execute(text('ALTER TABLE "license" ADD COLUMN IF NOT EXISTS template_id INTEGER'))

        # Add foreign key constraint
        db.session.execute(text('''
            DO $$
            BEGIN
                IF NOT EXISTS (
                    SELECT 1 FROM pg_constraint WHERE conname = 'license_template_id_fkey'
                ) THEN
                    ALTER TABLE "license" 
                    ADD CONSTRAINT license_template_id_fkey 
                    FOREIGN KEY (template_id) 
                    REFERENCES license_template(id);
                END IF;
            END
            $$;
        '''))
        
        db.session.commit()
        flash('Migration completed successfully', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Migration failed: {str(e)}', 'danger')
    
    return redirect(url_for('admin.dashboard'))