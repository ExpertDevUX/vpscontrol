from flask import Blueprint, render_template, jsonify, request, redirect, url_for, flash
from flask_login import login_required, current_user
from datetime import datetime
import logging
import json
import threading
import time
import random

from app import db
from models import Server, Notification

deployment_bp = Blueprint('deployment', __name__)
logger = logging.getLogger(__name__)

# Store active deployment simulations
active_deployments = {}

@deployment_bp.route('/client/deployment-dashboard')
@login_required
def dashboard():
    """Display the deployment dashboard"""
    # Optimize by making a single query with UNION
    # Get all relevant servers in a single query with proper ordering
    from sqlalchemy import or_, desc, func, union_all
    
    # Build a more efficient query that gets all the data we need in one go
    current_time = datetime.utcnow()
    day_start = current_time.replace(hour=0, minute=0, second=0)
    
    # Using a single query with multiple conditions is more efficient
    servers = Server.query.filter(
        Server.user_id == current_user.id,
        Server.status != 'terminated',
        or_(
            Server.deployment_status.in_(['pending', 'in_progress', 'error']),
            # Recently completed
            db.and_(
                Server.deployment_status == 'complete',
                Server.deployment_completed_at >= day_start
            )
        )
    ).order_by(desc(Server.created_at)).all()
    
    return render_template('client/deployment_dashboard.html', servers=servers)

@deployment_bp.route('/api/deployment/status')
@login_required
def deployment_status():
    """API endpoint to get deployment status for servers"""
    # Get server IDs from query parameter
    server_ids = request.args.get('servers', '').split(',')
    
    if not server_ids or server_ids[0] == '':
        return jsonify({'error': 'No server IDs provided'}), 400
    
    # Filter out non-numeric IDs
    server_ids = [int(sid) for sid in server_ids if sid.isdigit()]
    
    # Get servers owned by the current user
    servers = Server.query.filter(
        Server.id.in_(server_ids),
        Server.user_id == current_user.id
    ).all()
    
    # Format the response
    result = {
        'servers': [{
            'server_id': server.id,
            'status': server.deployment_status,
            'progress': server.deployment_progress,
            'error_message': server.deployment_error_message
        } for server in servers]
    }
    
    return jsonify(result)

@deployment_bp.route('/api/deployment/<int:server_id>/logs')
@login_required
def deployment_logs(server_id):
    """API endpoint to get deployment logs for a server"""
    server = Server.query.filter_by(id=server_id, user_id=current_user.id).first_or_404()
    
    logs = []
    if server.deployment_log:
        logs = server.deployment_log.strip().split('\n')
    
    return jsonify({
        'server_id': server.id,
        'logs': logs
    })

@deployment_bp.route('/api/deployment/<int:server_id>/retry', methods=['POST'])
@login_required
def retry_deployment(server_id):
    """API endpoint to retry a failed deployment"""
    server = Server.query.filter_by(id=server_id, user_id=current_user.id).first_or_404()
    
    if server.deployment_status != 'error':
        return jsonify({'success': False, 'message': 'Only failed deployments can be retried'}), 400
    
    # Reset deployment status
    server.deployment_status = 'pending'
    server.deployment_progress = 0
    server.deployment_error_message = None
    server.add_deployment_log("[info] Deployment retry initiated by user")
    db.session.commit()
    
    # Start deployment simulation in a background thread
    start_deployment_simulation(server.id)
    
    return jsonify({'success': True})

def start_deployment_simulation(server_id):
    """Start a simulated deployment process in a background thread"""
    if server_id in active_deployments:
        logger.warning(f"Deployment already active for server ID {server_id}")
        return
    
    # Create and start a new thread for deployment simulation
    deployment_thread = threading.Thread(
        target=simulate_deployment_process,
        args=(server_id,)
    )
    deployment_thread.daemon = True
    deployment_thread.start()
    
    # Add to active deployments
    active_deployments[server_id] = deployment_thread
    logger.info(f"Started deployment simulation for server ID {server_id}")

def simulate_deployment_process(server_id):
    """Simulate a deployment process with status updates"""
    try:
        server = Server.query.get(server_id)
        if not server:
            logger.error(f"Server with ID {server_id} not found")
            return
        
        # Initialize deployment
        server.deployment_status = 'in_progress'
        server.deployment_progress = 5
        server.deployment_started_at = datetime.utcnow()
        server.add_deployment_log("[info] Starting server deployment")
        db.session.commit()
        
        # Stage 1: Provisioning Infrastructure (5-25%)
        time.sleep(random.uniform(3, 5))  # simulate time passing
        server.deployment_progress = 10
        server.add_deployment_log("[info] Allocating resources")
        db.session.commit()
        
        time.sleep(random.uniform(2, 4))
        server.deployment_progress = 15
        server.add_deployment_log("[info] Creating virtual machine")
        db.session.commit()
        
        time.sleep(random.uniform(2, 3))
        server.deployment_progress = 20
        server.add_deployment_log("[info] Setting up storage")
        db.session.commit()
        
        # Simulate a random failure (5% chance of failing at this stage)
        if random.random() < 0.05:
            server.deployment_status = 'error'
            server.deployment_error_message = "Failed to allocate resources - infrastructure limit reached"
            server.add_deployment_log("[error] Failed to allocate resources - infrastructure limit reached")
            db.session.commit()
            return
        
        # Stage 2: Setting Up Network (25-50%)
        time.sleep(random.uniform(3, 5))
        server.deployment_progress = 30
        server.add_deployment_log("[info] Configuring network interfaces")
        db.session.commit()
        
        time.sleep(random.uniform(2, 4))
        server.deployment_progress = 40
        server.add_deployment_log("[info] Setting up firewall rules")
        db.session.commit()
        
        # Stage 3: Installing OS (50-75%)
        time.sleep(random.uniform(4, 8))
        server.deployment_progress = 55
        server.add_deployment_log(f"[info] Installing {server.operating_system}")
        db.session.commit()
        
        time.sleep(random.uniform(3, 6))
        server.deployment_progress = 65
        server.add_deployment_log("[info] Configuring system parameters")
        db.session.commit()
        
        # Stage 4: Configuring Services (75-90%)
        time.sleep(random.uniform(3, 5))
        server.deployment_progress = 80
        server.add_deployment_log("[info] Setting up security")
        db.session.commit()
        
        time.sleep(random.uniform(2, 4))
        server.deployment_progress = 85
        server.add_deployment_log("[info] Installing required packages")
        db.session.commit()
        
        # Stage 5: Finalizing (90-100%)
        time.sleep(random.uniform(2, 3))
        server.deployment_progress = 95
        server.add_deployment_log("[info] Performing final configuration")
        db.session.commit()
        
        time.sleep(random.uniform(1, 2))
        server.deployment_progress = 100
        server.deployment_status = 'complete'
        server.deployment_completed_at = datetime.utcnow()
        server.status = 'active'  # Update server status to active
        server.add_deployment_log("[success] Deployment completed successfully")
        db.session.commit()
        
        # Create a notification for the user
        notification = Notification(
            user_id=server.user_id,
            title="Server Deployment Complete",
            message=f"Your server {server.name} has been successfully deployed and is ready to use.",
            notification_type="system"
        )
        db.session.add(notification)
        db.session.commit()
        
    except Exception as e:
        logger.error(f"Error in deployment simulation: {str(e)}")
        try:
            server = Server.query.get(server_id)
            if server:
                server.deployment_status = 'error'
                server.deployment_error_message = f"Deployment failed: {str(e)}"
                server.add_deployment_log(f"[error] Deployment failed: {str(e)}")
                db.session.commit()
        except Exception as inner_e:
            logger.error(f"Failed to update server status: {str(inner_e)}")
    finally:
        # Remove from active deployments
        if server_id in active_deployments:
            del active_deployments[server_id]