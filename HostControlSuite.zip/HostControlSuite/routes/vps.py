from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from datetime import datetime, timedelta
import logging
import random  # For demo purposes only

from app import db
from models import Server, ServerTemplate, Invoice, InvoiceItem, ServerUsage
from utils.vps_manager import provision_server, delete_server, start_server, stop_server, restart_server, reinstall_os

vps_bp = Blueprint('vps', __name__)
logger = logging.getLogger(__name__)

@vps_bp.route('/order', methods=['POST'])
@login_required
def order():
    template_id = request.form.get('template_id')
    hostname = request.form.get('hostname')
    operating_system = request.form.get('operating_system')
    
    # Validate inputs
    if not template_id or not hostname or not operating_system:
        flash('Please provide all required information.', 'danger')
        return redirect(url_for('client.vps_list'))
    
    # Get the server template
    template = ServerTemplate.query.get_or_404(template_id)
    
    # Create the invoice first
    invoice_number = f"INV-{datetime.utcnow().strftime('%Y%m%d')}-{current_user.id}"
    due_date = datetime.utcnow() + timedelta(days=7)
    
    invoice = Invoice(
        invoice_number=invoice_number,
        amount=template.price_monthly,
        tax_amount=template.price_monthly * 0.1,  # 10% tax example
        total_amount=template.price_monthly * 1.1,
        status='unpaid',
        due_date=due_date,
        user_id=current_user.id,
        notes=f"Monthly charge for {template.name} VPS"
    )
    db.session.add(invoice)
    db.session.flush()  # Get the invoice ID
    
    # Create the invoice item
    invoice_item = InvoiceItem(
        description=f"{template.name} VPS ({hostname}) - Monthly Fee",
        amount=template.price_monthly,
        quantity=1,
        invoice_id=invoice.id
    )
    db.session.add(invoice_item)
    
    # In a real implementation, server provisioning would be done after payment
    # For this demo, we'll create the server in 'pending' status initially
    
    # If template has a provider, we should try to provision a real server
    provider_server_id = None
    expiry_date = datetime.utcnow() + timedelta(days=30)
    
    if hasattr(template, 'provider') and template.provider:
        logger.info(f"Provisioning real server with provider {template.provider.name} for template {template.name}")
        
        # This is an expensive operation and would normally be done asynchronously
        # after payment confirmation. For the demo we'll do it synchronously.
        from utils.vps_manager import provision_server
        server_data = provision_server(
            hostname=hostname,
            template=template,
            operating_system=operating_system,
            user_id=current_user.id,
            billing_cycle='monthly'
        )
        
        if server_data:
            # Use the data from the cloud provider
            ip_address = server_data.get('ip_address', f"192.168.{random.randint(1, 254)}.{random.randint(1, 254)}")
            username = server_data.get('username', f"user{random.randint(1000, 9999)}")
            password = server_data.get('password', f"pass{random.randint(1000, 9999)}")
            ssh_port = server_data.get('ssh_port', 22)
            status = server_data.get('status', 'pending')
            expiry_date = server_data.get('expiry_date', expiry_date)
            provider_server_id = server_data.get('provider_server_id')
            
            logger.info(f"Server provisioned with cloud provider: IP {ip_address}, Status: {status}")
        else:
            # Fall back to mock values if provisioning failed
            logger.warning("Failed to provision server with cloud provider, falling back to mock data")
            ip_address = f"192.168.{random.randint(1, 254)}.{random.randint(1, 254)}"
            username = f"user{random.randint(1000, 9999)}"
            password = f"pass{random.randint(1000, 9999)}"
            ssh_port = 22  # Default SSH port
            status = 'pending'
    else:
        # No cloud provider, use mock data
        ip_address = f"192.168.{random.randint(1, 254)}.{random.randint(1, 254)}"
        username = f"user{random.randint(1000, 9999)}"
        password = f"pass{random.randint(1000, 9999)}"
        ssh_port = 22  # Default SSH port
        status = 'pending'
    
    server = Server(
        name=hostname,
        hostname=hostname,
        ip_address=ip_address,
        status=status,
        operating_system=operating_system,
        username=username,
        password=password,
        ssh_port=ssh_port,
        cpu_cores=template.cpu_cores,
        ram_mb=template.ram_mb,
        disk_gb=template.disk_gb,
        bandwidth_gb=template.bandwidth_gb,
        bandwidth_used_gb=0,
        expiry_date=expiry_date,
        user_id=current_user.id,
        template_id=template.id,
        provider_server_id=provider_server_id
    )
    db.session.add(server)
    db.session.commit()
    
    # Update invoice item with server ID
    invoice_item.server_id = server.id
    db.session.commit()
    
    flash('VPS ordered successfully! Please pay the invoice to activate your server.', 'success')
    return redirect(url_for('client.invoice_details', invoice_id=invoice.id))

@vps_bp.route('/renew/<int:server_id>', methods=['POST'])
@login_required
def renew():
    server_id = request.form.get('server_id')
    server = Server.query.filter_by(id=server_id, user_id=current_user.id).first_or_404()
    
    # Get the server template
    template = ServerTemplate.query.get(server.template_id)
    
    # Create the invoice
    invoice_number = f"INV-{datetime.utcnow().strftime('%Y%m%d')}-{current_user.id}"
    due_date = datetime.utcnow() + timedelta(days=7)
    
    invoice = Invoice(
        invoice_number=invoice_number,
        amount=template.price_monthly,
        tax_amount=template.price_monthly * 0.1,  # 10% tax example
        total_amount=template.price_monthly * 1.1,
        status='unpaid',
        due_date=due_date,
        user_id=current_user.id,
        notes=f"Monthly renewal for {server.hostname}"
    )
    db.session.add(invoice)
    db.session.flush()  # Get the invoice ID
    
    # Create the invoice item
    invoice_item = InvoiceItem(
        description=f"Renewal of {server.hostname} - Monthly Fee",
        amount=template.price_monthly,
        quantity=1,
        server_id=server.id,
        invoice_id=invoice.id
    )
    db.session.add(invoice_item)
    db.session.commit()
    
    flash('Renewal invoice created. Please pay to extend your server.', 'success')
    return redirect(url_for('client.invoice_details', invoice_id=invoice.id))

@vps_bp.route('/api/status/<int:server_id>')
@login_required
def server_status(server_id):
    server = Server.query.filter_by(id=server_id, user_id=current_user.id).first_or_404()
    
    # Query the VPS provider's API through our vps_manager module
    from utils.vps_manager import get_server_status
    
    # Get real-time server status from the cloud provider
    status_data = get_server_status(server_id)
    
    # Create a server usage record with the received values
    cpu_usage = status_data.get('cpu_usage', 0)
    ram_usage = status_data.get('ram_usage', 0)
    disk_usage = status_data.get('disk_usage', 0)
    network_in = status_data.get('network_in', 0)
    network_out = status_data.get('network_out', 0)
    
    # Update the server status in the database if needed
    current_status = status_data.get('status', server.status)
    if current_status != server.status:
        server.status = current_status
        db.session.commit()
    
    # Save the usage data for historical tracking
    usage = ServerUsage(
        cpu_usage_percent=cpu_usage,
        ram_usage_percent=ram_usage,
        disk_usage_percent=disk_usage,
        network_in_mb=network_in,
        network_out_mb=network_out,
        server_id=server.id
    )
    db.session.add(usage)
    db.session.commit()
    
    return jsonify({
        'status': current_status,
        'cpu_usage': cpu_usage,
        'ram_usage': ram_usage,
        'disk_usage': disk_usage,
        'network_in': network_in,
        'network_out': network_out,
        'timestamp': datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
    })

@vps_bp.route('/api/usage/<int:server_id>')
@login_required
def server_usage(server_id):
    server = Server.query.filter_by(id=server_id, user_id=current_user.id).first_or_404()
    
    # Get usage data for the past 24 hours
    usage_data = ServerUsage.query.filter_by(server_id=server.id)\
        .order_by(ServerUsage.timestamp.desc())\
        .limit(24).all()
    
    # Format data for chart.js
    cpu_data = []
    ram_data = []
    disk_data = []
    network_data = []
    labels = []
    
    for usage in reversed(usage_data):  # Oldest first
        labels.append(usage.timestamp.strftime('%H:%M'))
        cpu_data.append(usage.cpu_usage_percent)
        ram_data.append(usage.ram_usage_percent)
        disk_data.append(usage.disk_usage_percent)
        network_data.append({
            'in': usage.network_in_mb,
            'out': usage.network_out_mb
        })
    
    return jsonify({
        'labels': labels,
        'cpu_data': cpu_data,
        'ram_data': ram_data,
        'disk_data': disk_data,
        'network_data': network_data
    })

@vps_bp.route('/server_action/<int:server_id>', methods=['POST'])
@login_required
def server_action(server_id):
    """Handle server actions like start, stop, restart, reinstall"""
    server = Server.query.filter_by(id=server_id, user_id=current_user.id).first_or_404()
    action = request.form.get('action')
    
    if not action:
        flash('No action specified', 'danger')
        return redirect(url_for('client.vps_details', server_id=server.id))
    
    # Process the action
    if action == 'start':
        # Start the server
        if start_server(server.id):
            server.status = 'active'
            db.session.commit()
            flash('Server started successfully', 'success')
        else:
            flash('Failed to start server', 'danger')
    
    elif action == 'stop':
        # Stop the server
        if stop_server(server.id):
            server.status = 'stopped'
            db.session.commit()
            flash('Server stopped successfully', 'success')
        else:
            flash('Failed to stop server', 'danger')
    
    elif action == 'restart':
        # Restart the server
        if restart_server(server.id):
            server.status = 'active'
            db.session.commit()
            flash('Server restarted successfully', 'success')
        else:
            flash('Failed to restart server', 'danger')
    
    elif action == 'reinstall':
        # Reinstall the operating system
        operating_system = request.form.get('operating_system')
        if not operating_system:
            flash('Please select an operating system', 'warning')
            return redirect(url_for('client.vps_details', server_id=server.id))
        
        # In a real implementation, this would call the actual reinstall API
        # For this demo, we'll just simulate it by updating the server in the database
        result = reinstall_os(server.id, operating_system)
        
        # Handle the case where reinstall_os returns None (error)
        if result is None:
            flash('Failed to reinstall operating system', 'danger')
            return redirect(url_for('client.vps_details', server_id=server.id))
        
        # Update server with new password and keep or update SSH port
        server.password = result.get('password', f"pass{random.randint(1000, 9999)}")
        server.operating_system = operating_system
        server.ssh_port = result.get('ssh_port', 22)  # Default to port 22 if not provided
        db.session.commit()
        
        flash('Server operating system has been reinstalled successfully', 'success')
    
    else:
        flash(f'Unknown action: {action}', 'danger')
    
    return redirect(url_for('client.vps_details', server_id=server.id))
