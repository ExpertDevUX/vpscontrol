from flask import Blueprint, render_template, redirect, url_for, flash, request, session
from werkzeug.security import generate_password_hash, check_password_hash
from flask_login import login_user, logout_user, current_user, login_required
import logging
import os

from app import db
from models import User, Role, Settings
from utils.captcha_utils import verify_turnstile_token

auth_bp = Blueprint('auth', __name__)
logger = logging.getLogger(__name__)

@auth_bp.route('/')
def index():
    if current_user.is_authenticated:
        if current_user.has_role('admin'):
            return redirect(url_for('admin.dashboard'))
        else:
            return redirect(url_for('client.dashboard'))
    return redirect(url_for('auth.login'))

@auth_bp.route('/login', methods=['GET', 'POST'])
def login():
    if current_user.is_authenticated:
        if current_user.has_role('admin'):
            return redirect(url_for('admin.dashboard'))
        else:
            return redirect(url_for('client.dashboard'))
    
    # Check if CAPTCHA is enabled
    captcha_enabled = Settings.get_value('captcha_enabled', False)
    
    # Get the Turnstile site key for the template if CAPTCHA is enabled
    site_key = os.environ.get('TURNSTILE_SITE_KEY', '') if captcha_enabled else ''
            
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        remember = request.form.get('remember') == 'on'
        turnstile_token = request.form.get('cf-turnstile-response')
        
        # Verify CAPTCHA if enabled
        if captcha_enabled and not verify_turnstile_token(turnstile_token):
            flash('CAPTCHA verification failed. Please try again.', 'danger')
            return render_template('login.html', site_key=site_key, captcha_enabled=captcha_enabled)
        
        user = User.query.filter_by(email=email).first()
        
        if not user or not check_password_hash(user.password_hash, password):
            flash('Please check your login details and try again.', 'danger')
            return render_template('login.html', site_key=site_key, captcha_enabled=captcha_enabled)
        
        if not user.is_active:
            flash('Your account has been deactivated. Please contact support.', 'danger')
            return render_template('login.html', site_key=site_key, captcha_enabled=captcha_enabled)
            
        login_user(user, remember=remember)
        
        # Log successful login
        logger.info(f"User {user.email} logged in successfully")
        
        next_page = request.args.get('next')
        if next_page:
            return redirect(next_page)
        
        if user.has_role('admin'):
            return redirect(url_for('admin.dashboard'))
        else:
            return redirect(url_for('client.dashboard'))
            
    return render_template('login.html', site_key=site_key, captcha_enabled=captcha_enabled)

@auth_bp.route('/register', methods=['GET', 'POST'])
def register():
    if current_user.is_authenticated:
        return redirect(url_for('auth.index'))
    
    # Check if a referral code was provided
    referral_code = request.args.get('ref')
    
    # Check if CAPTCHA is enabled
    captcha_enabled = Settings.get_value('captcha_enabled', False)
    
    # Get the Turnstile site key for the template if CAPTCHA is enabled
    site_key = os.environ.get('TURNSTILE_SITE_KEY', '') if captcha_enabled else ''
    
    if request.method == 'POST':
        email = request.form.get('email')
        username = request.form.get('username')
        password = request.form.get('password')
        password_confirm = request.form.get('password_confirm')
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        company_name = request.form.get('company_name', '')
        referral_code = request.form.get('referral_code')
        turnstile_token = request.form.get('cf-turnstile-response')
        
        # Verify CAPTCHA if enabled
        if captcha_enabled and not verify_turnstile_token(turnstile_token):
            flash('CAPTCHA verification failed. Please try again.', 'danger')
            return render_template('register.html', referral_code=referral_code, site_key=site_key, captcha_enabled=captcha_enabled)
        
        # Form validation
        if password != password_confirm:
            flash('Passwords do not match.', 'danger')
            return render_template('register.html', referral_code=referral_code, site_key=site_key, captcha_enabled=captcha_enabled)
            
        user_by_email = User.query.filter_by(email=email).first()
        if user_by_email:
            flash('Email address already registered.', 'danger')
            return render_template('register.html', referral_code=referral_code, site_key=site_key, captcha_enabled=captcha_enabled)
            
        user_by_username = User.query.filter_by(username=username).first()
        if user_by_username:
            flash('Username already taken.', 'danger')
            return render_template('register.html', referral_code=referral_code, site_key=site_key, captcha_enabled=captcha_enabled)
            
        # Create new user
        client_role = Role.query.filter_by(name='client').first()
        if not client_role:
            client_role = Role(name='client', description='Client user')
            db.session.add(client_role)
            db.session.flush()
        
        # Generate a unique affiliate code for the new user
        import secrets
        affiliate_code = secrets.token_hex(6)  # 12 characters long
        
        # Check for referred_by if a referral code was provided
        referred_by = None
        if referral_code:
            referring_user = User.query.filter_by(affiliate_code=referral_code).first()
            if referring_user:
                referred_by = referring_user.id
                logger.info(f"User {email} was referred by user ID {referred_by}")
            
        new_user = User(
            email=email,
            username=username,
            password_hash=generate_password_hash(password),
            first_name=first_name,
            last_name=last_name,
            company_name=company_name,
            is_active=True,
            affiliate_code=affiliate_code,
            referred_by=referred_by,
            affiliate_status='inactive'  # Start as inactive
        )
        
        new_user.roles.append(client_role)
        
        db.session.add(new_user)
        db.session.commit()
        
        # Log successful registration
        logger.info(f"New user registered: {email} with affiliate code: {affiliate_code}")
        
        # If they were referred, notify the referrer
        if referred_by:
            from models import Notification
            notification = Notification(
                user_id=referred_by,
                title="New Referral Signup",
                message=f"A new user ({email}) has signed up using your affiliate link.",
                notification_type="affiliate"
            )
            db.session.add(notification)
            db.session.commit()
        
        flash('Registration successful! You can now log in.', 'success')
        return redirect(url_for('auth.login'))
        
    return render_template('register.html', referral_code=referral_code, site_key=site_key, captcha_enabled=captcha_enabled)

@auth_bp.route('/logout')
@login_required
def logout():
    logger.info(f"User {current_user.email} logged out")
    logout_user()
    flash('You have been logged out.', 'info')
    return redirect(url_for('auth.login'))

@auth_bp.route('/profile', methods=['GET', 'POST'])
@login_required
def profile():
    if request.method == 'POST':
        first_name = request.form.get('first_name')
        last_name = request.form.get('last_name')
        company_name = request.form.get('company_name', '')
        address = request.form.get('address', '')
        city = request.form.get('city', '')
        state = request.form.get('state', '')
        country = request.form.get('country', '')
        zip_code = request.form.get('zip_code', '')
        phone = request.form.get('phone', '')
        
        current_user.first_name = first_name
        current_user.last_name = last_name
        current_user.company_name = company_name
        current_user.address = address
        current_user.city = city
        current_user.state = state
        current_user.country = country
        current_user.zip_code = zip_code
        current_user.phone = phone
        
        db.session.commit()
        flash('Profile updated successfully.', 'success')
        
    return render_template('client/profile.html')

@auth_bp.route('/change-password', methods=['POST'])
@login_required
def change_password():
    current_password = request.form.get('current_password')
    new_password = request.form.get('new_password')
    confirm_password = request.form.get('confirm_password')
    
    if not check_password_hash(current_user.password_hash, current_password):
        flash('Current password is incorrect.', 'danger')
        return redirect(url_for('auth.profile'))
        
    if new_password != confirm_password:
        flash('New passwords do not match.', 'danger')
        return redirect(url_for('auth.profile'))
        
    current_user.password_hash = generate_password_hash(new_password)
    db.session.commit()
    
    flash('Password changed successfully.', 'success')
    return redirect(url_for('auth.profile'))
