from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from datetime import datetime
import logging
import json
import os
import requests

from app import db
from models import CloudProvider, ServerTemplate
from routes.admin import admin_required
from utils.cloud_manager import get_provider_manager

cloud_bp = Blueprint('cloud', __name__)
logger = logging.getLogger(__name__)

@cloud_bp.route('/admin/cloud_providers')
@login_required
@admin_required
def providers_list():
    """Admin page to list cloud providers"""
    providers = CloudProvider.query.all()
    return render_template('admin/cloud_providers.html', providers=providers)

@cloud_bp.route('/admin/cloud_providers/new', methods=['GET', 'POST'])
@login_required
@admin_required
def add_provider():
    """Admin page to add a new cloud provider"""
    if request.method == 'POST':
        name = request.form.get('name')
        provider_type = request.form.get('provider_type')
        api_key = request.form.get('api_key')
        api_secret = request.form.get('api_secret')
        region = request.form.get('region')
        notes = request.form.get('notes')
        
        # Create new provider
        provider = CloudProvider(
            name=name,
            provider_type=provider_type,
            api_key=api_key,
            api_secret=api_secret,
            region=region,
            notes=notes
        )
        
        db.session.add(provider)
        db.session.commit()
        
        flash(f'Cloud provider {name} added successfully', 'success')
        return redirect(url_for('cloud.providers_list'))
        
    return render_template('admin/add_cloud_provider.html')

@cloud_bp.route('/admin/cloud_providers/<int:provider_id>', methods=['GET', 'POST'])
@login_required
@admin_required
def edit_provider(provider_id):
    """Admin page to edit a cloud provider"""
    provider = CloudProvider.query.get_or_404(provider_id)
    
    if request.method == 'POST':
        provider.name = request.form.get('name')
        provider.provider_type = request.form.get('provider_type')
        provider.api_key = request.form.get('api_key')
        provider.api_secret = request.form.get('api_secret')
        provider.region = request.form.get('region')
        provider.notes = request.form.get('notes')
        provider.is_active = 'is_active' in request.form
        
        db.session.commit()
        
        flash(f'Cloud provider {provider.name} updated successfully', 'success')
        return redirect(url_for('cloud.providers_list'))
        
    return render_template('admin/edit_cloud_provider.html', provider=provider)

@cloud_bp.route('/admin/cloud_providers/<int:provider_id>/delete', methods=['POST'])
@login_required
@admin_required
def delete_provider(provider_id):
    """Delete a cloud provider"""
    provider = CloudProvider.query.get_or_404(provider_id)
    
    # Check if provider has templates
    if provider.templates:
        flash(f'Cannot delete provider {provider.name} as it has server templates', 'danger')
        return redirect(url_for('cloud.providers_list'))
    
    db.session.delete(provider)
    db.session.commit()
    
    flash(f'Cloud provider {provider.name} deleted successfully', 'success')
    return redirect(url_for('cloud.providers_list'))

@cloud_bp.route('/admin/cloud_providers/<int:provider_id>/test', methods=['POST'])
@login_required
@admin_required
def test_provider(provider_id):
    """Test connection to cloud provider API"""
    provider = CloudProvider.query.get_or_404(provider_id)
    
    try:
        # Get the appropriate provider manager
        cloud_manager = get_provider_manager(provider)
        
        # Test the connection
        result = cloud_manager.test_connection()
        
        # Return the result
        return jsonify({
            'success': result['success'],
            'message': result['message']
        })
    except Exception as e:
        logger.error(f"Error testing provider connection: {str(e)}")
        return jsonify({
            'success': False,
            'message': f"Error: {str(e)}"
        })

@cloud_bp.route('/admin/cloud_providers/<int:provider_id>/sync', methods=['POST'])
@login_required
@admin_required
def sync_provider_plans(provider_id):
    """Sync available plans from cloud provider API"""
    provider = CloudProvider.query.get_or_404(provider_id)
    
    try:
        # Get the appropriate provider manager
        cloud_manager = get_provider_manager(provider)
        
        # Get available plans from the provider
        plans_result = cloud_manager.get_available_plans()
        
        if not plans_result['success']:
            flash(f"Failed to sync plans: {plans_result['message']}", 'danger')
            return jsonify({
                'success': False,
                'message': plans_result['message']
            })
        
        # Get available operating systems
        os_result = cloud_manager.get_available_os()
        
        # Check if we already have plans from this provider
        existing_plans = ServerTemplate.query.filter_by(provider_id=provider.id).all()
        if existing_plans:
            logger.info(f'Provider {provider.name} already has {len(existing_plans)} plans. Syncing will update them.')
        
        # Available OS list for template
        os_list = []
        if os_result['success'] and os_result['data']:
            for os_item in os_result['data']:
                os_id = os_item.get('id')
                os_name = os_item.get('name')
                if os_id and os_name:
                    os_list.append(f"{os_id}:{os_name}")
        
        os_string = ','.join(os_list) if os_list else 'ubuntu,debian,centos'
        
        # Process the plans
        plans_data = plans_result['data']
        for i, plan_data in enumerate(plans_data):
            # Check if plan exists already
            existing_plan = ServerTemplate.query.filter_by(
                provider_id=provider.id, 
                provider_plan_id=plan_data['provider_plan_id']
            ).first()
            
            # Format description
            cpu = plan_data.get('cpu_cores', 0)
            ram_gb = plan_data.get('ram_mb', 0) / 1024
            disk_gb = plan_data.get('disk_gb', 0)
            description = f"{cpu} CPU, {ram_gb:.1f}GB RAM, {disk_gb}GB SSD"
            
            if existing_plan:
                # Update existing plan
                existing_plan.name = plan_data['name']
                existing_plan.cpu_cores = plan_data['cpu_cores']
                existing_plan.ram_mb = plan_data['ram_mb']
                existing_plan.disk_gb = plan_data['disk_gb']
                existing_plan.bandwidth_gb = plan_data['bandwidth_gb']
                existing_plan.price_monthly = plan_data['price_monthly']
                existing_plan.operating_systems = os_string
                existing_plan.description = description
            else:
                # Create new plan
                template = ServerTemplate(
                    name=plan_data['name'],
                    cpu_cores=plan_data['cpu_cores'],
                    ram_mb=plan_data['ram_mb'],
                    disk_gb=plan_data['disk_gb'],
                    bandwidth_gb=plan_data['bandwidth_gb'],
                    price_monthly=plan_data['price_monthly'],
                    provider_plan_id=plan_data['provider_plan_id'],
                    operating_systems=os_string,
                    description=description,
                    provider_id=provider.id,
                    display_order=i,
                    featured=(i == 1)  # Mark the middle option as featured
                )
                db.session.add(template)
        
        db.session.commit()
        
        flash(f"Successfully synchronized {len(plans_data)} plans from {provider.name}", 'success')
        return jsonify({
            'success': True,
            'message': f"Successfully synchronized {len(plans_data)} plans from {provider.name}"
        })
        
    except Exception as e:
        logger.error(f"Error syncing provider plans: {str(e)}")
        return jsonify({
            'success': False,
            'message': f"Error: {str(e)}"
        })

# Helper functions for server provisioning

def provision_server_on_provider(provider, template, operating_system, hostname, user):
    """
    Provision a new server on the cloud provider.
    Uses the cloud manager to create a real server on the provider's infrastructure.
    """
    try:
        # Get the appropriate provider manager
        cloud_manager = get_provider_manager(provider)
        
        # Get the provider plan ID from the template
        plan_id = template.provider_plan_id
        
        # Create the server
        result = cloud_manager.create_server(
            name=hostname,
            plan_id=plan_id,
            os_id=operating_system,
            region=provider.region
        )
        
        if not result['success']:
            logger.error(f"Failed to provision server: {result['message']}")
            return None, result['message']
        
        server_data = result['data']
        
        # Format the response to match our expected structure
        formatted_data = {
            'provider_server_id': server_data.get('id'),
            'ip_address': server_data.get('ip_address'),
            'hostname': hostname,
            'username': server_data.get('username'),
            'password': server_data.get('password'),
            'ssh_port': server_data.get('ssh_port', 22),
            'status': server_data.get('status')
        }
        
        return formatted_data, None  # Return data and no error
        
    except Exception as e:
        logger.error(f"Error provisioning server: {str(e)}")
        return None, f"Error: {str(e)}"

def server_action(provider, server_id, action):
    """
    Perform an action on a server
    
    Args:
        provider: The cloud provider
        server_id: The server ID
        action: The action to perform (start, stop, restart, delete)
    
    Returns:
        tuple: (success, message)
    """
    try:
        # Get the appropriate provider manager
        cloud_manager = get_provider_manager(provider)
        
        # Perform the requested action
        if action == 'start':
            result = cloud_manager.power_on_server(server_id)
        elif action == 'stop':
            result = cloud_manager.power_off_server(server_id)
        elif action == 'restart':
            result = cloud_manager.restart_server(server_id)
        elif action == 'delete':
            result = cloud_manager.delete_server(server_id)
        else:
            return False, f"Unsupported action: {action}"
        
        if not result['success']:
            logger.error(f"Failed to {action} server: {result['message']}")
            return False, result['message']
        
        return True, f"Server {action} initiated successfully"
        
    except Exception as e:
        logger.error(f"Error performing server action: {str(e)}")
        return False, f"Error: {str(e)}"

def get_server_info(provider, server_id):
    """
    Get server information
    
    Args:
        provider: The cloud provider
        server_id: The server ID
    
    Returns:
        tuple: (server_info, error_message)
    """
    try:
        # Get the appropriate provider manager
        cloud_manager = get_provider_manager(provider)
        
        # Get server details
        result = cloud_manager.get_server_details(server_id)
        
        if not result['success']:
            logger.error(f"Failed to get server info: {result['message']}")
            return None, result['message']
        
        return result['data'], None
        
    except Exception as e:
        logger.error(f"Error getting server info: {str(e)}")
        return None, f"Error: {str(e)}"