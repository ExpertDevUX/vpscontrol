from flask import Blueprint, render_template, redirect, url_for, flash, request, jsonify
from flask_login import login_required, current_user
from datetime import datetime, timedelta
import logging
import re

from app import db
from models import User, Cart, CartItem, ServerTemplate, Invoice, InvoiceItem
from utils.billing_utils import generate_invoice_number, calculate_tax, calculate_total
from utils.security import sanitize_input, validate_hostname

cart_bp = Blueprint('cart', __name__)
logger = logging.getLogger(__name__)

def get_or_create_cart():
    """Get the user's cart or create one if it doesn't exist"""
    if not current_user.cart:
        # Create a new cart for the user
        cart = Cart(user_id=current_user.id)
        db.session.add(cart)
        db.session.commit()
        return cart
    return current_user.cart

@cart_bp.route('/products')
def products():
    """Display available products/server templates"""
    templates = ServerTemplate.query.filter_by(is_active=True).order_by(ServerTemplate.display_order).all()
    
    # Group templates by provider
    providers = {}
    for template in templates:
        if template.provider:
            if template.provider.id not in providers:
                providers[template.provider.id] = {
                    'name': template.provider.name,
                    'templates': []
                }
            providers[template.provider.id]['templates'].append(template)
    
    return render_template('client/products.html', 
                          providers=providers,
                          templates=templates)

@cart_bp.route('/cart')
@login_required
def view_cart():
    """View shopping cart"""
    cart = get_or_create_cart()
    return render_template('client/cart.html', cart=cart)

@cart_bp.route('/configure/<int:template_id>')
@login_required
def configure_vps(template_id):
    """Configure VPS before adding to cart"""
    template = ServerTemplate.query.get_or_404(template_id)
    return render_template('client/vps_configure.html', template=template)

@cart_bp.route('/cart/add', methods=['POST'])
@login_required
def add_to_cart():
    """Add an item to the cart"""
    try:
        # Get and validate template_id
        template_id = request.form.get('template_id')
        if not template_id or not template_id.isdigit():
            flash('Invalid product selected', 'danger')
            return redirect(url_for('cart.products'))
        
        template_id = int(template_id)
        
        # Get and validate quantity
        try:
            quantity = int(request.form.get('quantity', 1))
            if quantity < 1 or quantity > 10:  # Set a reasonable limit
                quantity = 1  # Default to 1 if invalid
        except (ValueError, TypeError):
            quantity = 1  # Default to 1 if not a valid number
        
        # Validate billing cycle against allowed values
        allowed_billing_cycles = ['hourly', 'monthly', 'quarterly', 'semi_annual', 'annual', 'biennial', 'quadrennial']
        billing_cycle = request.form.get('billing_cycle', 'monthly')
        if billing_cycle not in allowed_billing_cycles:
            billing_cycle = 'monthly'  # Default to monthly if invalid
        
        # Get and validate operating system
        operating_system = sanitize_input(request.form.get('operating_system'), max_length=100)
        if not operating_system:
            flash('Invalid operating system selected', 'danger')
            return redirect(url_for('cart.products'))
        
        # Get and validate hostname
        hostname = sanitize_input(request.form.get('hostname'), max_length=255)
        if not hostname:
            flash('Invalid hostname', 'danger')
            return redirect(url_for('cart.products'))
        
        # Validate hostname format using our security utility
        if not validate_hostname(hostname):
            flash('Invalid hostname format', 'danger')
            return redirect(url_for('cart.products'))
            
        # Get premium add-ons with validation
        valid_addons = ['backup', 'ddos', 'monitoring', 'extra_ram', 'cpu_priority']
        addons = []
        
        # Only accept known add-ons
        if request.form.get('addon_backup') == 'true':
            addons.append('backup')
        if request.form.get('addon_ddos') == 'true':
            addons.append('ddos')
        if request.form.get('addon_monitoring') == 'true':
            addons.append('monitoring')
        if request.form.get('addon_ram') == 'true':
            addons.append('extra_ram')
        if request.form.get('addon_cpu_priority') == 'true':
            addons.append('cpu_priority')
        
        # Validate that all addons are in the valid list (additional security)
        addons = [addon for addon in addons if addon in valid_addons]
        
        # Get the template
        template = ServerTemplate.query.get_or_404(template_id)
        
        # Get or create cart
        cart = get_or_create_cart()
        
        # Create cart item
        cart_item = CartItem(
            cart_id=cart.id,
            template_id=template.id,
            quantity=quantity,
            billing_cycle=billing_cycle,
            operating_system=operating_system,
            hostname=hostname,
            addons=','.join(addons) if addons else None
        )
        
        db.session.add(cart_item)
        db.session.commit()
        
        flash(f'Added {template.name} to your cart', 'success')
        
        # Validate next_url
        next_url = request.form.get('next')
        if next_url == 'cart':
            return redirect(url_for('cart.view_cart'))
        else:
            return redirect(url_for('cart.products'))
    
    except Exception as e:
        # Log the error but don't expose details to the user
        logger.error(f"Error adding item to cart: {str(e)}")
        db.session.rollback()  # Roll back the transaction on error
        flash('An error occurred while adding the item to your cart', 'danger')
        return redirect(url_for('cart.products'))

@cart_bp.route('/cart/remove/<int:item_id>', methods=['POST'])
@login_required
def remove_from_cart(item_id):
    """Remove an item from the cart"""
    try:
        # Validate item_id is a positive integer
        if item_id <= 0:
            flash('Invalid item selected', 'danger')
            return redirect(url_for('cart.view_cart'))
        
        cart = get_or_create_cart()
        
        # Find the item and ensure it belongs to the current user's cart
        item = CartItem.query.filter_by(id=item_id, cart_id=cart.id).first_or_404()
        
        # Remove the item
        db.session.delete(item)
        db.session.commit()
        
        flash('Item removed from cart', 'success')
        return redirect(url_for('cart.view_cart'))
        
    except Exception as e:
        # Log the error but don't expose details to the user
        logger.error(f"Error removing item from cart: {str(e)}")
        db.session.rollback()  # Roll back the transaction on error
        flash('An error occurred while removing the item from your cart', 'danger')
        return redirect(url_for('cart.view_cart'))

@cart_bp.route('/cart/update/<int:item_id>', methods=['POST'])
@login_required
def update_cart_item(item_id):
    """Update a cart item"""
    try:
        cart = get_or_create_cart()
        
        # Find the item and ensure it belongs to the current user's cart
        item = CartItem.query.filter_by(id=item_id, cart_id=cart.id).first_or_404()
        
        # Get and validate quantity
        try:
            quantity = int(request.form.get('quantity', 1))
            if quantity < 1 or quantity > 10:  # Set a reasonable limit
                quantity = 1  # Default to 1 if invalid
        except (ValueError, TypeError):
            quantity = 1  # Default to 1 if not a valid number
        
        # Validate billing cycle against allowed values
        allowed_billing_cycles = ['hourly', 'monthly', 'quarterly', 'semi_annual', 'annual', 'biennial', 'quadrennial']
        billing_cycle = request.form.get('billing_cycle', item.billing_cycle)
        if billing_cycle not in allowed_billing_cycles:
            billing_cycle = item.billing_cycle  # Keep existing if invalid
        
        # Get and validate operating system
        operating_system = sanitize_input(request.form.get('operating_system', item.operating_system), max_length=100)
        if not operating_system:
            operating_system = item.operating_system  # Keep existing if invalid
        
        # Get and validate hostname
        hostname = sanitize_input(request.form.get('hostname', item.hostname), max_length=255)
        if not hostname:
            hostname = item.hostname  # Keep existing if invalid
        else:
            # Validate hostname format using our security utility
            if not validate_hostname(hostname):
                hostname = item.hostname  # Keep existing if invalid format
        
        # Get premium add-ons with validation
        valid_addons = ['backup', 'ddos', 'monitoring', 'extra_ram', 'cpu_priority']
        addons = []
        
        # Only accept known add-ons
        if request.form.get('addon_backup') == 'true':
            addons.append('backup')
        if request.form.get('addon_ddos') == 'true':
            addons.append('ddos')
        if request.form.get('addon_monitoring') == 'true':
            addons.append('monitoring')
        if request.form.get('addon_ram') == 'true':
            addons.append('extra_ram')
        if request.form.get('addon_cpu_priority') == 'true':
            addons.append('cpu_priority')
        
        # Validate that all addons are in the valid list (additional security)
        addons = [addon for addon in addons if addon in valid_addons]
        
        # Update the item
        item.quantity = quantity
        item.billing_cycle = billing_cycle
        item.operating_system = operating_system
        item.hostname = hostname
        item.addons = ','.join(addons) if addons else None
        
        db.session.commit()
        
        flash('Cart updated', 'success')
        return redirect(url_for('cart.view_cart'))
        
    except Exception as e:
        # Log the error but don't expose details to the user
        logger.error(f"Error updating cart item: {str(e)}")
        db.session.rollback()  # Roll back the transaction on error
        flash('An error occurred while updating your cart', 'danger')
        return redirect(url_for('cart.view_cart'))

@cart_bp.route('/cart/checkout', methods=['GET', 'POST'])
@login_required
def checkout():
    """Checkout process"""
    try:
        cart = get_or_create_cart()
        
        # Check if cart is empty
        if not cart.items:
            flash('Your cart is empty', 'warning')
            return redirect(url_for('cart.products'))
        
        if request.method == 'POST':
            # Verify that the cart still has items (double-check)
            if not cart.items:
                flash('Your cart is empty', 'warning')
                return redirect(url_for('cart.products'))
                
            # Create invoice from cart
            invoice_number = generate_invoice_number()
            
            # Calculate amounts with validation
            amount = cart.subtotal
            if amount <= 0:
                flash('Invalid cart amount', 'danger')
                return redirect(url_for('cart.view_cart'))
                
            tax_amount = calculate_tax(amount)
            if tax_amount < 0:  # Tax should never be negative
                tax_amount = 0
                
            total_amount = calculate_total(amount, tax_amount)
            if total_amount <= 0:
                flash('Invalid total amount', 'danger')
                return redirect(url_for('cart.view_cart'))
            
            # Set due date (14 days from now)
            due_date = datetime.utcnow() + timedelta(days=14)
            
            # Create invoice with sanitized data
            invoice = Invoice(
                invoice_number=invoice_number,
                amount=amount,
                tax_amount=tax_amount,
                total_amount=total_amount,
                status='unpaid',
                issue_date=datetime.utcnow(),
                due_date=due_date,
                user_id=current_user.id
            )
            
            db.session.add(invoice)
            db.session.flush()  # Get invoice ID
            
            # Process valid cart items
            processed_items = 0
            for item in cart.items:
                # Validate the cart item before processing
                if not item.template or not item.quantity or item.quantity <= 0:
                    logger.warning(f"Skipping invalid cart item: {item.id}")
                    continue
                
                # Verify billing cycle is valid
                allowed_billing_cycles = ['hourly', 'monthly', 'quarterly', 'semi_annual', 'annual', 'biennial', 'quadrennial']
                if item.billing_cycle not in allowed_billing_cycles:
                    item.billing_cycle = 'monthly'  # Default to monthly if invalid
                
                # Map billing term correctly
                billing_term = "month"
                if item.billing_cycle == 'quarterly':
                    billing_term = "quarter (3 months)"
                elif item.billing_cycle == 'annually':
                    billing_term = "year"
                
                # Create sanitized description
                description = f"{item.template.name} ({item.template.cpu_cores} CPU, {item.template.ram_mb/1024}GB RAM) - {item.billing_cycle} billing"
                
                # Add addon information to description with validation
                valid_addons = ['backup', 'ddos', 'monitoring', 'extra_ram', 'cpu_priority']
                if item.addons:
                    # Only process valid addons
                    addon_list = [addon for addon in item.addons.split(',') if addon in valid_addons]
                    addon_names = []
                    if 'backup' in addon_list:
                        addon_names.append('Daily Backup')
                    if 'ddos' in addon_list:
                        addon_names.append('DDoS Protection')
                    if 'monitoring' in addon_list:
                        addon_names.append('Enhanced Monitoring')
                    if 'extra_ram' in addon_list:
                        addon_names.append('Extra RAM')
                    if 'cpu_priority' in addon_list:
                        addon_names.append('CPU Priority Boost')
                    
                    if addon_names:
                        description += f" with {', '.join(addon_names)}"
                
                # Create invoice item with validated data
                invoice_item = InvoiceItem(
                    description=description,
                    amount=max(0.01, item.subtotal),  # Ensure positive amount
                    quantity=max(1, item.quantity),   # Ensure positive quantity
                    invoice_id=invoice.id
                )
                
                db.session.add(invoice_item)
                processed_items += 1
            
            # If no valid items were processed, rollback and show error
            if processed_items == 0:
                db.session.rollback()
                flash('No valid items in cart to process', 'danger')
                return redirect(url_for('cart.view_cart'))
            
            # Clear the cart only if we have processed items successfully
            for item in cart.items:
                db.session.delete(item)
            
            # Commit the transaction after all operations are successful
            db.session.commit()
            
            logger.info(f"User {current_user.id} checked out successfully, invoice #{invoice_number} created")
            flash('Your order has been submitted. Please complete payment to provision your server.', 'success')
            return redirect(url_for('client.invoice_details', invoice_id=invoice.id))
        
        # For GET requests, just render the checkout template
        return render_template('client/checkout.html', cart=cart)
        
    except Exception as e:
        # Log the error but don't expose details to the user
        logger.error(f"Error during checkout process: {str(e)}")
        db.session.rollback()  # Roll back the transaction on error
        flash('An error occurred during the checkout process', 'danger')
        return redirect(url_for('cart.view_cart'))

@cart_bp.route('/cart/clear', methods=['POST'])
@login_required
def clear_cart():
    """Clear all items from the cart"""
    try:
        cart = get_or_create_cart()
        
        # Track how many items were removed for logging
        removed_item_count = len(cart.items)
        
        # Remove all items
        for item in cart.items:
            db.session.delete(item)
        
        db.session.commit()
        
        logger.info(f"User {current_user.id} cleared their cart with {removed_item_count} items")
        flash('Your cart has been cleared', 'success')
        return redirect(url_for('cart.products'))
        
    except Exception as e:
        # Log the error but don't expose details to the user
        logger.error(f"Error clearing cart: {str(e)}")
        db.session.rollback()  # Roll back the transaction on error
        flash('An error occurred while clearing your cart', 'danger')
        return redirect(url_for('cart.view_cart'))