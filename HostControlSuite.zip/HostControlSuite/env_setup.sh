export DATABASE_URL=postgresql://postgres:your_password@localhost:5432/vpscontrolpanel
# Run this with: source env_setup.sh

echo "Setup complete! Run 'python main.py' to start the application."
