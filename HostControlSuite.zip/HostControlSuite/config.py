"""
VPS Control Panel Configuration
"""
import os
import logging
from datetime import timedelta

# Setup logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Base configuration
class Config:
    """Base configuration"""
    # Secret key for session
    SECRET_KEY = os.environ.get('SESSION_SECRET', 'dev-secret-key-change-in-production')
    
    # Database configuration - uses PostgreSQL by default
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL')
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    SQLALCHEMY_ENGINE_OPTIONS = {
        "pool_recycle": 300,
        "pool_pre_ping": True,
    }
    
    # Session configuration
    SESSION_TYPE = 'filesystem'
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)
    
    # Security settings
    SESSION_COOKIE_SECURE = os.environ.get('PRODUCTION', 'false').lower() == 'true'
    SESSION_COOKIE_HTTPONLY = True
    REMEMBER_COOKIE_SECURE = os.environ.get('PRODUCTION', 'false').lower() == 'true'
    REMEMBER_COOKIE_HTTPONLY = True
    
    # Application settings
    APP_NAME = 'VPS Control Panel'
    COMPANY_NAME = os.environ.get('COMPANY_NAME', 'HWO Security')
    ADMIN_EMAIL = os.environ.get('ADMIN_EMAIL', 'info@hwosecurity.org')
    
    # Payment gateway settings
    PAYMENT_GATEWAYS = {
        'paypal': {
            'enabled': True,
            'sandbox': os.environ.get('PAYPAL_SANDBOX', 'true').lower() == 'true',
            'client_id': os.environ.get('PAYPAL_CLIENT_ID', ''),
            'secret_key': os.environ.get('PAYPAL_SECRET_KEY', ''),
        },
        'stripe': {
            'enabled': os.environ.get('STRIPE_SECRET_KEY', '') != '',
            'secret_key': os.environ.get('STRIPE_SECRET_KEY', ''),
            'public_key': os.environ.get('STRIPE_PUBLIC_KEY', ''),
        },
        'crypto': {
            'enabled': True,
        }
    }
    
    # Cloud provider settings
    CLOUD_PROVIDERS = {
        'aws': {
            'enabled': os.environ.get('AWS_ACCESS_KEY', '') != '',
            'access_key': os.environ.get('AWS_ACCESS_KEY', ''),
            'secret_key': os.environ.get('AWS_SECRET_KEY', ''),
        },
        'digitalocean': {
            'enabled': os.environ.get('DO_API_TOKEN', '') != '',
            'api_token': os.environ.get('DO_API_TOKEN', ''),
        },
        'vultr': {
            'enabled': os.environ.get('VULTR_API_KEY', '') != '',
            'api_key': os.environ.get('VULTR_API_KEY', ''),
        }
    }
    
    # Email settings
    MAIL_SERVER = os.environ.get('MAIL_SERVER', 'smtp.gmail.com')
    MAIL_PORT = int(os.environ.get('MAIL_PORT', 587))
    MAIL_USE_TLS = os.environ.get('MAIL_USE_TLS', 'true').lower() == 'true'
    MAIL_USE_SSL = os.environ.get('MAIL_USE_SSL', 'false').lower() == 'true'
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME', '')
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD', '')
    MAIL_DEFAULT_SENDER = os.environ.get('MAIL_DEFAULT_SENDER', 'info@hwosecurity.org')
    
    # AI settings
    AI_INTEGRATION = {
        'enabled': os.environ.get('AI_ENABLED', 'true').lower() == 'true',
        'provider': os.environ.get('AI_PROVIDER', 'anthropic'),
        'api_key': os.environ.get('ANTHROPIC_API_KEY', ''),
        'model': 'claude-3-5-sonnet-20241022',  # the newest Anthropic model is "claude-3-5-sonnet-20241022" which was released October 22, 2024
    }
    
    # Security settings
    SECURITY_SETTINGS = {
        'captcha_enabled': os.environ.get('CAPTCHA_ENABLED', 'false').lower() == 'true',
        'turnstile_site_key': os.environ.get('TURNSTILE_SITE_KEY', ''),
        'turnstile_secret_key': os.environ.get('TURNSTILE_SECRET_KEY', ''),
    }


# Development configuration
class DevelopmentConfig(Config):
    """Development configuration"""
    DEBUG = True
    TESTING = False


# Production configuration
class ProductionConfig(Config):
    """Production configuration"""
    DEBUG = False
    TESTING = False


# Test configuration
class TestingConfig(Config):
    """Testing configuration"""
    DEBUG = True
    TESTING = True
    SQLALCHEMY_DATABASE_URI = 'sqlite:///:memory:'


# Configuration dictionary
config = {
    'development': DevelopmentConfig,
    'production': ProductionConfig,
    'testing': TestingConfig,
    'default': DevelopmentConfig
}

# Get the active configuration
def get_config():
    """Get the active configuration based on environment"""
    env = os.environ.get('FLASK_ENV', 'development')
    return config.get(env, config['default'])